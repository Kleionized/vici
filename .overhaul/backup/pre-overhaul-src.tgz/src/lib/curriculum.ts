/**
 * The curriculum: twelve weeks, eighty-four lessons, read off the `UI Final`
 * bundle into `content/curriculum84.ts`.
 *
 * The rest of the app already speaks `Lesson` — progress, reflections and the
 * backend are all keyed on a slug — so this module adapts each of the eighty-
 * four into that shape. Nothing downstream needs to know the content changed.
 *
 * It used to adapt a different set: 110 interactive lessons in ten parts,
 * generated from `src/content/interactive`. Those were never part of the twelve
 * weeks the bundle draws, which is how a lesson called "The slip equation" came
 * to be the one the home page offered on day fourteen (DECISIONS D-112).
 *
 * A lesson's *body* is not here. The reader is 1,858 transcribed pages in
 * `content/lessonReader.ts`, opened by day at `/lesson/day/[day]`; the card at
 * `/lesson-card/[day]` is the way in. What this file carries is the index.
 */

import { CURRICULUM_84, lessonForDay } from '@/content/curriculum84';
import type { Lesson } from '@/lib/types';

/** `day-07` — zero-padded, so the plain string sort is the curriculum's order. */
export function lessonSlug(day: number): string {
  return `day-${String(day).padStart(2, '0')}`;
}

/** The day a slug names, or null if it names nothing this curriculum has. */
export function dayForSlug(slug: string): number | null {
  const match = /^day-(\d{1,2})$/.exec(slug);
  if (!match) return null;
  const day = Number(match[1]);
  return lessonForDay(day) ? day : null;
}

/**
 * Every lesson in the `Lesson` shape, in curriculum order.
 *
 * `bodyMarkdown` is the one-line summary the lesson card carries, because that
 * is the only prose the index holds and it is what a search should match on.
 * The curriculum states no reflection prompt, so that is left empty rather than
 * filled with a prompt nobody wrote.
 *
 * It does state a duration — every one of the 83 reader covers draws one, "3
 * min" to "7 min", and `LESSON_READER[day][0]` carries it — but nothing reads
 * `estimatedMinutes`, and the cover draws its own. Left unset rather than
 * duplicated into a field no screen consults.
 */
export const CURRICULUM_LESSONS: Lesson[] = CURRICULUM_84.flatMap((week) =>
  week.lessons.map((lesson, index) => ({
    slug: lessonSlug(lesson.day),
    title: lesson.title,
    week: week.n,
    dayInWeek: index + 1,
    orderIndex: lesson.day,
    bodyMarkdown: lesson.summary,
    reflectionPrompt: '',
    reflectionFields: [],
    approachTags: [],
    sensitive: false,
  })),
);

export function lessonBySlug(slug: string): Lesson | null {
  return CURRICULUM_LESSONS.find((lesson) => lesson.slug === slug) ?? null;
}
