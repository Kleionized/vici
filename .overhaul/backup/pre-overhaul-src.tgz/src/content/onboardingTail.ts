/**
 * The onboarding tail's drawings, read off the canvas.
 *
 * GENERATED FILE — do not edit by hand. Written by
 * `scripts/vicifull/gen-tail.mjs` from
 * `Latest Vici FULL/project/Email Login.dc.html`. Re-run the generator instead.
 */

/** `33 · Cost Next 30` — 30 cells, 6 across; true is a day that ends the same way. */
export const COST_30: boolean[] = [false,false,true,false,false,true,false,false,false,true,false,false,true,false,false,false,true,false,false,true,false,false,false,true,false,false,true,false,true,false];

/** `34 · Cost Next 365` — 365 cells, 17 across, square at radius 4. */
export const COST_365: boolean[] = [false,false,false,false,false,false,false,false,false,false,true,false,false,false,false,false,false,false,false,false,true,false,true,false,false,false,false,true,false,true,true,true,false,true,false,false,false,false,false,true,false,true,false,true,false,true,false,false,false,false,false,false,false,false,false,false,false,false,false,true,true,false,true,false,true,false,false,false,false,true,false,false,false,true,false,false,false,false,false,true,false,false,false,true,false,true,false,false,false,false,false,false,true,false,true,false,false,true,false,true,false,false,false,false,false,true,false,false,false,false,false,false,true,false,true,true,true,false,false,false,true,false,false,false,false,true,true,false,true,false,false,true,false,true,false,true,false,false,false,true,true,false,false,false,false,false,false,false,false,true,false,true,false,false,false,false,false,false,true,true,false,false,false,true,true,false,true,false,false,true,false,false,false,false,false,true,true,true,false,true,true,false,true,true,false,false,true,false,false,false,true,true,false,true,false,false,true,true,false,false,true,true,false,false,false,false,true,false,true,false,false,false,false,false,false,false,true,true,false,true,false,true,false,false,false,false,false,false,false,false,true,false,true,false,false,false,false,true,false,false,false,false,true,true,true,true,false,false,false,false,false,true,false,true,false,false,false,false,false,true,true,false,false,false,false,false,true,false,false,false,false,false,false,false,true,true,false,true,false,false,false,false,true,true,false,true,false,false,false,true,false,false,false,false,false,true,true,true,false,false,true,false,false,true,false,false,false,true,false,true,false,false,false,false,false,true,false,true,false,false,false,false,false,false,false,false,true,false,false,false,false,true,false,false,true,false,false,true,true,false,true,true,false,false,false,false,true,true,true,false,true,false,false,false,false,false,true,true,false,false,false,false,true,false,false];

/** `35 · Cost By Age 80` — eleven 1.3pt stars on #060606, at the frame's own points. */
export const AGE_80_STARS: [number, number][] = [[61,132],[287,96],[174,214],[329,291],[96,348],[244,407],[52,489],[331,542],[158,596],[262,671],[84,703]];

/**
 * `32 · Starting Score` — the ring gauge and the ELO curve.
 *
 * 48 tick marks around a 240 x 240 box, a 104pt track at 10pt, and an arc whose
 * dash length is the rating's share of the circumference: 2π·104 = 653.45.
 * The frame's own `89.7 653.5` writes the gap as the whole circumference
 * rather than the remainder, so the two do not sum to it. The curve is 61
 * samples of a bell peaking at x 172.5, which is 1,500 on a 0…3,000 axis.
 */
export const SCORE_RING = {"ticks":[[120,7,120,2],[134.7,8,135.4,3],[149.2,10.9,150.5,6],[163.2,15.6,165.2,11],[176.5,22.1,179,17.8],[188.8,30.4,191.8,26.4],[199.9,40.1,203.4,36.6],[209.6,51.2,213.6,48.2],[217.9,63.5,222.2,61],[224.4,76.8,229,74.8],[229.1,90.8,234,89.5],[232,105.3,237,104.6],[233,120,238,120],[232,134.7,237,135.4],[229.1,149.2,234,150.5],[224.4,163.2,229,165.2],[217.9,176.5,222.2,179],[209.6,188.8,213.6,191.8],[199.9,199.9,203.4,203.4],[188.8,209.6,191.8,213.6],[176.5,217.9,179,222.2],[163.2,224.4,165.2,229],[149.2,229.1,150.5,234],[134.7,232,135.4,237],[120,233,120,238],[105.3,232,104.6,237],[90.8,229.1,89.5,234],[76.8,224.4,74.8,229],[63.5,217.9,61,222.2],[51.2,209.6,48.2,213.6],[40.1,199.9,36.6,203.4],[30.4,188.8,26.4,191.8],[22.1,176.5,17.8,179],[15.6,163.2,11,165.2],[10.9,149.2,6,150.5],[8,134.7,3,135.4],[7,120,2,120],[8,105.3,3,104.6],[10.9,90.8,6,89.5],[15.6,76.8,11,74.8],[22.1,63.5,17.8,61],[30.4,51.2,26.4,48.2],[40.1,40.1,36.6,36.6],[51.2,30.4,48.2,26.4],[63.5,22.1,61,17.8],[76.8,15.6,74.8,11],[90.8,10.9,89.5,6],[105.3,8,104.6,3]],"trackR":104,"strokeW":10,"circumference":653.45};
export const SCORE_CURVE: [number, number][] = [[0,80],[5.8,79.9],[11.5,79.9],[17.3,79.8],[23,79.7],[28.8,79.6],[34.5,79.4],[40.3,79.1],[46,78.7],[51.8,78.1],[57.5,77.4],[63.2,76.4],[69,75.1],[74.8,73.5],[80.5,71.5],[86.3,69],[92,66.1],[97.8,62.7],[103.5,58.9],[109.3,54.5],[115,49.8],[120.7,44.8],[126.5,39.5],[132.3,34.3],[138,29.2],[143.8,24.5],[149.5,20.3],[155.3,16.8],[161,14.2],[166.8,12.5],[172.5,12],[178.3,12.5],[184,14.2],[189.8,16.8],[195.5,20.3],[201.3,24.5],[207,29.2],[212.8,34.3],[218.5,39.5],[224.3,44.8],[230,49.8],[235.8,54.5],[241.5,58.9],[247.3,62.7],[253,66.1],[258.8,69],[264.5,71.5],[270.3,73.5],[276,75.1],[281.8,76.4],[287.5,77.4],[293.3,78.1],[299,78.7],[304.8,79.1],[310.5,79.4],[316.3,79.6],[322,79.7],[327.8,79.8],[333.5,79.9],[339.3,79.9],[345,80]];
/** What the frame itself draws, kept so the spec can quote it — see DECISIONS D050. */
export const SCORE_SAMPLE = {"score":842,"dash":89.7,"markerX":79.4};
