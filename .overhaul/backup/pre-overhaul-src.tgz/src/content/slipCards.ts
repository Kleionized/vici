import type { SlipArtName } from '@/components/slip/art';

/**
 * The nineteen post-slip cards — canvas 99A–99H (`Slip Feeling — …`) and
 * 100A–100K (`Slip Trigger — …`).
 *
 * All nineteen frames are the same sheet: the illustration at 180, the headline
 * at 434, the body at 480, one dark pill and the ghost link **Give me another**.
 * Stripped of their artwork and their two strings, all nineteen hash identical,
 * so the only per-card data is what is here. The eight Feeling cards all end on
 * “Done”; the eleven Trigger cards each name their own verb.
 *
 * Fourteen drawings serve the twenty-one illustrated frames in the group — six
 * pairs and one three-way clone. `art` names the picture, not the frame, so the
 * sharing is visible rather than copied.
 */
export type SlipCard = {
  /** Unique across the two families — `Not sure` is a card in both of them. */
  id: string;
  /** The canvas's own key: the words after the em dash in the frame's badge. */
  key: string;
  kind: 'feeling' | 'trigger';
  headline: string;
  body: string;
  cta: string;
  art: SlipArtName;
  /**
   * What 98E's fourth row reads back as `Change for next time`.
   *
   * The canvas states the row, its label and one value — `Phone charges outside
   * the bedroom`, next to a slip fed by `Phone in bed · Late night`, which is
   * the Late night card's own instruction restated as a standing rule. No frame
   * asks the question, so the other eighteen are written here to the same
   * pattern: each card's move, in one line, in the log's voice.
   */
  change: string;
};

export const SLIP_CARDS: readonly SlipCard[] = [
  { id: 'feel-ashamed', change: 'No self-lecture — straight to the next thing', key: 'Ashamed', kind: 'feeling', art: 'cards', cta: 'Done', headline: 'Skip the self-lecture.', body: 'Don’t spend the next ten minutes punishing yourself. The useful part starts now: change what happens next.' },
  { id: 'feel-bored', change: 'One thing chosen instead of the feed', key: 'Bored', kind: 'feeling', art: 'steps', cta: 'Done', headline: 'Pick the next thing.', body: 'The slip doesn’t get to decide the rest of your day. Choose one thing to do and get out of the feed.' },
  { id: 'feel-lonely', change: 'Not alone with it tonight', key: 'Lonely', kind: 'feeling', art: 'bubbles', cta: 'Done', headline: 'Don’t stay cut off.', body: 'You don’t have to tell anyone what happened. Just don’t stay alone with it tonight.' },
  { id: 'feel-stressed', change: 'A real break before the next hour', key: 'Stressed', kind: 'feeling', art: 'deskclock', cta: 'Done', headline: 'The problem can wait.', body: 'Ten minutes. Stop here, take a real break, and give yourself a clean next hour.' },
  { id: 'feel-rejected', change: 'No messages until it has cooled down', key: 'Rejected', kind: 'feeling', art: 'phonerays', cta: 'Done', headline: 'Don’t go back yet.', body: 'No messages, no profiles, no replies. Cool down first — then decide.' },
  { id: 'feel-tired', change: 'Phone away, the night made easier', key: 'Tired', kind: 'feeling', art: 'bed', cta: 'Done', headline: 'Do less, not more.', body: 'Put the phone away and make the rest of the night easier.' },
  { id: 'feel-turned-on', change: 'The cue goes, not the feeling', key: 'Turned on', kind: 'feeling', art: 'nighthills', cta: 'Done', headline: 'Stop feeding it.', body: 'Being turned on is not the problem. Cut the cue and let the rest of it pass.' },
  { id: 'feel-not-sure', change: 'Stop at the first one, no story needed', key: 'Not sure', kind: 'feeling', art: 'dots', cta: 'Done', headline: 'No reason needed tonight.', body: 'You don’t need the story. Stop here and make the next slip harder.' },

  { id: 'trig-late-night', change: 'Phone charges outside the bedroom', key: 'Late night', kind: 'trigger', art: 'phoneflat', cta: 'Phone is away', headline: 'Move the phone.', body: 'Charge it outside the bedroom tonight.' },
  { id: 'trig-scrolling', change: 'The feed stays closed for the night', key: 'Scrolling', kind: 'trigger', art: 'phoneup', cta: 'Feed is closed', headline: 'Get off the feed.', body: 'Close it for the rest of the night. Don’t replace it with another feed.' },
  { id: 'trig-sexual-content', change: 'The account that got me there is closed', key: 'Sexual content', kind: 'trigger', art: 'phonerays', cta: 'Closed', headline: 'Close everything.', body: 'Close the page, app, or account that got you there. Don’t look again.' },
  { id: 'trig-boredom', change: 'The next hour gets a job', key: 'Boredom', kind: 'trigger', art: 'steps', cta: 'Done', headline: 'Give the next hour a job.', body: 'A short, hard set beats an open feed. Then pick one thing to actually do.' },
  { id: 'trig-loneliness', change: 'One person messaged instead', key: 'Loneliness', kind: 'trigger', art: 'bubbles', cta: 'Done', headline: 'Move toward people.', body: 'Message one person, or go where people are. No explanation required.' },
  { id: 'trig-stress', change: 'One task named for later, then a break', key: 'Stress', kind: 'trigger', art: 'deskclock', cta: 'Done', headline: 'Contained break.', body: 'Step away from the problem properly. Name one task for later — just one.' },
  { id: 'trig-argument', change: 'Ten minutes before I reply', key: 'Argument', kind: 'trigger', art: 'bubbles', cta: 'I’ll leave it', headline: 'Don’t reply yet.', body: 'Stop rereading the messages. Leave it alone for ten minutes.' },
  { id: 'trig-couldnt-sleep', change: 'Out of bed rather than on the phone', key: 'Couldn’t sleep', kind: 'trigger', art: 'bed', cta: 'I’m out of bed', headline: 'Get out of bed for a few minutes.', body: 'Stay off feeds. Go back when you are actually ready to sleep.' },
  { id: 'trig-being-alone', change: 'Somewhere less private for ten minutes', key: 'Being alone', kind: 'trigger', art: 'door', cta: 'I’ve moved', headline: 'Leave the room.', body: 'Move somewhere less private for the next ten minutes.' },
  { id: 'trig-habit', change: 'Something different after a slip', key: 'Habit', kind: 'trigger', art: 'rings', cta: 'Continue', headline: 'Change what happens next.', body: 'Do something different from what you normally do after a slip.' },
  { id: 'trig-not-sure', change: 'Phone out of reach for ten minutes', key: 'Not sure', kind: 'trigger', art: 'dots', cta: 'Phone is away', headline: 'Put the phone away.', body: 'Move somewhere different and keep the phone out of reach for ten minutes.' },
] as const;

/**
 * Which card a `What fed it?` tile opens. The canvas states no mapping — the
 * tiles and the cards are two lists that overlap without matching — so this is
 * the reading the words support: the five feelings on the grid open their own
 * Feeling card, and the four situations open the Trigger card that names the
 * same situation. `Phone in bed` has no card of its own; `Late night` is the
 * one that tells you to charge the phone outside the bedroom, so it takes both.
 */
export const SLIP_FED_TO_CARD: Readonly<Record<string, string>> = {
  Bored: 'feel-bored',
  Lonely: 'feel-lonely',
  Stressed: 'feel-stressed',
  Tired: 'feel-tired',
  'Phone in bed': 'trig-late-night',
  'Late night': 'trig-late-night',
  'Sexual content': 'trig-sexual-content',
  Argument: 'trig-argument',
  'Not sure': 'feel-not-sure',
};
