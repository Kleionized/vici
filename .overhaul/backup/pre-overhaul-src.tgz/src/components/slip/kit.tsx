import { LinearGradient } from 'expo-linear-gradient';
import { useId, type ReactNode } from 'react';
import { View, type TextStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, Ellipse, Path, RadialGradient, Rect, Stop } from 'react-native-svg';

import { SlipArt, type SlipArtName } from '@/components/slip/art';
import { AppText, Grain, Hill, PressScale } from '@/components/ui';
import { fonts, sans } from '@/lib/theme';

/**
 * The post-slip sheet — canvas 98A–98L, 99A–99H, 100A–100K.
 *
 * Twenty-five of the group's thirty-one frames are the same object: a sheet
 * pinned at frame y 52 under a lone close cross, an illustration, a headline, a
 * line of body, one dark pill on the bottom edge and sometimes a ghost link.
 * What they do NOT share is where any of that sits. The nineteen card frames
 * agree exactly (art 180, headline 434, body 480); the six one-offs disagree
 * with the family and with each other — art 166–180, headline 382–446, and even
 * the headline-to-body gap is 44, 46 or 50. So every offset below is a prop.
 */

const PAPER = '#F4F3F0';
const INK = '#1D1C1A';
const MUTED = '#55534E';
const GHOST = '#8B8882';

const BALANCE = { textWrap: 'balance' } as unknown as TextStyle;
const PRETTY = { textWrap: 'pretty' } as unknown as TextStyle;
/** Where a frame states no `text-wrap`, the app must not impose one. */
const PLAIN = { textWrap: 'wrap' } as unknown as TextStyle;

/** `M3 3l14 14M17 3L3 17` at 20 × 20 — the only chrome the card frames carry. */
export function SlipClose({ onPress, color = MUTED, top = 18 }: { onPress: () => void; color?: string; top?: number }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel="Close"
      hitSlop={{ top: 18, bottom: 18, left: 18, right: 18 }}
      style={{ position: 'absolute', right: 22, top, minHeight: 0 }}>
      <Svg width={20} height={20} viewBox="0 0 20 20">
        <Path d="M3 3l14 14M17 3L3 17" stroke={color} strokeWidth={2} strokeLinecap="round" />
      </Svg>
    </PressScale>
  );
}

/**
 * The sheet itself. The canvas draws it at `top: 52` against a 54pt status bar,
 * so it crests 2pt above the bar's baseline — hence `insets.top - 2`, and hence
 * every offset inside it being the canvas's own number with nothing taken off.
 */
export function SlipSheet({ dark = false, children }: { dark?: boolean; children: ReactNode }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: dark ? '#131313' : PAPER }}>
      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: insets.top - 2,
          bottom: 0,
          // 98I is the only frame in the group whose sheet declares no
          // background of its own — the dark frame shows through it.
          backgroundColor: dark ? undefined : PAPER,
          overflow: 'hidden',
        }}>
        {children}
      </View>
    </View>
  );
}

export type SlipPageProps = {
  art: SlipArtName;
  artTop: number;
  headline: string;
  headlineTop: number;
  body: string;
  bodyTop: number;
  cta: string;
  onCta: () => void;
  onClose: () => void;
  ghost?: string;
  onGhost?: () => void;
  /** 98I `Slip Third` inverts the pill and lightens every string. */
  dark?: boolean;
};

/** One card frame, whole. Every number on it is stated by the caller. */
export function SlipPage({ art, artTop, headline, headlineTop, body, bodyTop, cta, onCta, onClose, ghost, onGhost, dark = false }: SlipPageProps) {
  return (
    <SlipSheet dark={dark}>
      <SlipClose onPress={onClose} color={dark ? 'rgba(244,243,240,0.55)' : MUTED} />
      <SlipArt name={art} top={artTop} />
      <AppText
        center
        style={[
          sans('500'),
          // 98I drops the `letter-spacing:0.1px` its eighteen light siblings
          // all carry. Kept as drawn rather than regularised.
          { position: 'absolute', left: 30, right: 30, top: headlineTop, fontSize: 23, lineHeight: 30, color: dark ? PAPER : INK },
          dark ? null : { letterSpacing: 0.1 },
          BALANCE,
        ]}>
        {headline}
      </AppText>
      <AppText
        center
        style={[
          sans('400'),
          { position: 'absolute', left: 44, right: 44, top: bodyTop, fontSize: 15.5, lineHeight: 23, color: dark ? 'rgba(244,243,240,0.65)' : MUTED },
          PRETTY,
        ]}>
        {body}
      </AppText>
      <SlipPrimary label={cta} onPress={onCta} dark={dark} />
      {ghost && onGhost ? <SlipGhost label={ghost} onPress={onGhost} /> : null}
    </SlipSheet>
  );
}

/** `left:24 right:24 bottom:88 h:54 r:27` — the card family's pill. */
export function SlipPrimary({ label, onPress, dark = false }: { label: string; onPress: () => void; dark?: boolean }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        bottom: 88,
        height: 54,
        minHeight: 0,
        borderRadius: 27,
        backgroundColor: dark ? PAPER : '#131313',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: dark ? '#131313' : '#FFFFFF' }]}>{label}</AppText>
    </PressScale>
  );
}

/** `left:0 right:0 bottom:44` — “Not now”, “Later”, “Give me another”. */
export function SlipGhost({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}
      style={{ position: 'absolute', left: 0, right: 0, bottom: 44, minHeight: 0 }}>
      <AppText center style={[sans('500'), { fontSize: 15, color: GHOST }]}>
        {label}
      </AppText>
    </PressScale>
  );
}

// ═══ 98C / 98D · the two logged questions ════════════════════════════

/**
 * The question each of the two rail steps asks. The urge log's own `Heading`
 * has the same box, but the slip frames state `text-wrap:balance` where it
 * inherits `pretty` — a different set of line breaks on the same words.
 */
export function SlipHeading({ children, top = 84 }: { children: string; top?: number }) {
  return (
    <AppText center style={[sans('500'), { position: 'absolute', left: 44, right: 44, top, fontSize: 22, lineHeight: 30, letterSpacing: 0.1, color: INK }, BALANCE]}>
      {children}
    </AppText>
  );
}

/**
 * The nine `What fed it?` glyphs, drawn from 98D's own paths rather than from
 * `TriggerMark`: the canvas withdrew `Social` and `Craving` from this grid and
 * added an eye and a three-dot ellipsis that the shared mark set has no member
 * for, and it renamed three of the seven it kept.
 */
function FedGlyph({ name, on }: { name: FedName; on: boolean }) {
  const ink = on ? PAPER : INK;
  const cut = on ? '#131313' : '#F1EFE9';
  switch (name) {
    case 'Bored':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Circle cx={12} cy={12} r={9} fill="none" stroke={ink} strokeWidth={2.1} />
          <Path d="M8.5 14.5h7" stroke={ink} strokeWidth={2.1} strokeLinecap="round" />
          <Circle cx={9} cy={10} r={1.2} fill={ink} />
          <Circle cx={15} cy={10} r={1.2} fill={ink} />
        </Svg>
      );
    case 'Lonely':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Circle cx={12} cy={8} r={4} fill={ink} />
          <Path d="M4.5 20c0-3.9 3.4-6.2 7.5-6.2S19.5 16.1 19.5 20z" fill={ink} />
        </Svg>
      );
    case 'Stressed':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Path d="M13 2L4 13h6l-1 9 9-12h-6z" fill={ink} />
        </Svg>
      );
    case 'Tired':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Path d="M13 3h6l-6 7h6" fill="none" stroke={ink} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
          <Path d="M4 13h5l-5 6h5" fill="none" stroke={ink} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      );
    case 'Phone in bed':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Rect width={12} height={19} x={6} y={2.5} rx={3} fill={ink} />
          <Rect width={8} height={11} x={8} y={5} rx={1} fill={cut} />
          <Circle cx={12} cy={18.6} r={1} fill={cut} />
        </Svg>
      );
    case 'Late night':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Path d="M20.1 15.1A8.7 8.7 0 1 1 8.9 3.9 8.7 8.7 0 0 0 20.1 15.1Z" fill={ink} fillRule="evenodd" />
        </Svg>
      );
    case 'Sexual content':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Path d="M2.5 12c2.7-4.4 5.9-6.6 9.5-6.6s6.8 2.2 9.5 6.6c-2.7 4.4-5.9 6.6-9.5 6.6S5.2 16.4 2.5 12z" fill="none" stroke={ink} strokeWidth={2} strokeLinejoin="round" />
          <Circle cx={12} cy={12} r={2.8} fill={ink} />
        </Svg>
      );
    case 'Argument':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Path d="M3 5.5A1.5 1.5 0 0 1 4.5 4h9A1.5 1.5 0 0 1 15 5.5v5A1.5 1.5 0 0 1 13.5 12H8l-3.4 3v-3H4.5A1.5 1.5 0 0 1 3 10.5z" fill={ink} />
          {/* the canvas fades the reply bubble to 0.55. This was the only plain
              `opacity` attribute in the group's 31 frames, and it was invisible
              to `body.mjs` until F37 added it to the transcriber's allowlist —
              the value was read out of the frame's own markup instead. */}
          <Path d="M17 9h3a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1v2.5L16.5 16H12a1 1 0 0 1-1-1z" fill={ink} opacity={0.55} />
        </Svg>
      );
    case 'Not sure':
      return (
        <Svg width={24} height={24} viewBox="0 0 24 24">
          <Circle cx={5} cy={12} r={1.9} fill={ink} />
          <Circle cx={12} cy={12} r={1.9} fill={ink} />
          <Circle cx={19} cy={12} r={1.9} fill={ink} />
        </Svg>
      );
  }
}

export type FedName = 'Bored' | 'Lonely' | 'Stressed' | 'Tired' | 'Phone in bed' | 'Late night' | 'Sexual content' | 'Argument' | 'Not sure';

/** 98D's grid order, left to right and top to bottom. */
export const SLIP_FED: readonly FedName[] = ['Bored', 'Lonely', 'Stressed', 'Tired', 'Phone in bed', 'Late night', 'Sexual content', 'Argument', 'Not sure'];

/**
 * One tile of the grid. Unlike the urge log's, this label changes SIZE as well
 * as weight when it is picked — 13.5/500 at rest, 14/600 selected — which the
 * previous bundle did not do.
 */
export function SlipFedTile({ name, selected, onPress, width }: { name: FedName; selected: boolean; onPress: () => void; width: number }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="checkbox"
      accessibilityState={{ checked: selected }}
      style={{
        width,
        height: 112,
        minHeight: 0,
        borderRadius: 18,
        backgroundColor: '#FFFFFF',
        boxShadow: selected ? '0 0 0 1.8px #131313' : '0 0 0 1px rgba(0,0,0,0.10)',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
      }}>
      <View style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: selected ? '#131313' : '#F1EFE9', alignItems: 'center', justifyContent: 'center' }}>
        <FedGlyph name={name} on={selected} />
      </View>
      <AppText style={[sans(selected ? '600' : '500'), { fontSize: selected ? 14 : 13.5, color: INK }]}>{name}</AppText>
    </PressScale>
  );
}

// ═══ 98E · logged ════════════════════════════════════════════════════

/**
 * A row of the logged card. 98E adds three things `Lapse Done` never stated:
 * a 14pt gap, a label that cannot shrink, and a value that is right-aligned,
 * leaded at 19 and clamped to 200 — so a long trigger join wraps to a second
 * right-aligned line instead of pushing the label out of the row.
 */
export function SlipSummaryRow({ label, value, last = false }: { label: string; value: string; last?: boolean }) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 14,
        paddingVertical: 15,
        borderBottomWidth: last ? 0 : 1,
        borderBottomColor: 'rgba(0,0,0,0.06)',
      }}>
      <AppText style={[sans('600'), { flexShrink: 0, fontSize: 12.5, color: GHOST }]}>{label}</AppText>
      <AppText style={[sans('500'), { maxWidth: 200, textAlign: 'right', fontSize: 14.5, lineHeight: 19, color: INK }]}>{value}</AppText>
    </View>
  );
}

// ═══ 98F · do you still want to keep watching ════════════════════════

/**
 * A 64pt answer row with a bare 22pt dot on the right — no leading icon tile,
 * which is what separates it from the urge log's outcome rows. The dot is a
 * 2pt inset ring at rest and a filled disc with a check when picked.
 */
export function SlipAnswerRow({ label, selected, top, onPress }: { label: string; selected: boolean; top: number; onPress: () => void }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ checked: selected }}
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        top,
        height: 64,
        minHeight: 0,
        borderRadius: 18,
        backgroundColor: '#FFFFFF',
        boxShadow: selected ? '0 0 0 1.8px #131313' : '0 0 0 1px rgba(0,0,0,0.10)',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 14,
        paddingHorizontal: 20,
      }}>
      <AppText style={[sans(selected ? '600' : '500'), { flex: 1, fontSize: 15, color: INK }]}>{label}</AppText>
      <View
        style={{
          width: 22,
          height: 22,
          borderRadius: 11,
          flexShrink: 0,
          backgroundColor: selected ? '#131313' : undefined,
          boxShadow: selected ? undefined : 'inset 0 0 0 2px rgba(0,0,0,0.18)',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        {selected ? (
          <Svg width={13} height={13} viewBox="0 0 24 24">
            <Path d="M5 12.5l4.5 4.5L19 7" fill="none" stroke="#FFFFFF" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        ) : null}
      </View>
    </PressScale>
  );
}

// ═══ 98J · the pledge still stands ═══════════════════════════════════

/**
 * The pledge card. 98J states no sheet at all — the content sits straight on
 * the frame — so its tops are frame-absolute and carry the 54pt bar off them.
 *
 * The pledge line is set in the frame's own system sans, not in a quote face:
 * the canvas declares no `font-family` on it, only 22/32 at −0.2. Reaching for
 * `fonts.quote` by analogy with the morning sheet would be wrong.
 *
 * `pledge` is required. It used to fall back to the canvas's own sample line,
 * which meant an account that had never written a pledge was shown one and told
 * it was theirs (D148). The screen is gated instead, so the card is only ever
 * drawn over words the user actually signed.
 */
export function SlipPledgeCard({ name, pledge }: { name?: string; pledge: string }) {
  // D130: a paint server's id is a name, not an identifier.
  const wash = `slipPledgeWash${useId().replace(/:/g, '')}`;
  return (
    <View
      style={{
        position: 'absolute',
        left: 36,
        right: 36,
        top: 240,
        height: 236,
        overflow: 'hidden',
        borderRadius: 18,
        borderCurve: 'continuous',
        backgroundColor: '#FFFFFF',
        boxShadow: '0 0 0 1px rgba(0,0,0,0.08), 0 10px 26px rgba(40,38,32,0.08)',
      }}>
      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
        <Svg width={180} height={180} style={{ position: 'absolute', right: -40, top: -52 }}>
          <Defs>
            <RadialGradient id={wash} cx="50%" cy="50%" r="50%">
              <Stop offset="0" stopColor="#E9D2A4" stopOpacity={0.34} />
              <Stop offset="0.74" stopColor="#E9D2A4" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={90} cy={90} rx={90} ry={90} fill={`url(#${wash})`} />
        </Svg>
        <View style={{ position: 'absolute', right: 28, top: 26, width: 30, height: 30, borderRadius: 15, backgroundColor: '#F0DDB4' }} />
        <Hill height={110} rise={50} color="#EFEEE9" style={{ position: 'absolute', left: -30, right: -30, bottom: -64 }} />
        <Hill height={110} rise={44} color="#E9E8E2" style={{ position: 'absolute', left: -60, right: -10, bottom: -78 }} />
      </View>
      {/* `Latest Vici FULL` replaced the typeset “ with a two-lobe glyph: 29 x 21
          drawn in a 44 x 32 box, so the mark no longer depends on whichever face
          the platform resolves for a bare quote character. */}
      {/* the canvas's box is 24 tall — the line box of an inline 21pt glyph, not
          the glyph itself — so the mark sits 1.5pt below its own top edge */}
      <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 42, height: 24, alignItems: 'center' }}>
        <Svg width={29} height={21} viewBox="0 0 44 32">
          <Path
            d="M9.8 0C4.2 3.4 0 9.6 0 16.9 0 26 5.4 32 12.4 32c5.4 0 9.3-3.8 9.3-9 0-5-3.6-8.6-8.4-8.6-.9 0-2 .2-2.6.4C11 10.1 14.1 5.4 18.3 2.9L9.8 0z"
            fill="#C9C0AC"
          />
          <Path
            d="M31.9 0c-5.6 3.4-9.8 9.6-9.8 16.9 0 9.1 5.4 15.1 12.4 15.1 5.4 0 9.3-3.8 9.3-9 0-5-3.6-8.6-8.4-8.6-.9 0-2 .2-2.6.4.3-4.7 3.4-9.4 7.6-11.9L31.9 0z"
            fill="#C9C0AC"
          />
        </Svg>
      </View>
      <AppText center style={[sans('500'), { position: 'absolute', left: 36, right: 36, top: 86, fontSize: 22, letterSpacing: -0.2, lineHeight: 32, color: '#3A3934' }, BALANCE]}>
        {pledge}
      </AppText>
      {/* the canvas puts an empty `<span>` opposite the signature to push it
          right — a flex spacer, so the row states `flex-end` instead.

          Neither the block nor the name carries a width in the canvas: only the
          rule does (`width:104px; margin-left:auto`), so the block is as wide as
          the NAME or the rule, whichever is greater. Both had a hard 104 here,
          which is invisible at “Jerry” and clips or wraps a first name that sets
          wider than 104pt at 26pt Snell Roundhand. The rule keeps its 104 and
          right-aligns itself; the name is left to its own width. */}
      <View style={{ position: 'absolute', left: 16, right: 20, bottom: 16, alignItems: 'flex-end' }}>
        <View>
          <AppText style={{ textAlign: 'right', fontFamily: fonts.script, fontSize: 26, lineHeight: 26, color: INK, transform: [{ rotate: '-3.5deg' }] }}>
            {name?.split(' ')[0] ?? 'You'}
          </AppText>
          <View style={{ marginTop: 5, marginLeft: 'auto', width: 104, height: 1, backgroundColor: 'rgba(0,0,0,0.2)' }} />
        </View>
      </View>
    </View>
  );
}

// ═══ 98K · begin again ═══════════════════════════════════════════════

const noiseDark = require('../../../assets/images/noise-dark.png');

/**
 * The 98K field: a four-stop dawn with the sun rising into a horizon band that
 * cuts every light source off at y 558.
 *
 * `Relapse Begin` — the older frame this one supersedes, still in the bundle and
 * still built at `/relapse` — hangs three rotated shafts of grain over the same
 * sky and a Back control over the same headline. 98K draws neither, so neither
 * is here. Its body also gained a stated `line-height: 21`.
 */
export function SlipBeginSky() {
  // D130: a paint server's id is a name, not an identifier.
  const uid = useId().replace(/:/g, '');
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
      <LinearGradient
        colors={['#F2E3D8', '#E4C6A8', '#FBFAF7', '#F0EFEB']}
        locations={[0, 0.39, 0.65, 0.82]}
        style={{ position: 'absolute', left: 0, top: 0, right: 0, bottom: 0 }}
      />

      {/* the canvas clips the sun and its halo at y 558 so the light stops at the water */}
      <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 558, overflow: 'hidden' }}>
        {/* the canvas states `left: 96`, not a centring — on a 393 frame a
            centred 200 box would land on 96.5 */}
        <View style={{ position: 'absolute', left: 96, top: 368, width: 200, height: 200, borderRadius: 100, overflow: 'hidden' }}>
          <Svg width={200} height={200}>
            <Defs>
              {/* radial-gradient(circle at 50% 30%, …) — farthest-corner radius from (100,60) in a 200 box */}
              <RadialGradient id={`slip-begin-sun${uid}`} cx={100} cy={60} r={172.05} gradientUnits="userSpaceOnUse">
                <Stop offset="0" stopColor="#FBF2E2" />
                <Stop offset="0.65" stopColor="#F0DBB4" />
                <Stop offset="1" stopColor="#DFC08B" />
              </RadialGradient>
            </Defs>
            <Rect x={0} y={0} width={200} height={200} fill={`url(#slip-begin-sun${uid})`} />
          </Svg>
          <Grain source={noiseDark} opacity={0.5} />
        </View>

        {/* no blur on this one in the canvas, so it is the literal two-stop ramp */}
        <Svg width={280} height={280} style={{ position: 'absolute', left: 56, top: 328 }}>
          <Defs>
            <RadialGradient id={`slip-begin-halo${uid}`} cx="50%" cy="50%" r="50%">
              <Stop offset="0" stopColor="#FAECD2" stopOpacity={0.5} />
              <Stop offset="0.72" stopColor="#FAECD2" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={140} cy={140} rx={140} ry={140} fill={`url(#slip-begin-halo${uid})`} />
        </Svg>
      </View>

      <LinearGradient
        colors={['rgba(255,255,255,0)', 'rgba(255,255,255,0.55)', 'rgba(255,255,255,0)']}
        locations={[0, 0.5, 1]}
        style={{ position: 'absolute', left: 0, right: 0, top: 542, height: 32 }}
      />

      <Grain source={noiseDark} opacity={0.1} />
    </View>
  );
}

export { BALANCE, GHOST, INK, MUTED, PAPER, PLAIN, PRETTY };
