import { useId } from 'react';
import { View, type ViewStyle } from 'react-native';
import Svg, { Defs, Ellipse, FeGaussianBlur, Filter, LinearGradient, RadialGradient, Rect, Stop } from 'react-native-svg';

import { Hill } from '@/components/ui';

/**
 * The post-slip drawings — canvas frames 98A–98L, 99A–99H and 100A–100K.
 *
 * Twenty-one of the group's frames draw an illustration, and between them they
 * use only sixteen pictures: six pairs and one three-way clone ship the same
 * artwork under two or three different headlines (`Slip Feel Lonely`,
 * `Slip Trigger Loneliness` and `Slip Trigger Argument` are byte-identical).
 * They are keyed by picture here rather than by frame, so a clone is one entry
 * and the duplication stays visible instead of being copied out four times.
 *
 * Every picture is a 240 × 200 slot of absolutely positioned boxes. The canvas
 * clips it (`overflow:hidden`), which two of them lean on: `nighthills` and
 * `sunhills` put a ground shadow at y 196 and y 192 so only 4 and 8 of its 13
 * points survive. The clip is reproduced, so is the survivor.
 */

const abs = (l: number, t: number, w: number, h: number, s?: ViewStyle): ViewStyle => ({ position: 'absolute', left: l, top: t, width: w, height: h, ...s });

/**
 * A paint server's id is a name, not an identifier (D130). On web a `<Defs>` is
 * a document-wide `<…gradient id>`, and expo-router keeps the screen a push came
 * from mounted underneath with `display: none` — so a second copy of the same
 * picture makes `url(#…)` bind to the hidden one, which paints nothing. Mixing
 * the mount's own `useId()` in keeps every instance its own.
 */
const usePaintId = (name: string) => `${name}-${useId().replace(/:/g, '')}`;

/**
 * `radial-gradient(closest-side, rgba(226,186,120,α), rgba(226,186,120,0) 74%)`
 * in a round box, under `filter: blur(4px)`.
 *
 * D010 used to absorb that blur on the grounds that a `closest-side` ramp has
 * no hard edge to feather. **D151 retires the exemption**, and it is right about
 * where the difference lives: a Gaussian does not only soften the boundary, it
 * flattens the CORE, because the kernel pulls the low-alpha ring inward over the
 * peak. Measured here per pixel over each glow's own box, nothing masked — the
 * unblurred ramp was worst 6/255 on `Slip Morning After`'s 140pt wash (alpha
 * 0.5) and 5/255 on `Slip Entry`'s 124pt one, both in the core, and the 100pt
 * 0.35 washes were already inside 2/255. Small, but it is a real error in the
 * region D010 argued was safe, so the wash gets the canvas's own Gaussian like
 * everything else.
 *
 * Both stops name the same RGB, which is D105's rule and what keeps the ramp
 * from darkening as it fades.
 */
function Glow({ id, l, t, size, alpha, blur = 4 }: { id: string; l: number; t: number; size: number; alpha: number; blur?: number }) {
  const uid = usePaintId(id);
  const pad = 3 * blur;
  return (
    <Svg width={size + 2 * pad} height={size + 2 * pad} style={{ position: 'absolute', left: l - pad, top: t - pad }}>
      <Defs>
        <RadialGradient id={`${uid}r`} cx="50%" cy="50%" r="50%">
          <Stop offset="0" stopColor="#E2BA78" stopOpacity={alpha} />
          <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
        </RadialGradient>
        <Filter id={`${uid}f`} x="-200%" y="-200%" width="500%" height="500%" {...({ colorInterpolationFilters: 'sRGB' } as object)}>
          <FeGaussianBlur stdDeviation={String(blur)} />
        </Filter>
      </Defs>
      <Ellipse cx={pad + size / 2} cy={pad + size / 2} rx={size / 2} ry={size / 2} fill={`url(#${uid}r)`} filter={`url(#${uid}f)`} />
    </Svg>
  );
}

/**
 * The ground shadow is a flat `rgba(0,0,0,α)` ellipse under `filter: blur(N)` —
 * a blurred SOLID, not a blurred gradient, so D010 does not cover it and the
 * radial that stood in for it here was wrong in both directions (F26): a 13pt
 * shape under a 5px blur never reaches its stated alpha, and its falloff runs
 * on well outside its own box. Measured on `Slip Entry` down the centre of the
 * shadow, design against the radial: y388 232/243, y392 225/220, y400 231/239,
 * y408 242/244 — a foot half as tall and a quarter too dark.
 *
 * D091/D113: `react-native-svg` 15.15.4 ships `<FeGaussianBlur>` on all three
 * targets, so the layer is simply drawn as the canvas states it. `filter:
 * blur(r)` states σ directly (a `box-shadow`'s blur radius is 2σ), so `blur`
 * goes straight into `stdDeviation`. The `<Svg>` is grown 3σ each way and hung
 * back off the canvas's own origin, or the filter clips itself square; the
 * colour space is stated because an SVG filter defaults to linearRGB where
 * CSS's `blur()` composites in sRGB (F43).
 *
 * The declared consequence is D091's: each shadow reports one signature row 3σ
 * larger than the frame's own div, because the div is not what the canvas
 * paints. Where the 240 × 200 slot's `overflow:hidden` cuts the shadow — 98L
 * and 99G — it now cuts a diffuse smear, which is what the canvas cuts.
 */
function Shade({ id, l, t, w, h, alpha = 0.1, blur = 5 }: { id: string; l: number; t: number; w: number; h: number; alpha?: number; blur?: number }) {
  const uid = usePaintId(id);
  const pad = 3 * blur;
  return (
    <Svg width={w + 2 * pad} height={h + 2 * pad} style={{ position: 'absolute', left: l - pad, top: t - pad }}>
      <Defs>
        <Filter id={uid} x="-200%" y="-200%" width="500%" height="500%" {...({ colorInterpolationFilters: 'sRGB' } as object)}>
          <FeGaussianBlur stdDeviation={String(blur)} />
        </Filter>
      </Defs>
      <Ellipse cx={pad + w / 2} cy={pad + h / 2} rx={w / 2} ry={h / 2} fill="#000000" fillOpacity={alpha} filter={`url(#${uid})`} />
    </Svg>
  );
}

/** `linear-gradient(180deg, A, B)` on a rounded box. */
function VGrad({ id, l, t, w, h, r, from, to }: { id: string; l: number; t: number; w: number; h: number; r: number; from: string; to: string }) {
  const uid = usePaintId(id);
  return (
    <Svg width={w} height={h} style={{ position: 'absolute', left: l, top: t }}>
      <Defs>
        <LinearGradient id={uid} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={from} />
          <Stop offset="1" stopColor={to} />
        </LinearGradient>
      </Defs>
      <Rect x={0} y={0} width={w} height={h} rx={r} ry={r} fill={`url(#${uid})`} />
    </Svg>
  );
}

/** `linear-gradient(90deg, C, transparent)` — the light through the open door. */
function HGrad({ id, l, t, w, h, from }: { id: string; l: number; t: number; w: number; h: number; from: string }) {
  const uid = usePaintId(id);
  return (
    <Svg width={w} height={h} style={{ position: 'absolute', left: l, top: t }}>
      <Defs>
        <LinearGradient id={uid} x1="0" y1="0" x2="1" y2="0">
          <Stop offset="0" stopColor={from} stopOpacity={0.55} />
          <Stop offset="1" stopColor={from} stopOpacity={0} />
        </LinearGradient>
      </Defs>
      <Rect x={0} y={0} width={w} height={h} fill={`url(#${uid})`} />
    </Svg>
  );
}

/**
 * The moon: a pale disc with a duller one slid down and right behind it. Every
 * moon in the group is that same `+8 / +6` offset, at 24, 26, 30 or 34 across.
 */
function Moon({ l, t, size }: { l: number; t: number; size: number }) {
  return (
    <>
      <View style={abs(l + 8, t + 6, size, size, { borderRadius: size / 2, backgroundColor: '#DCDED8' })} />
      <View style={abs(l, t, size, size, { borderRadius: size / 2, backgroundColor: '#F4F3F0' })} />
    </>
  );
}

/** One 2 × 2 spark. The group states its alpha per speck, so it is a prop. */
function Speck({ l, t, alpha }: { l: number; t: number; alpha: number }) {
  return <View style={abs(l, t, 2, 2, { borderRadius: 1, backgroundColor: `rgba(200,225,235,${alpha})` })} />;
}

/**
 * A rotation the canvas hangs off a corner or an edge. RN rotates about the
 * box's centre and has no origin token, so the rotation is bracketed by the
 * centre-to-origin offset and its inverse.
 */
const spin = (deg: number, dx: number, dy: number) =>
  [{ translateX: dx }, { translateY: dy }, { rotate: `${deg}deg` }, { translateX: -dx }, { translateY: -dy }] as ViewStyle['transform'];

export type SlipArtName =
  | 'phoneflat'
  | 'phoneup'
  | 'dominoes'
  | 'screendark'
  | 'tvnight'
  | 'sunhills'
  | 'cards'
  | 'steps'
  | 'bubbles'
  | 'deskclock'
  | 'phonerays'
  | 'bed'
  | 'nighthills'
  | 'dots'
  | 'door'
  | 'rings';

/** The 240 × 200 illustration slot. `top` is per frame — it is never the same twice running. */
export function SlipArt({ name, top }: { name: SlipArtName; top: number }) {
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 76, top, width: 240, height: 200 }}>
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
        <Picture name={name} />
      </View>
    </View>
  );
}

function Picture({ name }: { name: SlipArtName }) {
  switch (name) {
    // 98A · Slip Entry, 100A · Slip Trigger Late night — the phone face down under a moon.
    case 'phoneflat':
      return (
        <>
          <Glow id="slip-phoneflat-glow" l={64} t={50} size={124} alpha={0.35} />
          <Moon l={16} t={10} size={34} />
          <View style={abs(96, 150, 66, 14, { borderRadius: 5, backgroundColor: '#3A3934' })} />
          <View style={abs(104, 153, 20, 3, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.3)' })} />
          <Shade id="slip-phoneflat-shade" l={84} t={166} w={96} h={13} />
          <Speck l={200} t={28} alpha={0.35} />
          <Speck l={10} t={60} alpha={0.3} />
        </>
      );

    // 98B · Slip Close It, 100B · Slip Trigger Scrolling — the phone standing, lit.
    case 'phoneup':
      return (
        <>
          <Glow id="slip-phoneup-glow" l={50} t={44} size={120} alpha={0.35} />
          <Moon l={12} t={8} size={34} />
          <View style={abs(150, 44, 54, 134, { borderRadius: 8, backgroundColor: '#E4E3DE' })} />
          <VGrad id="slip-phoneup-screen" l={156} t={50} w={38} h={122} r={5} from="#3A3934" to="#2E2C29" />
          <View style={abs(167, 96, 20, 3, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.4)' })} />
          <Shade id="slip-phoneup-shade" l={140} t={178} w={80} h={13} />
          <Speck l={216} t={24} alpha={0.35} />
          <Speck l={8} t={52} alpha={0.3} />
        </>
      );

    // 98G · Slip Dont Fail Twice — one domino down, one still standing.
    case 'dominoes':
      return (
        <>
          <Glow id="slip-dominoes-glow" l={70} t={52} size={130} alpha={0.38} />
          <Moon l={12} t={8} size={34} />
          <Shade id="slip-dominoes-fallen" l={34} t={158} w={78} h={16} />
          <View style={abs(42, 118, 18, 66, { borderRadius: 6, backgroundColor: '#C6C5C0', transform: spin(76, 9, 33) })} />
          <View style={abs(112, 144, 14, 28, { borderRadius: 4, backgroundColor: '#B4B1AB' })} />
          <Shade id="slip-dominoes-standing" l={150} t={162} w={44} h={12} alpha={0.14} blur={4} />
          <View style={abs(152, 100, 20, 68, { borderRadius: 6, backgroundColor: '#3A3934' })} />
          <View style={abs(157, 110, 10, 3, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.35)' })} />
        </>
      );

    // 98H · Slip Stop Here — the screen and the bar under it, going dark.
    case 'screendark':
      return (
        <>
          <Glow id="slip-screendark-glow" l={58} t={40} size={126} alpha={0.35} />
          <View style={abs(60, 52, 120, 96, { borderRadius: 12, backgroundColor: '#E4E3DE' })} />
          <View style={abs(68, 60, 104, 80, { borderRadius: 8, backgroundColor: '#EFEEE9' })} />
          <View style={abs(48, 88, 144, 16, { borderRadius: 8, backgroundColor: '#3A3934' })} />
          <View style={abs(58, 92, 24, 4, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.3)' })} />
          <Shade id="slip-screendark-shade" l={58} t={152} w={124} h={13} />
          <Moon l={188} t={10} size={26} />
          <Speck l={24} t={26} alpha={0.35} />
        </>
      );

    // 98I · Slip Third — the only dark frame. The canvas paints this one's wash
    // EIGHTH of eleven, not first: it composites over the set's top-right
    // corner rather than sitting behind it. Child order is literal here.
    case 'tvnight':
      return (
        <>
          <View style={abs(60, 90, 120, 64, { borderRadius: 10, backgroundColor: '#2E2C29' })} />
          <View style={abs(68, 98, 104, 48, { borderRadius: 7, backgroundColor: '#1B1A18' })} />
          <View style={abs(88, 114, 64, 13, { borderRadius: 5, backgroundColor: '#3F3D39' })} />
          <View style={abs(96, 117, 18, 3, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.22)' })} />
          <View style={abs(112, 158, 16, 4, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.14)' })} />
          <Moon l={22} t={10} size={30} />
          <Glow id="slip-tvnight-glow" l={120} t={10} size={120} alpha={0.16} />
          <Speck l={200} t={30} alpha={0.5} />
          <Speck l={180} t={64} alpha={0.35} />
          <Speck l={16} t={70} alpha={0.4} />
        </>
      );

    // 98L · Slip Morning After — the sun clearing two hills. The ground shadow
    // is painted SEVENTH of eight, over the front hill's skirt, and 8 of its 13
    // points fall outside the clip. Both are the canvas's, and both stand.
    case 'sunhills':
      return (
        <>
          <Glow id="slip-sunhills-glow" l={70} t={20} size={140} alpha={0.5} />
          <View style={abs(102, 42, 40, 40, { borderRadius: 20, backgroundColor: '#E9D2A4' })} />
          <Hill height={120} rise={56} color="#DEDDD6" style={{ position: 'absolute', left: -40, top: 110, width: 190 }} />
          <Hill height={120} rise={48} color="#CFCEC7" style={{ position: 'absolute', left: 90, top: 128, width: 200 }} />
          <View style={abs(36, 150, 13, 4, { borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.55)' })} />
          <View style={abs(62, 138, 13, 4, { borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.55)' })} />
          <Shade id="slip-sunhills-shade" l={40} t={192} w={160} h={13} />
          <Speck l={210} t={20} alpha={0.3} />
        </>
      );

    // 99A · Slip Feel Ashamed — three cards face down, one marked.
    case 'cards':
      return (
        <>
          <Glow id="slip-cards-glow" l={66} t={44} size={124} alpha={0.35} />
          <View style={abs(70, 118, 100, 16, { borderRadius: 5, backgroundColor: '#D6D5D0' })} />
          <View style={abs(80, 102, 100, 16, { borderRadius: 5, backgroundColor: '#E4E3DE' })} />
          <View style={abs(74, 86, 96, 16, { borderRadius: 5, backgroundColor: '#EDECE7' })} />
          <View style={abs(120, 90, 8, 8, { borderRadius: 2, backgroundColor: '#E9D2A4' })} />
          <Moon l={190} t={10} size={26} />
          <Shade id="slip-cards-shade" l={66} t={140} w={120} h={13} />
          <Speck l={30} t={34} alpha={0.35} />
        </>
      );

    // 99B · Slip Feel Bored, 100D · Slip Trigger Boredom — four rungs climbing.
    case 'steps':
      return (
        <>
          <Glow id="slip-steps-glow" l={120} t={14} size={100} alpha={0.35} />
          <View style={abs(40, 146, 150, 12, { borderRadius: 6, backgroundColor: '#D6D5D0' })} />
          <View style={abs(76, 116, 120, 12, { borderRadius: 6, backgroundColor: '#DCDBD5' })} />
          <View style={abs(112, 86, 120, 12, { borderRadius: 6, backgroundColor: '#E4E3DE' })} />
          <View style={abs(148, 56, 120, 12, { borderRadius: 6, backgroundColor: '#EDECE7' })} />
          <View style={abs(186, 24, 22, 22, { borderRadius: 11, backgroundColor: '#E9D2A4' })} />
          <Shade id="slip-steps-shade" l={36} t={168} w={150} h={13} />
        </>
      );

    // 99C · Slip Feel Lonely, 100E · Loneliness, 100G · Argument — two bubbles,
    // one pale and empty, one inked and answering. The canvas ships the same
    // drawing under all three headlines.
    case 'bubbles':
      return (
        <>
          <Glow id="slip-bubbles-glow" l={60} t={30} size={120} alpha={0.35} />
          <View style={abs(52, 66, 86, 53, { borderRadius: 24, backgroundColor: '#E4E3DE' })} />
          <View style={abs(112, 96, 96, 60, { borderRadius: 27, backgroundColor: '#3A3934' })} />
          <View style={abs(128, 124, 40, 5, { borderRadius: 2.5, backgroundColor: 'rgba(244,243,240,0.35)' })} />
          <View style={abs(128, 136, 26, 5, { borderRadius: 2.5, backgroundColor: 'rgba(244,243,240,0.25)' })} />
          <Shade id="slip-bubbles-shade" l={64} t={166} w={140} h={13} />
          <Speck l={26} t={30} alpha={0.35} />
          <Speck l={206} t={50} alpha={0.3} />
        </>
      );

    // 99D · Slip Feel Stressed, 100F · Slip Trigger Stress — the document and the clock.
    case 'deskclock':
      return (
        <>
          <Glow id="slip-deskclock-glow" l={56} t={36} size={126} alpha={0.35} />
          <View
            style={abs(60, 56, 96, 88, {
              borderRadius: 12,
              backgroundColor: '#FFFFFF',
              boxShadow: '0 0 0 1px rgba(0,0,0,0.08), 0 8px 18px rgba(40,38,32,0.10)',
            })}
          />
          <View style={abs(74, 74, 52, 7, { borderRadius: 3.5, backgroundColor: '#D6D5D0' })} />
          <View style={abs(74, 92, 64, 7, { borderRadius: 3.5, backgroundColor: '#E4E3DE' })} />
          <View style={abs(74, 112, 14, 14, { borderRadius: 4, boxShadow: 'inset 0 0 0 2.5px #C6C5C0' })} />
          <View style={abs(152, 36, 52, 52, { borderRadius: 26, backgroundColor: '#FBFAF7', boxShadow: 'inset 0 0 0 5px #E4E3DE' })} />
          <View style={abs(176, 48, 3, 18, { borderRadius: 2, backgroundColor: '#B4B1AB', transform: spin(45, 0, 9) })} />
          <Shade id="slip-deskclock-shade" l={62} t={150} w={110} h={13} />
        </>
      );

    // 99E · Slip Feel Rejected, 100C · Slip Trigger Sexual content — the phone
    // going off face down, three short rays over it.
    case 'phonerays':
      return (
        <>
          <Glow id="slip-phonerays-glow" l={64} t={40} size={126} alpha={0.35} />
          <View style={abs(86, 132, 66, 14, { borderRadius: 5, backgroundColor: '#3A3934' })} />
          <View style={abs(94, 135, 20, 3, { borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.3)' })} />
          <View style={abs(70, 112, 12, 4, { borderRadius: 2, backgroundColor: '#C6C5C0', transform: [{ rotate: '-30deg' }] })} />
          <View style={abs(160, 108, 12, 4, { borderRadius: 2, backgroundColor: '#C6C5C0', transform: [{ rotate: '30deg' }] })} />
          <View style={abs(118, 98, 4, 12, { borderRadius: 2, backgroundColor: '#C6C5C0' })} />
          <Shade id="slip-phonerays-shade" l={76} t={150} w={96} h={13} />
          <Moon l={16} t={8} size={34} />
          <Speck l={206} t={36} alpha={0.35} />
        </>
      );

    // 99F · Slip Feel Tired, 100H · Slip Trigger Couldn’t sleep — a bed under a moon.
    case 'bed':
      return (
        <>
          <Glow id="slip-bed-glow" l={56} t={50} size={126} alpha={0.35} />
          <Moon l={14} t={6} size={34} />
          <View style={abs(70, 118, 100, 32, { borderTopLeftRadius: 10, borderTopRightRadius: 10, borderBottomLeftRadius: 4, borderBottomRightRadius: 4, backgroundColor: '#E0DFDA' })} />
          <View style={abs(76, 110, 50, 16, { borderRadius: 8, backgroundColor: '#C6C5C0' })} />
          <View style={abs(64, 118, 6, 54, { borderRadius: 3, backgroundColor: '#D6D5D0' })} />
          <View style={abs(170, 118, 6, 54, { borderRadius: 3, backgroundColor: '#D6D5D0' })} />
          <Shade id="slip-bed-shade" l={58} t={170} w={130} h={13} />
          <Speck l={206} t={30} alpha={0.35} />
          <Speck l={190} t={70} alpha={0.25} />
        </>
      );

    // 99G · Slip Feel Turned on — two cool hills at night. Its ground shadow
    // sits at y 196, so 4 of its 13 points are all the clip lets through.
    case 'nighthills':
      return (
        <>
          <Glow id="slip-nighthills-glow" l={110} t={20} size={110} alpha={0.3} />
          <Hill height={120} rise={70} color="#DCE1E4" style={{ position: 'absolute', left: -40, top: 120, width: 180 }} />
          <Hill height={120} rise={60} color="#CFD6DA" style={{ position: 'absolute', left: 80, top: 140, width: 200 }} />
          <Moon l={152} t={20} size={30} />
          <Shade id="slip-nighthills-shade" l={30} t={196} w={180} h={13} />
          <Speck l={60} t={40} alpha={0.35} />
        </>
      );

    // 99H · Slip Feel Not sure, 100K · Slip Trigger Not sure — four dots rising.
    case 'dots':
      return (
        <>
          <Glow id="slip-dots-glow" l={80} t={30} size={120} alpha={0.35} />
          <View style={abs(40, 142, 12, 12, { borderRadius: 6, backgroundColor: '#E4E3DE' })} />
          <View style={abs(84, 120, 14, 14, { borderRadius: 7, backgroundColor: '#DCDBD5' })} />
          <View style={abs(128, 98, 16, 16, { borderRadius: 8, backgroundColor: '#C6C5C0' })} />
          <View style={abs(172, 76, 18, 18, { borderRadius: 9, backgroundColor: '#3A3934' })} />
          <Shade id="slip-dots-shade" l={40} t={168} w={150} h={13} />
          <Moon l={188} t={10} size={26} />
          <Speck l={28} t={40} alpha={0.35} />
        </>
      );

    // 100I · Slip Trigger Being alone — a door ajar with light spilling out.
    // Not the Rough Days `stepout` door: that one wedges its light as a polygon
    // and adds shoes and a plant this frame has none of.
    case 'door':
      return (
        <>
          <Glow id="slip-door-glow" l={120} t={30} size={120} alpha={0.35} />
          <View style={abs(84, 44, 84, 120, { borderRadius: 10, backgroundColor: '#E4E3DE' })} />
          <View
            style={abs(92, 52, 56, 112, {
              borderTopLeftRadius: 6,
              borderBottomLeftRadius: 6,
              backgroundColor: '#F7F6F2',
              transform: [{ translateX: -28 }, { skewY: '-4deg' }, { translateX: 28 }],
            })}
          />
          <HGrad id="slip-door-light" l={150} t={56} w={26} h={100} from="#E9D2A4" />
          <View style={abs(100, 104, 7, 7, { borderRadius: 3.5, backgroundColor: '#B4B1AB' })} />
          <Shade id="slip-door-shade" l={80} t={166} w={110} h={13} />
          <Speck l={30} t={40} alpha={0.35} />
        </>
      );

    // 100J · Slip Trigger Habit — a run of rings, three square on the line and
    // two tipping off it.
    case 'rings':
      return (
        <>
          <Glow id="slip-rings-glow" l={60} t={44} size={124} alpha={0.35} />
          <View style={abs(44, 118, 20, 20, { borderRadius: 10, boxShadow: 'inset 0 0 0 4px #C6C5C0' })} />
          <View style={abs(78, 116, 20, 20, { borderRadius: 10, boxShadow: 'inset 0 0 0 4px #C6C5C0' })} />
          <View style={abs(112, 114, 20, 20, { borderRadius: 10, boxShadow: 'inset 0 0 0 4px #C6C5C0' })} />
          <View style={abs(172, 106, 20, 20, { borderRadius: 10, boxShadow: 'inset 0 0 0 4px #E4E3DE', transform: [{ rotate: '12deg' }] })} />
          <View style={abs(206, 110, 20, 20, { borderRadius: 10, boxShadow: 'inset 0 0 0 4px #E4E3DE', transform: [{ rotate: '22deg' }] })} />
          <Shade id="slip-rings-shade" l={48} t={150} w={160} h={13} />
          <Moon l={192} t={8} size={24} />
          <Speck l={24} t={28} alpha={0.35} />
        </>
      );
  }
}
