/**
 * Auth kit — the pieces the auth boards share.
 *
 * `Latest Vici FULL` turns the front door around. Where the previous bundle
 * drew `02 · Login` on warm paper with the envelope mark, this one draws the
 * same board on the splash's night field — the #131313 → #2E2C29 gradient, two
 * soft washes, four 2px stars — under the laurel. It then adds `03 · Welcome
 * Back`, the same composition with four strings changed, so the two doors are
 * one component with a variant rather than two boards that drift apart.
 *
 * The boards *behind* the doors — the address step, the password step, the
 * verification code, create-account — have no frame in this bundle and never
 * did in the last one. They are dressed in the night vocabulary the funnel
 * states on `04 · V3 Q24 Name`, which is the screen family they sit between:
 * the 0.75-alpha Back row, the 60-tall field on `rgba(255,255,255,0.07)` under
 * a `rgba(255,255,255,0.22)` hairline, and the paper-white 58/29 pill. See the
 * report for that reading — the alternative was leaving them on cream, one tap
 * from a night door and one tap before a night funnel.
 *
 * The canvas frame is 393 × 852 and its status bar ends at 54, so every design
 * y quoted below is already the offset under the safe area (D009).
 */

import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { useId, useState, type ReactNode } from 'react';
import { Platform, ScrollView, TextInput, View, type TextInputProps } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Defs, Ellipse, Path, RadialGradient, Stop } from 'react-native-svg';

import { AppText } from '@/components/ui';
import { PressScale } from '@/components/ui/press-scale';
import { colors, sans, spacing } from '@/lib/theme';

const laurelMark = require('../../../assets/images/laurel-mark.webp');

// ── the night palette the two doors and the funnel share ─────────────
const PAPER = '#F4F3F0';
const INK = '#131313';
/** `rgba(244,243,240,α)` — the door frames write the paper white at nine alphas. */
const paper = (a: number) => `rgba(244,243,240,${a})`;

/** Chrome's own default; AppText asks for `pretty` on web, the canvas does not. */
const WRAP = Platform.OS === 'web' ? ({ textWrap: 'wrap' } as object) : null;

// ── provider marks, copied from the canvas ───────────────────────────
export const AppleMark = ({ color }: { color: string }) => (
  <Svg width={15} height={18} viewBox="0 0 384 512">
    <Path
      fill={color}
      d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.9-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"
    />
  </Svg>
);

export const GoogleMark = () => (
  <Svg width={17} height={17} viewBox="0 0 48 48">
    <Path
      fill="#EA4335"
      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
    />
    <Path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
    <Path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
    <Path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
  </Svg>
);

/**
 * One `radial-gradient(closest-side, c α, c 0 <fade>%)` wash.
 *
 * The canvas blurs each of these by 5–8px and RN SVG has no filter, but a
 * closest-side radial already dies at its own edge so there is no hard edge for
 * the blur to soften (D010).
 *
 * Two stops, not the three D010 prescribes. CSS interpolates a gradient in
 * premultiplied alpha, and both of these stops name the same RGB, so the ramp
 * between them is linear in alpha and an SVG two-stop radial reproduces it
 * exactly. Measured on `02 · Login`: D010's `× 0.42` midpoint darkens the mark's
 * halo by up to 5/255 against the frame, and dropping it takes the whole mark
 * region to ≤1.
 *
 * The paint-server id is per instance, not per call site. On web a `<Defs>` is
 * a document-wide `<radialGradient id>`, and expo-router keeps the board a push
 * came from mounted underneath with `display:none` — so a second copy of this
 * field puts two `id="ad-warm"` in one document and `url(#ad-warm)` binds to
 * the first, which is the hidden one, and paints nothing. That is exactly what
 * `03 · Welcome Back` lost when it was reached the way the bundle designs it
 * (FINDINGS F20). `useId()` per mount is what the rest of the app already does (D130).
 */
function Wash({ id, x, y, w, h, color, opacity, fade }: { id: string; x: number; y: number; w: number; h: number; color: string; opacity: number; fade: number }) {
  const gid = `${id}-${useId().replace(/:/g, '')}`;
  return (
    <Svg width={w} height={h} style={{ position: 'absolute', left: x, top: y }}>
      <Defs>
        <RadialGradient id={gid} cx="50%" cy="50%" rx="50%" ry="50%">
          <Stop offset="0" stopColor={color} stopOpacity={opacity} />
          <Stop offset={fade / 100} stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Ellipse cx={w / 2} cy={h / 2} rx={w / 2} ry={h / 2} fill={`url(#${gid})`} />
    </Svg>
  );
}

/**
 * The night field both doors stand on — `02 · Login` and `03 · Welcome Back`
 * state it identically, and it is the splash's own gradient.
 *
 * Offsets are the frame's, measured from the top of the frame rather than from
 * the safe area: the field paints under the status bar, so its 120 is a
 * literal 120 while the content above it is design y minus 54. The lower wash
 * is anchored to the bottom edge (design top 620 + 260 tall in an 852 frame →
 * bottom −28) so it stays with the edge on a taller screen (D026).
 */
export function AuthNightField() {
  return (
    <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
      <LinearGradient
        colors={['#131313', '#1D1C1A', '#2E2C29']}
        locations={[0, 0.55, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />
      <Wash id="ad-warm" x={82} y={120} w={230} h={230} color="#E2BE8C" opacity={0.13} fade={72} />
      <View style={{ position: 'absolute', left: -60, bottom: -28, width: 420, height: 260 }}>
        <Wash id="ad-low" x={0} y={0} w={420} h={260} color="#787369" opacity={0.14} fade={72} />
      </View>
      {/* four 2px stars, `rgba(160,155,145,α)` */}
      <Star x={96} y={110} opacity={0.25} />
      <Star x={318} y={168} opacity={0.2} />
      <Star x={256} y={96} opacity={0.18} />
      <Star x={44} y={236} opacity={0.16} />
    </View>
  );
}

function Star({ x, y, opacity }: { x: number; y: number; opacity: number }) {
  return <View style={{ position: 'absolute', left: x, top: y, width: 2, height: 2, borderRadius: 1, backgroundColor: `rgba(160,155,145,${opacity})` }} />;
}

/**
 * The door's mark: a 150 × 150 block centred on the frame, holding a 190 wash
 * and the 96px laurel, both centred on the block's own centre. The wash
 * overflows the block — the canvas puts no `overflow:hidden` on it.
 */
export const AUTH_MARK = 150;

export function AuthMark() {
  return (
    <View style={{ width: AUTH_MARK, height: AUTH_MARK }}>
      <Wash id="ad-mark" x={-20} y={-20} w={190} h={190} color="#E2BA78" opacity={0.16} fade={72} />
      {/* `contentFit: fill`, not `contain`: the canvas sets the mark with an
          <img width="96" height="96"> and no object-fit, so the browser stretches
          the 280 × 252 asset into a square and the laurel is 11% taller than its
          own aspect. Fitting it would draw a 96 × 86 mark the frame does not. */}
      <Image source={laurelMark} tintColor="#FFFFFF" contentFit="fill" style={{ position: 'absolute', left: 27, top: 27, width: 96, height: 96, opacity: 0.95 }} />
    </View>
  );
}

/** The two doors, and the four strings that separate them. */
export type AuthDoorVariant = 'new' | 'returning';

const DOOR = {
  new: {
    title: 'Welcome to VICI.',
    subtitle: 'Sign in or create an account to keep your plan and progress.',
    email: 'Continue with email',
    footer: 'Already have an account? ',
    footerLink: 'Sign in',
  },
  returning: {
    title: 'Welcome back.',
    subtitle: 'Sign in to pick up where you left off.',
    email: 'Sign in with email',
    footer: 'New here? ',
    footerLink: 'Create an account',
  },
} as const;

/**
 * `02 · Login` and `03 · Welcome Back` — a fixed composition at the canvas's
 * own offsets, design y minus 54.
 *
 * Every control the canvas marks `cursor:pointer` is a control: both provider
 * pills, the arrow button on the email row, and the footer link. The
 * "Terms · Privacy" line carries none, and is drawn as the caption it is
 * (D013/D021).
 */
export function AuthDoor({
  variant,
  onApple,
  onGoogle,
  onEmail,
  onFooter,
  onBack,
  loading,
  message,
}: {
  variant: AuthDoorVariant;
  onApple: () => void;
  onGoogle: () => void;
  onEmail: () => void;
  onFooter: () => void;
  /** The canvas draws no Back here; see the call site for when one is shown. */
  onBack?: () => void;
  loading?: boolean;
  message?: ReactNode;
}) {
  const copy = DOOR[variant];
  return (
    <View style={{ flex: 1, backgroundColor: INK }}>
      <AuthNightField />
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
        <View style={{ flex: 1 }}>
          {onBack ? (
            <View style={{ position: 'absolute', left: 0, top: 40, zIndex: 5 }}>
              <AuthBack onPress={onBack} />
            </View>
          ) : null}

          {/* design y 170 — the block is centred, so the laurel lands on the
              frame's own axis rather than on a left offset */}
          <View style={{ position: 'absolute', left: 0, right: 0, top: 116, alignItems: 'center' }}>
            <AuthMark />
          </View>

          <AppText style={[sans('600'), { position: 'absolute', left: 24, top: 326, fontSize: 27, letterSpacing: -0.2, color: PAPER }]}>{copy.title}</AppText>
          {/* the frame states no `text-wrap`, so the line breaks where the box
              runs out; AppText's web default is `pretty`, which rebalances the
              last two lines and moves a word off the first.

              `right: 0` is the box the canvas actually renders, not a value it
              states. The frame writes `left: 24` alone and the browser
              shrink-to-fits the box to the space left in its containing block —
              measured 369 wide, i.e. 24 to the frame's own edge. Yoga has no
              shrink-to-fit: an absolute node with `left` and no `right`/`width`
              sizes to its CONTENT, so on device this sentence laid out on one
              line and ran off the screen. The title above needs no such anchor:
              its design box measures 205.8, its own content width. */}
          <AppText style={[sans('400'), { position: 'absolute', left: 24, right: 0, top: 366, fontSize: 14.5, color: paper(0.5) }, WRAP]}>{copy.subtitle}</AppText>

          <PressScale
            onPress={onApple}
            disabled={loading}
            accessibilityRole="button"
            style={{ position: 'absolute', left: 24, right: 24, top: 418, height: 54, minHeight: 0, borderRadius: 27, backgroundColor: PAPER, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 }}>
            <AppleMark color={INK} />
            <AppText style={[sans('600'), { fontSize: 16, color: INK }]}>Continue with Apple</AppText>
          </PressScale>

          <PressScale
            onPress={onGoogle}
            disabled={loading}
            accessibilityRole="button"
            style={{
              position: 'absolute',
              left: 24,
              right: 24,
              top: 484,
              height: 54,
              minHeight: 0,
              borderRadius: 27,
              backgroundColor: paper(0.08),
              boxShadow: `0 0 0 1px ${paper(0.2)}`,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 10,
            }}>
            <GoogleMark />
            <AppText style={[sans('600'), { fontSize: 16, color: PAPER }]}>Continue with Google</AppText>
          </PressScale>

          <View style={{ position: 'absolute', left: 24, right: 24, top: 560, flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <View style={{ flex: 1, height: 1, backgroundColor: paper(0.14) }} />
            <AppText style={[sans('500'), { fontSize: 12.5, color: paper(0.4) }]}>or</AppText>
            <View style={{ flex: 1, height: 1, backgroundColor: paper(0.14) }} />
          </View>

          {/* The canvas gives the row a static label and no caret — the board
              where an address is typed was withdrawn two bundles ago — and puts
              `cursor:pointer` on the arrow alone. The whole row is the target;
              a 40px circle is not one. */}
          <PressScale
            onPress={onEmail}
            accessibilityRole="button"
            accessibilityLabel={copy.email}
            style={{
              position: 'absolute',
              left: 24,
              right: 24,
              top: 588,
              height: 56,
              minHeight: 0,
              borderRadius: 16,
              backgroundColor: paper(0.06),
              boxShadow: `0 0 0 1px ${paper(0.16)}`,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 12,
              paddingLeft: 20,
              paddingRight: 8,
            }}>
            <AppText style={[sans('400'), { flex: 1, fontSize: 16.5, color: paper(0.45) }]}>{copy.email}</AppText>
            <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: PAPER, alignItems: 'center', justifyContent: 'center' }}>
              <Svg width={15} height={13} viewBox="0 0 16 14" fill="none">
                <Path d="M1.5 7h12M9 2.5L13.5 7 9 11.5" stroke={INK} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
            </View>
          </PressScale>

          {/* Nothing is drawn between the email row and the footer; an SSO
              failure has to say so somewhere, and this is the gap — 42pt of it,
              from the email row's own bottom edge at 644 to the footer at 686.
              The block is the gap, and the line is centred in it, so the two-line
              refusal the mock build returns clears both by 2pt instead of running
              its second line into "Already have an account?" (13/19 from 650 ends
              at 688, two under the footer). The canvas draws nothing here, so
              this is the app's own composition and not a frame number. */}
          <View style={{ position: 'absolute', left: 24, right: 24, top: 644, height: 42, justifyContent: 'center' }}>{message}</View>

          <PressScale
            onPress={onFooter}
            accessibilityRole="button"
            hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}
            style={{ position: 'absolute', left: 0, right: 0, top: 686, minHeight: 0, alignItems: 'center' }}>
            <AppText style={[sans('400'), { alignSelf: 'stretch', textAlign: 'center', fontSize: 13.5, color: paper(0.5) }]}>
              {copy.footer}
              <AppText style={[sans('600'), { fontSize: 13.5, color: PAPER }]}>{copy.footerLink}</AppText>
            </AppText>
          </PressScale>

          {/* design y 818 */}
          <AppText style={[sans('400'), { position: 'absolute', left: 0, right: 0, top: 764, textAlign: 'center', fontSize: 12, color: paper(0.35) }]}>
            Terms &nbsp;·&nbsp; Privacy
          </AppText>
        </View>
      </SafeAreaView>
    </View>
  );
}

/**
 * The Back row the inner boards open with — `04 · V3 Q24 Name`'s own: left 16,
 * design y 94, an 11 × 19 chevron at 2.4 and a 17px label, both at 0.75.
 */
export function AuthBack({ onPress }: { onPress: () => void }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel="Back"
      hitSlop={{ top: 12, bottom: 12, left: 16, right: 24 }}
      style={{ alignSelf: 'flex-start', height: 40, minHeight: 0, marginLeft: 16, paddingRight: 12, flexDirection: 'row', alignItems: 'center', gap: 9 }}>
      <Svg width={11} height={19} viewBox="0 0 11 19" fill="none">
        <Path d="M9.5 1.5L2 9.5l7.5 8" stroke={paper(0.75)} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
      <AppText style={[sans('400'), { fontSize: 17, color: paper(0.75) }]}>Back</AppText>
    </PressScale>
  );
}

/**
 * Night auth shell: the field, the Back row, and a scroller for the form. The
 * Back row is 40 tall so content below it starts at design y 94, which is what
 * each board's own paddingTop is measured from.
 */
export function AuthSurface({ children, onBack }: { children: ReactNode; onBack?: () => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: INK }}>
      <AuthNightField />
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
        {onBack ? <AuthBack onPress={onBack} /> : <View style={{ height: 40 }} />}
        <ScrollView
          // the SafeAreaView above already spends the insets; `automatic` would
          // spend them a second time and push every canvas offset down
          contentInsetAdjustmentBehavior="never"
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ flexGrow: 1, paddingHorizontal: spacing.xl, paddingBottom: spacing.lg }}>
          {children}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

/**
 * A labelled night field, on the funnel's own metrics: 60 tall, radius 16,
 * `rgba(255,255,255,0.07)` under a `rgba(255,255,255,0.22)` hairline, 22 of
 * side padding and a 17px face. Focus lifts the hairline to the paper white
 * without changing the box, so nothing below it moves while you type.
 */
export function AuthField({
  label,
  value,
  onChangeText,
  placeholder,
  ...props
}: Pick<TextInputProps, 'secureTextEntry' | 'keyboardType' | 'autoCapitalize' | 'autoComplete' | 'textContentType' | 'returnKeyType' | 'onSubmitEditing' | 'autoFocus'> & {
  label?: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={{ gap: 8 }}>
      {label ? <AppText style={[sans('400'), { fontSize: 15, color: paper(0.6), paddingLeft: 1 }]}>{label}</AppText> : null}
      <TextInput
        {...props}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={paper(0.45)}
        // the funnel draws a 2px paper caret beside the placeholder; the system
        // one is the only caret we get, so it is tinted to match
        selectionColor={PAPER}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={[
          sans('400'),
          {
            height: 60,
            paddingHorizontal: 22,
            paddingVertical: 0,
            borderRadius: 16,
            backgroundColor: 'rgba(255,255,255,0.07)',
            color: PAPER,
            fontSize: 17,
            boxShadow: focused ? '0 0 0 2px rgba(255,255,255,0.4)' : '0 0 0 1px rgba(255,255,255,0.22)',
          },
          Platform.OS === 'web' ? ({ outlineStyle: 'none' } as object) : null,
        ]}
      />
    </View>
  );
}

/** The funnel's primary pill: 58 tall, radius 29, paper white on ink text. */
export function AuthButton({
  label,
  onPress,
  disabled,
  secondary = false,
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  secondary?: boolean;
}) {
  return (
    <PressScale
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      style={{
        height: 58,
        borderRadius: 29,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: secondary ? paper(0.08) : PAPER,
        opacity: disabled ? 0.38 : 1,
        ...(secondary ? { boxShadow: `0 0 0 1px ${paper(0.2)}` } : null),
      }}>
      <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: secondary ? PAPER : INK }]}>{label}</AppText>
    </PressScale>
  );
}

/**
 * The one line an auth board says back. Nothing in the bundle draws it — the
 * canvas never draws a failed sign-in — so it takes the funnel's own muted
 * paper for a notice and the palette's danger for a refusal.
 */
export function AuthMessage({ error, notice }: { error: string | null; notice: string | null }) {
  const message = error || notice;
  if (!message) return null;
  return (
    <AppText center selectable style={[sans('500'), { fontSize: 13, lineHeight: 19, color: error ? colors.danger : paper(0.6) }]}>
      {message}
    </AppText>
  );
}

/** The small print under the last control. 11 on the form, 12 on the gate. */
export function AuthLegal({ size = 11 }: { size?: number }) {
  return (
    <AppText center style={[sans('400'), { fontSize: size, color: paper(0.35) }]}>
      By continuing, you agree to our <AppText style={[sans('400'), { fontSize: size, color: paper(0.35), textDecorationLine: 'underline' }]}>terms of service</AppText> and{' '}
      <AppText style={[sans('400'), { fontSize: size, color: paper(0.35), textDecorationLine: 'underline' }]}>privacy policy</AppText>.
    </AppText>
  );
}
