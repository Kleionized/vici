import { useId } from 'react';
import Svg, {
  ClipPath,
  Defs,
  Ellipse,
  FeColorMatrix,
  FeComposite,
  FeGaussianBlur,
  FeOffset,
  Filter,
  LinearGradient as SvgLinearGradient,
  Path,
  Polygon,
  RadialGradient,
  Rect,
  Stop,
} from 'react-native-svg';

import { WEEK_SCENES, type WeekSceneLayer } from '@/content/weekScenes';

/**
 * The picture at the top of a week overview — the 258pt band each `Week …`
 * frame opens with, drawn from the layer list transcribed out of the canvas.
 *
 * The canvas builds these from absolutely-positioned divs, so there is no
 * viewBox to copy: the band's own top-left is the origin and every offset is
 * band-local. Layers wider than the frame (the 473pt swells on a 393pt board)
 * overhang deliberately, so they are re-measured off the live width rather than
 * scaled — a narrower phone shows less of the same hill, not a smaller one.
 */

export const WEEK_SCENE_HEIGHT = 258;

/** The width the canvas composed against. */
const CANVAS_W = 393;

/**
 * `border-radius: 50% 50% 0 0 / Rpx Rpx 0 0` turns a box's whole top edge into
 * one elliptical arc of radii `w/2 × ry`. RN's single-value radii cannot say
 * that, so it is a path.
 */
function domePath(x: number, y: number, w: number, h: number, ry: number): string {
  return `M${x} ${y + ry}A${w / 2} ${ry} 0 0 1 ${x + w} ${y + ry}L${x + w} ${y + h}L${x} ${y + h}Z`;
}

/**
 * A rounded rect with four independently-cut corners.
 *
 * CSS scales all four by `f = min(1, side ÷ Σ radii)` on each edge before
 * drawing, so `5px 5px 16px 16px` on a 14.25-tall box is really
 * 3.39 / 3.39 / 10.86 / 10.86. Passing the declared values straight through
 * makes the path self-intersect.
 */
function cornersPath(x: number, y: number, w: number, h: number, c: number[]): string {
  const raw = c.length === 4 ? c : [c[0], c[1] ?? c[0], c[2] ?? c[0], c[3] ?? c[1] ?? c[0]];
  const f = Math.min(
    1,
    w / Math.max(1e-6, raw[0] + raw[1]),
    w / Math.max(1e-6, raw[3] + raw[2]),
    h / Math.max(1e-6, raw[0] + raw[3]),
    h / Math.max(1e-6, raw[1] + raw[2]),
  );
  const [tl, tr, br, bl] = raw.map((v) => v * f);
  return [
    `M${x + tl} ${y}`,
    `H${x + w - tr}`,
    `A${tr} ${tr} 0 0 1 ${x + w} ${y + tr}`,
    `V${y + h - br}`,
    `A${br} ${br} 0 0 1 ${x + w - br} ${y + h}`,
    `H${x + bl}`,
    `A${bl} ${bl} 0 0 1 ${x} ${y + h - bl}`,
    `V${y + tl}`,
    `A${tl} ${tl} 0 0 1 ${x + tl} ${y}`,
    'Z',
  ].join('');
}

/** `polygon(50% 0, 100% 100%, 0 100%)` against a `w × h` box. */
function polygonPoints(clip: string, x: number, y: number, w: number, h: number): string {
  const inner = clip.slice(clip.indexOf('(') + 1, clip.lastIndexOf(')'));
  return inner
    .split(',')
    .map((pair) => {
      const [px, py] = pair.trim().split(/\s+/);
      const cx = px.endsWith('%') ? (parseFloat(px) / 100) * w : parseFloat(px);
      const cy = py.endsWith('%') ? (parseFloat(py) / 100) * h : parseFloat(py);
      return `${x + cx},${y + cy}`;
    })
    .join(' ');
}

type Gradient =
  | { kind: 'radial'; stops: { offset: number; color: string; opacity: number }[] }
  | { kind: 'linear'; stops: { offset: number; color: string; opacity: number }[] }
  | null;

/** `rgba(226,186,120,0.42)` / `#E9D2A4` → colour plus its alpha. */
function splitColor(raw: string): { color: string; opacity: number } {
  const rgba = raw.match(/rgba?\(([^)]+)\)/);
  if (!rgba) return { color: raw.trim(), opacity: 1 };
  const parts = rgba[1].split(',').map((p) => Number(p.trim()));
  const [r, g, b, a = 1] = parts;
  const hex = `#${[r, g, b].map((v) => Math.round(v).toString(16).padStart(2, '0')).join('')}`;
  return { color: hex, opacity: a };
}

/**
 * A CSS gradient, as its stops. `closest-side` on a square box is the box's own
 * half-width, which is what an SVG radial with `r = 50%` already is, so the
 * stop offsets carry straight over.
 */
function parseGradient(background: string): Gradient {
  if (!background.startsWith('radial-gradient') && !background.startsWith('linear-gradient')) return null;
  const kind = background.startsWith('radial-gradient') ? 'radial' : 'linear';
  const inner = background.slice(background.indexOf('(') + 1, background.lastIndexOf(')'));
  // Split on commas that are not inside a colour function.
  const chunks: string[] = [];
  let depth = 0;
  let current = '';
  for (const ch of inner) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) {
      chunks.push(current);
      current = '';
    } else current += ch;
  }
  chunks.push(current);

  const stops: { offset: number; color: string; opacity: number }[] = [];
  for (const chunk of chunks) {
    const text = chunk.trim();
    // Skip the shape/direction keyword.
    if (/^(closest-side|farthest-side|closest-corner|farthest-corner|circle|ellipse|to |[0-9.]+deg)/.test(text)) continue;
    const stopAt = text.match(/\s([0-9.]+)%$/);
    const colorText = stopAt ? text.slice(0, stopAt.index).trim() : text;
    const { color, opacity } = splitColor(colorText);
    stops.push({ offset: stopAt ? Number(stopAt[1]) / 100 : stops.length === 0 ? 0 : 1, color, opacity });
  }
  return { kind, stops };
}

/**
 * SVG filters compose in `linearRGB` by default and CSS's `filter: blur()`
 * works in `sRGB`, so a filter that does not say so round-trips the colour
 * through the wrong space (F43).
 */
const SRGB = { colorInterpolationFilters: 'sRGB' } as unknown as Record<string, never>;

/**
 * The user-space margin a Gaussian needs around its source box.
 *
 * A filter region defaults to 10% of the bounding box, which on week I's
 * 56 × 10 flag shadow is 1pt of room for a 4pt blur — the bloom would be cut
 * square well inside itself. So every region here is stated in user space, at
 * 3σ, where a Gaussian has spent 99.7% of its mass; the +2 keeps the boundary
 * off the last faint row.
 */
function bleedFor(sigma: number): number {
  return sigma * 3 + 2;
}

/** The `feColorMatrix` that stains a blurred alpha channel one flat colour. */
function stain(color: string, opacity: number): string {
  const hex = color.replace('#', '');
  const at = (i: number) => parseInt(hex.length === 3 ? hex[i] + hex[i] : hex.slice(i * 2, i * 2 + 2), 16) / 255;
  return `0 0 0 0 ${at(0)} 0 0 0 0 ${at(1)} 0 0 0 0 ${at(2)} 0 0 0 ${opacity} 0`;
}

/** The canvas draws its birds as inline `<svg>`; those layers carry a tree. */
function SvgLayer({ layer }: { layer: WeekSceneLayer }) {
  const s = layer.svg;
  if (!s) return null;
  return (
    <Svg width={s.width} height={s.height} viewBox={s.viewBox} x={s.left} y={s.top}>
      {s.children.map((child, i) =>
        child.tag === 'path' ? (
          <Path
            key={i}
            d={child.attrs.d}
            fill={child.attrs.fill ?? 'none'}
            stroke={child.attrs.stroke}
            strokeWidth={Number(child.attrs['stroke-width']) || undefined}
            strokeLinecap={child.attrs['stroke-linecap'] as 'round' | undefined}
            strokeLinejoin={child.attrs['stroke-linejoin'] as 'round' | undefined}
          />
        ) : null,
      )}
    </Svg>
  );
}

function Layer({ layer, index, id, width }: { layer: WeekSceneLayer; index: number; id: string; width: number }) {
  if (layer.svg) return <SvgLayer layer={layer} />;
  // Layers composed against the canvas's own 393 keep their absolute lefts; the
  // ones that run past an edge are re-measured so they still run past it.
  //
  // The test is on the layer's *edges*, not on its width alone: week IX's two
  // hills are 270 and 290 wide and each ends 83pt beyond one edge of the 393
  // board, so a width-only test left both of them stopping short on any wider
  // screen and opened a valley between them that the canvas does not draw.
  const dw = layer.width ?? 0;
  const dl = layer.left ?? 0;
  const past = Math.max(0, -dl) + Math.max(0, dl + dw - CANVAS_W);
  const overhang = layer.width != null && past > 0;
  const w = overhang ? width - CANVAS_W + dw : (layer.width ?? width);
  const x = layer.left ?? (layer.right != null ? width - layer.right - w : 0);
  const h = layer.height ?? 0;
  const y = layer.top ?? (layer.bottom != null ? WEEK_SCENE_HEIGHT - layer.bottom - h : 0);

  const gradient = layer.background ? parseGradient(layer.background) : null;
  const solid = !gradient && layer.background ? splitColor(layer.background) : null;
  const gid = `wl${id}${index}`;
  const cid = `wc${id}${index}`;

  // A solid box with a blur is a cast shadow or a glow. D082 modelled it as a
  // radial ramp fitted to the Gaussian, because this file had no blur
  // primitive; `react-native-svg` 15.15.4 carries `FeGaussianBlur` on web, iOS
  // and Android (D063/D113), so the layer is simply blurred. That is the only
  // way both of D082's observations come out right at once — a solid thinner
  // than its own blur never reaches its stated alpha (the flag shadow is a
  // 56 × 10 ellipse of rgba(0,0,0,0.08) under blur(4) and peaks at 0.063), and
  // the falloff carries on well past the box the canvas states.
  //
  // `filter: blur(r)` states σ directly, unlike a box-shadow's blur radius,
  // which is 2σ.
  const solidBlur = solid && layer.blur ? layer.blur : 0;
  const fid = `wf${id}${index}`;

  const fill = gradient ? `url(#${gid})` : solid?.color;
  const fillOpacity = gradient ? 1 : solid?.opacity;
  const rotate = layer.rotate ? `rotate(${layer.rotate} ${x + w / 2} ${y + h / 2})` : undefined;

  // Every radial here is exactly its own shape's bounding ellipse — a CSS
  // `closest-side` on a box is half its width by half its height, which is what
  // an untouched `objectBoundingBox` radial already is. Said that way rather
  // than as `userSpaceOnUse` + `rx`/`ry` because `react-native-svg`'s web build
  // forwards `rx`/`ry` to the DOM verbatim and `<radialGradient>` has no such
  // attributes: the browser falls back to r = 50% of the *viewport*, which on
  // this 393 × 258 band is r ≈ 166 and spreads every falloff over the whole
  // scene. It is what turned week I's 46pt sun into a 106pt orange blob.
  const defs = (
    <Defs>
      {solidBlur ? (
        <Filter
          id={fid}
          filterUnits="userSpaceOnUse"
          x={x - bleedFor(solidBlur)}
          y={y - bleedFor(solidBlur)}
          width={w + bleedFor(solidBlur) * 2}
          height={h + bleedFor(solidBlur) * 2}
          {...SRGB}>
          <FeGaussianBlur stdDeviation={solidBlur} />
        </Filter>
      ) : null}
      {gradient?.kind === 'radial' ? (
        <RadialGradient id={gid}>
          {gradient.stops.map((s, i) => (
            <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={s.opacity} />
          ))}
        </RadialGradient>
      ) : null}
      {gradient?.kind === 'linear' ? (
        <SvgLinearGradient id={gid} x1={x} y1={y} x2={x} y2={y + h} gradientUnits="userSpaceOnUse">
          {gradient.stops.map((s, i) => (
            <Stop key={i} offset={s.offset} stopColor={s.color} stopOpacity={s.opacity} />
          ))}
        </SvgLinearGradient>
      ) : null}
      {layer.clip ? (
        <ClipPath id={cid}>
          <Polygon points={polygonPoints(layer.clip, x, y, w, h)} />
        </ClipPath>
      ) : null}
    </Defs>
  );

  const common = {
    fill,
    fillOpacity,
    opacity: layer.opacity,
    transform: rotate,
    clipPath: layer.clip ? `url(#${cid})` : undefined,
    filter: solidBlur ? `url(#${fid})` : undefined,
  };

  // A zero-blur, zero-offset spread is a ring, expressible as a stroke — but
  // CSS puts the whole spread *outside* the border box, where a stroke sits
  // half in and half out (D111). So the stroked silhouette is grown by half a
  // spread and the stroke is one spread wide, which puts the ink exactly where
  // the canvas puts it. Both hulls carry `0 0 0 1px rgba(0,0,0,0.05)`, and
  // half a device pixel of it at the hull's foot was worth 2.8/255 of block
  // mean before this.
  const ring = layer.clip ? null : layer.shadow?.match(/^0 0 0 ([0-9.]+)px (rgba?\([^)]+\)|#[0-9A-Fa-f]{3,8})$/);
  const ringStroke = ring ? splitColor(ring[2]) : null;
  const spread = ring ? Number(ring[1]) : 0;

  // An offset, blurred, zero-spread shadow is a soft copy of the shape under
  // it. Two layers state one — the near sail of week VII's and week XII's boat,
  // both `0 1px 2px rgba(0,0,0,0.06)` — and **both are clipped**, so the canvas
  // draws neither: `clip-path` clips an element's whole rendering, its
  // box-shadow included, and an outer shadow lies outside the border box while
  // the polygon lies inside it (D117). Nothing in the twelve scenes states an
  // unclipped one, so this branch currently paints nothing; it is kept correct
  // rather than removed because the generator will emit one the moment a later
  // drop draws it.
  //
  // (Through pass 1 the pattern here was `/^(-?[0-9.]+)px? …/`, where the `?`
  // binds to the `x` alone and so demanded a literal `p` on the first length.
  // It could never match the canvas's own `0 1px 2px`, and the file's comment
  // claimed a shadow was being drawn that was not.)
  const drop = layer.clip
    ? null
    : layer.shadow?.match(/^(-?[0-9.]+)(?:px)? (-?[0-9.]+)px (-?[0-9.]+)px (rgba?\([^)]+\)|#[0-9A-Fa-f]{3,8})$/);
  const dropColor = drop ? splitColor(drop[4]) : null;
  const did = `wd${id}${index}`;
  const dx = drop ? Number(drop[1]) : 0;
  const dy = drop ? Number(drop[2]) : 0;
  // A box-shadow's blur radius is 2σ, unlike `filter: blur()`, which states σ.
  const dsigma = drop ? Number(drop[3]) / 2 : 0;
  const dmargin = bleedFor(dsigma) + Math.abs(dx) + Math.abs(dy);

  // The box's own silhouette, drawn with whatever paint it is handed — once
  // for the layer itself and, where one is stated, once more underneath as the
  // source the cast-shadow filter blurs.
  //
  // `g` grows the silhouette outwards, which is what a spread does: CSS grows
  // each *non-zero* corner radius by the spread and leaves a square corner
  // square.
  const silhouette = (props: Record<string, unknown>, g = 0) => {
    const [gx, gy, gw, gh] = [x - g, y - g, w + 2 * g, h + 2 * g];
    if (layer.radius.kind === 'ellipse') return <Ellipse cx={x + w / 2} cy={y + h / 2} rx={w / 2 + g} ry={h / 2 + g} {...props} />;
    if (layer.radius.kind === 'dome') return <Path d={domePath(gx, gy, gw, gh, layer.radius.ry + g)} {...props} />;
    if (layer.radius.kind === 'corners')
      return <Path d={cornersPath(gx, gy, gw, gh, layer.radius.corners.map((c) => (c > 0 ? c + g : 0)))} {...props} />;
    // CSS scales every radius by `min(1, side / Σ radii)` and then clamps each
    // to half the side; SVG clamps each axis independently, so a pill whose
    // 2r exceeds its height would draw an elliptical corner where the canvas
    // draws a circular one. Clamp before handing it over.
    const raw = layer.radius.kind === 'round' ? layer.radius.r : 0;
    const r = raw > 0 ? Math.min(raw + g, gw / 2, gh / 2) : 0;
    return <Rect x={gx} y={gy} width={gw} height={gh} rx={r} ry={r} {...props} />;
  };

  const shape = (
    <>
      {ringStroke
        ? silhouette(
            { fill: 'none', stroke: ringStroke.color, strokeOpacity: ringStroke.opacity, strokeWidth: spread, opacity: layer.opacity, transform: rotate },
            spread / 2,
          )
        : null}
      {silhouette(common)}
    </>
  );

  return (
    <>
      {defs}
      {dropColor ? (
        // Blur the silhouette, offset it, take the box back out of it and
        // stain it the shadow's colour — `out` is what CSS means by "the
        // shadow is drawn outside the border edge only", so it cannot show
        // through a translucent fill.
        <>
          <Defs>
            <Filter
              id={did}
              filterUnits="userSpaceOnUse"
              x={x - dmargin}
              y={y - dmargin}
              width={w + dmargin * 2}
              height={h + dmargin * 2}
              {...SRGB}>
              <FeGaussianBlur in="SourceAlpha" stdDeviation={dsigma} result="b" />
              <FeOffset in="b" dx={dx} dy={dy} result="o" />
              <FeComposite in="o" in2="SourceAlpha" operator="out" result="k" />
              <FeColorMatrix in="k" type="matrix" values={stain(dropColor.color, dropColor.opacity)} />
            </Filter>
          </Defs>
          {silhouette({ fill: '#000000', transform: rotate, filter: `url(#${did})`, opacity: layer.opacity })}
        </>
      ) : null}
      {shape}
    </>
  );
}

export function WeekScene({ week, width }: { week: number; width: number }) {
  const id = useId().replace(/:/g, '');
  const layers = WEEK_SCENES[week] ?? [];
  return (
    <Svg width={width} height={WEEK_SCENE_HEIGHT} style={{ position: 'absolute', left: 0, top: 0 }} pointerEvents="none">
      <Defs>
        <SvgLinearGradient id={`wsky${id}`} x1="0" y1="0" x2="0" y2={WEEK_SCENE_HEIGHT} gradientUnits="userSpaceOnUse">
          <Stop offset="0" stopColor="#F4F3F0" />
          <Stop offset="0.58" stopColor="#F3EEE1" />
          <Stop offset="1" stopColor="#F4F3F0" />
        </SvgLinearGradient>
      </Defs>
      <Rect x={0} y={0} width={width} height={WEEK_SCENE_HEIGHT} fill={`url(#wsky${id})`} />
      {layers.map((layer, index) => (
        <Layer key={index} layer={layer} index={index} id={id} width={width} />
      ))}
    </Svg>
  );
}
