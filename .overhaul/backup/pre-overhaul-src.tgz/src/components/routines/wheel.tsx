import { useEffect, useRef, useState } from 'react';
import { type NativeScrollEvent, type NativeSyntheticEvent, ScrollView, View } from 'react-native';

import { AppText } from '@/components/ui';
import type { TimeOfDay } from '@/lib/routines';
import { sans } from '@/lib/theme';

/**
 * The time wheel the two check-in boards share (108/109 on the canvas).
 *
 * The canvas draws a static perspective stack: the selected row 30px inside a
 * 44px line box, the six around it stepping down to 22/21/20 inside 29px ones.
 * Those rows are not evenly spaced — the first neighbour sits 36.5 from the
 * centre and each one after that a further 29 — so the scroll runs on a flat
 * 36.5 interval and every row is then nudged back toward the centre to land on
 * the canvas's spacing.
 */

const ITEM_H = 36.5;
/** Canvas 250 → 468: three rows either side of the selected one, and nothing past them. */
const COLUMN_H = 218;
const PAD = (COLUMN_H - ITEM_H) / 2;
/** Spacing between the off-centre rows once past the first neighbour. */
const OUTER_GAP = 29;

/**
 * A row's scroll position is `index * 36.5`, so it lands on a half pixel
 * whenever the index is odd — hour 10 is index 9, and with the loop's base of
 * 12 that is 21 x 36.5 = 766.5. The browser rounds the scroll offset it keeps,
 * and the whole column then sits half a point off the canvas's 250 / 279 / 308
 * / 337. So scroll to the whole pixel and take the half back out of the leading
 * pad: the sum is what places a row, and both halves of it are then exact.
 * Down, not to nearest: the AM/PM column's last row sits exactly on its own
 * scroll limit, and rounding up would ask for an offset the view cannot reach.
 */
const snapTo = (target: number) => Math.floor(target * ITEM_H);
const snapPad = (target: number) => PAD + (snapTo(target) - target * ITEM_H);

/** Size, leading and tone by distance from the selected row, straight off the canvas. */
const STEPS = [
  { size: 30, leading: 44, color: '#1D1C1A' },
  { size: 22, leading: 29, color: 'rgba(90,88,82,0.55)' },
  { size: 21, leading: 29, color: 'rgba(120,117,110,0.5)' },
  { size: 20, leading: 29, color: 'rgba(140,137,130,0.45)' },
];

function Column({
  values,
  index,
  onIndex,
  width,
  label,
  loop = false,
}: {
  values: string[];
  index: number;
  onIndex: (next: number) => void;
  width: number;
  label: string;
  loop?: boolean;
}) {
  const ref = useRef<ScrollView>(null);
  // The canvas shows 57/58/59 above a selected 00, so hours and minutes wrap.
  // Three copies is enough runway that a thumb never reaches an end before the
  // wheel has settled and re-centred on the middle one.
  const rows = loop ? [...values, ...values, ...values] : values;
  const base = loop ? values.length : 0;

  // Where the wheel is right now, in rows — fractional, so the perspective
  // moves with the finger rather than only after the snap settles.
  const [offset, setOffset] = useState(index + base);
  const [lead, setLead] = useState(() => snapPad(index + base));
  const position = useRef(0);

  const park = (target: number) => {
    ref.current?.scrollTo({ y: snapTo(target), animated: false });
    position.current = target;
    setOffset(target);
    setLead(snapPad(target));
  };

  // `contentOffset` is iOS-only, so the column has to be scrolled to the saved
  // value by hand. Re-running on `index` also catches the stored routine
  // arriving from disk a beat after the screen mounts.
  useEffect(() => {
    const target = index + base;
    if (Math.abs(target - position.current) < 0.5) return;
    park(target);
  }, [index, base]);

  // `react-native-web` never emits `onMomentumScrollEnd` (DECISIONS D065), so a
  // flick on the web preview would never commit its value or re-centre the
  // loop. The scroll going quiet is the event both platforms do have.
  const idle = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (idle.current) clearTimeout(idle.current); }, []);

  const settle = (y: number, recentre: boolean) => {
    if (idle.current) { clearTimeout(idle.current); idle.current = null; }
    const landed = Math.max(0, Math.min(rows.length - 1, Math.round(y / ITEM_H)));
    const next = loop ? ((landed % values.length) + values.length) % values.length : landed;
    if (next !== index) onIndex(next);
    if (!recentre) return;
    const target = loop ? next + base : landed;
    if (target === landed && snapTo(target) === y) return;
    park(target);
  };

  const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const y = event.nativeEvent.contentOffset.y;
    position.current = y / ITEM_H;
    setOffset(y / ITEM_H);
    if (idle.current) clearTimeout(idle.current);
    idle.current = setTimeout(() => settle(y, true), 140);
  };

  // Only the rows near the band are built; 180 live <Text> nodes re-rendering on
  // every scroll frame is what makes a wheel stutter.
  const first = Math.max(0, Math.round(offset) - 4);
  const last = Math.min(rows.length - 1, Math.round(offset) + 4);

  return (
    <ScrollView
      ref={ref}
      accessibilityRole="adjustable"
      accessibilityLabel={label}
      accessibilityValue={{ text: values[index] }}
      // ScrollView composes its own `baseVertical` under this style, and that
      // base carries flexGrow/flexShrink 1 — which `width` does not override.
      // Left alone, the three columns stretch to fill the row and none of them
      // lands on the canvas's x. Pinning both flex factors to 0 is what keeps
      // 40 / 50 / 60 at 105 / 172 / 238.
      style={{ width, height: COLUMN_H, flexGrow: 0, flexShrink: 0 }}
      showsVerticalScrollIndicator={false}
      snapToInterval={ITEM_H}
      decelerationRate="fast"
      onScroll={onScroll}
      scrollEventThrottle={16}
      onMomentumScrollEnd={(event) => settle(event.nativeEvent.contentOffset.y, true)}
      onScrollEndDrag={(event) => settle(event.nativeEvent.contentOffset.y, false)}>
      <View style={{ height: lead + first * ITEM_H }} />
      {rows.slice(first, last + 1).map((value, k) => {
        const i = first + k;
        const d = i - offset;
        const away = Math.abs(d);
        const step = STEPS[Math.min(3, Math.round(away))];
        // Flat scroll travel out, canvas spacing back in.
        const placed = away <= 1 ? d * ITEM_H : Math.sign(d) * (ITEM_H + (away - 1) * OUTER_GAP);
        return (
          <View key={`${value}-${i}`} style={{ height: ITEM_H }}>
            {/* The canvas writes each row as a full-width centred div, and its
                line box — not the glyph — is what lands on 250 / 279 / 308. So
                the row is placed by `top` rather than by a transform: a
                composited transform rasterises the same box half a device pixel
                off, which was the last thing left on these two boards. */}
            <AppText
              center
              style={[
                sans('400'),
                {
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  top: (ITEM_H - step.leading) / 2 + (placed - d * ITEM_H),
                  fontSize: step.size,
                  lineHeight: step.leading,
                  color: step.color,
                },
              ]}>
              {value}
            </AppText>
          </View>
        );
      })}
      <View style={{ height: (rows.length - 1 - last) * ITEM_H + (COLUMN_H - ITEM_H - lead) }} />
    </ScrollView>
  );
}

const HOURS = Array.from({ length: 12 }, (_, i) => String(i + 1));
const MINUTES = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));
const PERIODS = ['AM', 'PM'];

export function TimeWheel({ value, onChange }: { value: TimeOfDay; onChange: (next: TimeOfDay) => void }) {
  return (
    <View style={{ height: COLUMN_H }}>
      {/* the band under the selected rows — canvas 46/301 wide at y 335, i.e. 85 into the stack and 2px above the row's own box */}
      <View
        pointerEvents="none"
        style={{ position: 'absolute', left: 46, width: 301, top: 85, height: 44, borderRadius: 11, backgroundColor: 'rgba(0,0,0,0.08)' }}
      />
      {/* the canvas pins the columns at x 105/172/238; 105 + 40 + 27 = 172 and 172 + 50 + 16 = 238, so the row is padded to the
          literal origin rather than centred — the frame's cluster centre (201.5) is 5px right of the band's (196.5) and that
          disagreement is part of the drawing */}
      <View style={{ flexDirection: 'row', paddingLeft: 105 }}>
        <Column values={HOURS} index={value.hour - 1} onIndex={(i) => onChange({ ...value, hour: i + 1 })} width={40} label="Hour" loop />
        <View style={{ width: 27 }} />
        <Column values={MINUTES} index={value.minute} onIndex={(i) => onChange({ ...value, minute: i })} width={50} label="Minute" loop />
        <View style={{ width: 16 }} />
        <Column values={PERIODS} index={value.period === 'PM' ? 1 : 0} onIndex={(i) => onChange({ ...value, period: i === 1 ? 'PM' : 'AM' })} width={60} label="AM or PM" />
      </View>
    </View>
  );
}
