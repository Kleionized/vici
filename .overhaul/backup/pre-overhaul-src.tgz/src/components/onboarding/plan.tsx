/**
 * The plan sub-flow — `27 · Where We’d Start` … `31 · Your Plan`.
 *
 * Five frames the `Latest Vici FULL` drop adds between `26 · Enlisting Aegis`
 * and `32 · Starting Score`. They
 * replace the three boards the previous bundle put there — `Root Loop`,
 * `What Comes Before It` and `Results Pattern` — all three of which the drop
 * withdrew.
 *
 * All five share the tail's field exactly: a `#FAF9F8 → #FDFDFC` ground, the
 * `rgba(180,170,150,0.14)` corner bloom at −40,−140, a 560pt sun hung 300
 * below the bottom edge and grain at 0.12. They are drawn with `TailField`
 * rather than a copy of it — verified row for row against each frame's own
 * signature, not assumed.
 *
 * Design y minus 54 throughout (`DECISIONS.md` D009).
 */
import { LinearGradient } from 'expo-linear-gradient';
import { type ReactNode } from 'react';
import { Platform, View, type TextStyle } from 'react-native';
import Svg, { Circle, Defs, Ellipse, FeGaussianBlur, Filter, G, Line, Path, RadialGradient, Rect, Stop } from 'react-native-svg';

import { AppText, Grain } from '@/components/ui';
import { PressScale } from '@/components/ui/press-scale';
import { FUNNEL_GLYPHS } from '@/content/onboardingFunnel';
import { sans } from '@/lib/theme';
import { TailCopy, TailCta, TailFrame } from './tail';

const noiseDark = require('../../../assets/images/noise-dark.png');

/** Design y → the app's y under the safe-area inset. */
const Y = (top: number) => top - 54;

/** CSS's own wrapping, for a run the frame gives no `text-wrap` (D052). */
const PLAIN_WRAP = Platform.OS === 'web' ? ({ textWrap: 'wrap' } as unknown as TextStyle) : null;

/** CSS's `white-space: nowrap`, for the chip run `27` states it on (D092). */
const NOWRAP = Platform.OS === 'web' ? ({ whiteSpace: 'nowrap' } as unknown as TextStyle) : null;

// ── the pieces the five frames share ─────────────────────────────────

/**
 * A blurred layer inside one of the art boxes.
 *
 * The canvas builds every glow and every cast shadow in this family out of a
 * `border-radius: 50%` box under `filter: blur(Npx)`, and two different things
 * hide under that one shape.
 *
 * A blurred **radial gradient** is already a soft falloff with no edge, so the
 * blur only widens it and is absorbed into the stops — `DECISIONS.md` D010.
 * Those layers pass a `stop` and take that path.
 *
 * A blurred **solid** is the other case, and D082 is the rule for it: the blur
 * *is* the shape, so an ellipse drawn at the stated box loses the plateau's
 * true peak (a shape thinner than its own blur never reaches its stated alpha)
 * and loses the 2σ of falloff that lives outside the div. `react-native-svg`
 * 15 ships `<Filter>`/`<FeGaussianBlur>` on web, iOS and Android, so those are
 * not approximated at all — the canvas's own Gaussian, at the canvas's own
 * σ, over an `<Svg>` and a filter region padded 3σ so neither clips it.
 * `filter: blur(r)` states σ directly (a `box-shadow`'s blur radius is 2σ;
 * the two are not the same Gaussian). D091.
 */
function SoftBlob({
  id,
  left,
  top,
  width,
  height,
  color,
  alpha,
  stop,
  blur = 5,
}: {
  id: string;
  left: number;
  top: number;
  width: number;
  height: number;
  color: string;
  alpha: number;
  /** A blurred radial gradient's own falloff stop. A solid states none. */
  stop?: number;
  /** The canvas's own `blur(N)`, i.e. σ. */
  blur?: number;
}) {
  if (stop != null) {
    return (
      <Svg width={width} height={height} pointerEvents="none" style={{ position: 'absolute', left, top }}>
        <Defs>
          {/* No `rx`/`ry` on the radial: a `closest-side` radial on a box is
              already exactly what an untouched `objectBoundingBox` gradient
              is, and the web build forwards `rx`/`ry` to a DOM element that
              has no such attributes (D081). */}
          <RadialGradient id={id}>
            <Stop offset={0} stopColor={color} stopOpacity={alpha} />
            <Stop offset={stop} stopColor={color} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={width / 2} cy={height / 2} rx={width / 2} ry={height / 2} fill={`url(#${id})`} />
      </Svg>
    );
  }

  // 3σ is where a Gaussian has spent 99.7% of itself; the canvas's own art box
  // clips whatever runs past 240 x 200, exactly as `overflow: hidden` does.
  const pad = Math.ceil(blur * 3);
  const w = width + pad * 2;
  const h = height + pad * 2;
  return (
    <Svg width={w} height={h} pointerEvents="none" style={{ position: 'absolute', left: left - pad, top: top - pad }}>
      <Defs>
        {/* A filter region in user space: the default `-10% … 120%` of the
            object's own box is nowhere near a 14pt-tall shadow's 5pt blur and
            would cut the falloff off square. */}
        <Filter id={id} x={0} y={0} width={w} height={h} filterUnits="userSpaceOnUse">
          <FeGaussianBlur stdDeviation={blur} />
        </Filter>
      </Defs>
      <Ellipse
        cx={w / 2}
        cy={h / 2}
        rx={width / 2}
        ry={height / 2}
        fill={color}
        fillOpacity={alpha}
        filter={`url(#${id})`}
      />
    </Svg>
  );
}

/** One flat layer of an art box — an absolutely-positioned painted box. */
function Bit({
  l,
  t,
  w,
  h,
  r,
  bg,
  corners,
  gradient,
}: {
  l: number;
  t: number;
  w: number;
  h: number;
  /** `50%` on the canvas is half the box, not a percentage React Native takes. */
  r?: number | 'pill';
  bg?: string;
  corners?: [number, number, number, number];
  gradient?: readonly [string, string];
}) {
  const radius = r === 'pill' ? Math.min(w, h) / 2 : r;
  const style = {
    position: 'absolute' as const,
    left: l,
    top: t,
    width: w,
    height: h,
    ...(radius != null ? { borderRadius: radius } : null),
    ...(corners
      ? {
          borderTopLeftRadius: corners[0],
          borderTopRightRadius: corners[1],
          borderBottomRightRadius: corners[2],
          borderBottomLeftRadius: corners[3],
        }
      : null),
    ...(bg ? { backgroundColor: bg } : null),
  };
  if (gradient) return <LinearGradient colors={[gradient[0], gradient[1]]} style={style} />;
  return <View style={style} />;
}

/** The 240 x 200 clip box three of the five frames hang their scene inside. */
function ArtBox({ children }: { children: ReactNode }) {
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 76, top: Y(196), width: 240, height: 200 }}>
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>{children}</View>
    </View>
  );
}

/**
 * A 22 x 22 glyph off `13 · Risky Times`'s own tile set, inked #131313.
 *
 * `27 · Where We’d Start` draws the three signals he picked with the
 * grid picker's glyphs, path for path — the moon, the house and the phone are
 * byte-identical to `FUNNEL_GLYPHS`. The renderer is local rather than the
 * funnel's own because the two do different jobs: a picker tile flips its ink
 * with selection, these never do.
 */
function PlanGlyph({ label }: { label: string }) {
  const g = FUNNEL_GLYPHS[label];
  if (!g) return null;
  return (
    <Svg width={22} height={22} viewBox={g.viewBox} fill="none">
      {g.kids.map((k, i) => {
        const a = k.attrs;
        // The canvas fills a shape or strokes it, never both: a child with no
        // stated stroke width is a filled one and takes the ink as its fill.
        const filled = a.fill !== 'none' && !a['stroke-width'];
        const common = {
          stroke: a['stroke-width'] ? '#131313' : undefined,
          strokeWidth: a['stroke-width'] ? Number(a['stroke-width']) : undefined,
          strokeLinecap: a['stroke-linecap'] as 'round' | undefined,
          strokeLinejoin: a['stroke-linejoin'] as 'round' | undefined,
          fill: filled ? '#131313' : 'none',
        };
        if (k.tag === 'circle') return <Circle key={i} cx={Number(a.cx)} cy={Number(a.cy)} r={Number(a.r)} {...common} />;
        if (k.tag === 'rect')
          return <Rect key={i} x={Number(a.x)} y={Number(a.y)} width={Number(a.width)} height={Number(a.height)} rx={a.rx ? Number(a.rx) : undefined} {...common} />;
        return <Path key={i} d={a.d} {...common} />;
      })}
    </Svg>
  );
}

/** The two-dot pager `29 · Start Here Step 1` and `30 · Step 2` carry at y 132. */
function StepDots({ at }: { at: 0 | 1 }) {
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: Y(132), flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7 }}>
      {[0, 1].map((i) => (
        <View
          key={i}
          style={{ width: i === at ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === at ? '#131313' : 'rgba(19,19,19,0.18)' }}
        />
      ))}
    </View>
  );
}

// ── what the five screens say about him ──────────────────────────────

/**
 * The canvas draws one man's answers: late at night, in bed, scrolling, and a
 * first change of keeping the phone out of the bed. Every one of those five
 * strings is his answer rendered in the boards' own voice, so each gets a
 * table off the picker that produced it. The canvas's own row is verbatim; the
 * rest are written to its pattern — the same shape `windowFor` already uses
 * for text the frames never drew.
 */

/**
 * `13 · When` → the chip label on `27 · Where We’d Start`.
 *
 * The canvas contradicts itself here, and this table is where it is resolved.
 * `27` is a new frame in this drop, and it draws "Late at night", "Home alone"
 * and "Phone in bed" — which are slots 1, 8 and 9 of `13 · When` under the
 * PREVIOUS drop's names. This drop renamed six of that picker's nine options
 * one-for-one by slot and kept every glyph, so slot 8 now reads "When I’m home
 * alone" and slot 9 "While scrolling", and `27` was not restated.
 *
 * The chips are plainly his answers — the line under them says so, and the
 * three glyphs are `13 · When`'s own, path for path — so they are read off the
 * picker. But the column is 100 wide with `white-space: nowrap`, and the new
 * names do not fit it: "When I’m home alone" is half as wide again as the
 * frame's own widest chip. So each option gets a chip form, and slots 1, 8 and
 * 9 take the words `27` itself draws. `DECISIONS.md` D053.
 *
 * Measured at 13.5/600 in the frame's own family against its 100pt column:
 * 82.0 · 94.7 · 38.9 · 58.2 · 73.9 · 87.8 · 90.3 · 77.4 · 84.8. `When I’m bored`
 * shipped at its full 103.4 and was the one entry over the column; it is
 * shortened here on the same pattern as its two neighbours (D092).
 */
const CHIP_LABEL: Record<string, string> = {
  'Late at night': 'Late at night',
  'In the morning': 'In the morning',
  'When I’m bored': 'Bored',
  'When I’m stressed': 'Stressed',
  'When I can’t sleep': 'Can’t sleep',
  'On weekends': 'On weekends',
  'After drinking': 'After drinking',
  'When I’m home alone': 'Home alone',
  'While scrolling': 'Phone in bed',
};

/** `13 · When` → the sentence-opening form on `28 · Start Here`. */
const WHEN_SHORT: Record<string, string> = {
  'Late at night': 'Late night',
  'In the morning': 'Mornings',
  'When I’m bored': 'Boredom',
  'When I’m stressed': 'Stress',
  'When I can’t sleep': 'Sleepless nights',
  'On weekends': 'Weekends',
  'After drinking': 'Drinking',
  'When I’m home alone': 'Being home alone',
  'While scrolling': 'Scrolling',
};

/** `15 · Place` → the mid-sentence form. The canvas turns "In bed" into "bed". */
const WHERE_SHORT: Record<string, string> = {
  'In bed': 'bed',
  'In the bathroom': 'the bathroom',
  'At my desk': 'your desk',
  'In the living room': 'the living room',
  'Somewhere else at home': 'home',
  'Outside home': 'being out',
};

/**
 * `16 · What starts it` → the mid-sentence form and the plan row.
 *
 * The canvas fixes the transform on one entry: "I start scrolling" is
 * "scrolling" in the sentence and "Scrolling" on the plan row — the
 * first-person clause becomes a noun phrase. The rest follow it.
 */
const STARTER: Record<string, { phrase: string; row: string }> = {
  'I see something sexual online': { phrase: 'something you saw', row: 'Something you saw' },
  'I start scrolling': { phrase: 'scrolling', row: 'Scrolling' },
  'I can’t sleep': { phrase: 'not sleeping', row: 'Not sleeping' },
  'I’ve had a stressful day': { phrase: 'a stressful day', row: 'A stressful day' },
  'I argue with someone or feel rejected': { phrase: 'an argument', row: 'An argument' },
  'I start fantasising': { phrase: 'fantasising', row: 'Fantasising' },
  'Nothing obvious': { phrase: 'no one thing', row: 'Nothing obvious' },
};

export type FirstChange = {
  /** `28 · Start Here`'s heading. */
  heading: string;
  /** `31 · Your Plan`'s fourth row. */
  row: string;
  /** `29 · Step 1` and `30 · Step 2` — one heading and one note each. */
  steps: [{ title: string; note: string }, { title: string; note: string }];
};

/**
 * The first change the boards propose, and the ones `Choose another` reaches.
 *
 * The bundle designs exactly one — the phone out of the bed — and draws
 * `Choose another` under it with no destination frame anywhere in the drop. A
 * dead control was the worse of the two readings, so the line swaps the
 * proposed change for the next signal he named on `27 · Where We’d Start`; the
 * boards keep their own artwork, because inventing a second scene would be
 * approximating a visualisation the canvas does not draw. Anything without a
 * row here falls back to the canvas's own. `DECISIONS.md` D054.
 *
 * No heading below carries a line break: `28` and `30` state
 * `text-wrap: balance` and the boards pass it through (D052) rather than
 * hard-wrapping — the same engine balancing the same run at the same width
 * breaks where the frame breaks.
 */
const FIRST_CHANGES: Record<string, FirstChange> = {
  // the canvas's own board, verbatim — slot 9 of `13 · When`
  'While scrolling': {
    heading: 'Keep your phone out of bed tonight.',
    row: 'Phone out of bed',
    steps: [
      { title: 'Charge it away from the bed.', note: 'Tonight, before you lie down.' },
      { title: 'Can’t sleep? Get out of bed before you start scrolling.', note: 'One change tonight. Build from there.' },
    ],
  },
  'Late at night': {
    heading: 'Pick the hour you stop tonight.',
    row: 'A stop time',
    steps: [
      { title: 'Set the hour before you need it.', note: 'Tonight, while it is still early.' },
      { title: 'When it comes round, put the phone down and go to bed.', note: 'One change tonight. Build from there.' },
    ],
  },
  'When I can’t sleep': {
    heading: 'Leave the room instead of lying there.',
    row: 'Out of the room',
    steps: [
      { title: 'Decide now where you will go.', note: 'Tonight, before you lie down.' },
      { title: 'Twenty minutes awake and you get up, without the phone.', note: 'One change tonight. Build from there.' },
    ],
  },
  'When I’m home alone': {
    heading: 'Keep one door open tonight.',
    row: 'A door left open',
    steps: [
      { title: 'Pick the room you will not close.', note: 'Tonight, before the house goes quiet.' },
      { title: 'When the house empties, the door stays open.', note: 'One change tonight. Build from there.' },
    ],
  },
};
const DEFAULT_CHANGE = 'While scrolling';

/**
 * Which of his signals `28 · Start Here` proposes first, and the order
 * `Choose another` walks them in.
 *
 * The canvas is the datum: for a man who named late night, being home alone
 * and scrolling, `28` proposes the phone out of the bed — the third of his
 * three chips, not the first. So the proposal is not "his first answer" but
 * the most concrete thing among them, and the order below is that reading.
 * His `15 · Place` and `16 · What starts it` answers on the same frame ("In
 * bed", "I start scrolling") both point at the same board, which is the
 * evidence for it. `DECISIONS.md` D054.
 */
const CHANGE_ORDER = ['While scrolling', 'When I can’t sleep', 'When I’m home alone', 'Late at night'];

/**
 * The three signals `27` puts on its dashed rule, in his own picker's labels.
 *
 * The frame always draws three, spaced apart with a rule running between them,
 * so a man who ticked one or two is topped up from the trio the canvas itself
 * draws rather than left with a rule going nowhere.
 */
export function planSignals(triggers: string[]): [string, string, string] {
  const seen: string[] = [];
  for (const t of [...triggers, 'Late at night', 'When I’m home alone', 'While scrolling']) {
    if (FUNNEL_GLYPHS[t] && !seen.includes(t)) seen.push(t);
    if (seen.length === 3) break;
  }
  return seen as [string, string, string];
}

/** The change a signal proposes — the canvas's own board wherever none is named. */
export function firstChangeFor(signal: string): FirstChange {
  return FIRST_CHANGES[signal] ?? FIRST_CHANGES[DEFAULT_CHANGE];
}

/**
 * The boards `28 · Start Here` can propose, in the order it proposes them.
 *
 * Read off the three signals `27` just drew rather than off the raw answers,
 * so `28` never proposes a change for something `27` did not show him.
 */
export function changeCandidates(signals: string[]): string[] {
  const named = CHANGE_ORDER.filter((k) => signals.includes(k));
  return named.length ? named : [DEFAULT_CHANGE];
}

export function chipLabel(signal: string) {
  return CHIP_LABEL[signal] ?? signal;
}
export function whenShort(when: string) {
  return WHEN_SHORT[when] ?? when;
}
export function whereShort(where: string) {
  return WHERE_SHORT[where] ?? where.toLowerCase();
}
export function starterFor(starter: string) {
  return STARTER[starter] ?? { phrase: 'scrolling', row: 'Scrolling' };
}

/**
 * `28 · Start Here`'s sentence — the three of his answers the board's proposal
 * sits on.
 *
 * The canvas draws it for one man: "Late night, bed and scrolling came up
 * together in your answers.", under "Keep your phone out of bed tonight." —
 * his `13 · When`, his `15 · Place` and his `16 · What starts it`, and the
 * change they converge on. What holds that board together is that the signal
 * being acted on is one of the three things named, and on the canvas's own
 * board it is: the proposal is `While scrolling` and the sentence says
 * scrolling.
 *
 * `Choose another` (D054) swaps the proposal to another of his signals, and
 * two of the four — `When I can’t sleep` and `When I’m home alone` — are not
 * among the three terms for a man with the canvas's answers, so the board then
 * argued for a door using evidence about a phone. The signal takes the `when`
 * slot whenever it is not already in the sentence: every word is still his own
 * answer, the frame's sentence keeps its shape, and the canvas's own state is
 * untouched (`While scrolling` shortens to "Scrolling", which the starter term
 * already says). D093.
 */
export function evidenceLine(signal: string, when: string, where: string, starter: string) {
  const terms = [whenShort(when), whereShort(where), starterFor(starter).phrase];
  const lead = whenShort(signal);
  if (!terms.some((t) => t.toLowerCase() === lead.toLowerCase())) terms[0] = lead;
  return `${terms[0]}, ${terms[1]} and ${terms[2]} came up together in your answers.`;
}

// ── 27 · Where We’d Start ────────────────────────────────────────────
/**
 * The night card, the three signals on a dashed rule, and the line that says
 * he does not have to change everything at once.
 */
export function O3WhereWedStart({ name, triggers, next }: { name?: string; triggers: string[]; next: () => void }) {
  const who = (name ?? '').trim();
  const signals = planSignals(triggers);
  return (
    <TailFrame>
      <TailCopy top={140} inset={36} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
        {who ? `${who}, this is where we’d start.` : 'This is where we’d start.'}
      </TailCopy>

      {/* the bedroom at night, 345 x 150 at radius 20 */}
      <View
        style={{
          position: 'absolute',
          left: 24,
          right: 24,
          top: Y(222),
          height: 150,
          borderRadius: 20,
          overflow: 'hidden',
          boxShadow: '0 0 0 1px rgba(0,0,0,0.09), 0 14px 30px rgba(40,38,32,0.18)',
        }}>
        <LinearGradient colors={['#17171A', '#2A2926']} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <Grain source={noiseDark} opacity={0.14} />
        {/* absolute, or the card's grain paints over the whole scene on web */}
        <Svg width={345} height={150} viewBox="0 0 345 150" style={{ position: 'absolute', left: 0, top: 0 }}>
          {/* The frame states `cx`/`cy` and no radius on either: a bare
              `objectBoundingBox` radial is already the shape's own bounding
              ellipse, and naming `rx`/`ry` is the one thing D081 says not to
              do (RNSVG's web build forwards them to a DOM `<radialGradient>`,
              which has no such attributes). */}
          <Defs>
            <RadialGradient id="wds-glow" cx="50%" cy="50%">
              <Stop offset={0} stopColor="rgba(240,206,142,0.7)" />
              <Stop offset={1} stopColor="rgba(240,206,142,0)" />
            </RadialGradient>
            <RadialGradient id="wds-moon" cx="40%" cy="35%">
              <Stop offset={0} stopColor="#FBEECF" />
              <Stop offset={1} stopColor="#E2BA78" />
            </RadialGradient>
          </Defs>
          <G fill="rgba(244,243,240,0.35)">
            <Circle cx={34} cy={30} r={1.6} />
            <Circle cx={96} cy={18} r={1.3} />
            <Circle cx={150} cy={40} r={1.2} />
            <Circle cx={212} cy={22} r={1.4} />
            <Circle cx={318} cy={58} r={1.3} />
            <Circle cx={62} cy={62} r={1.1} />
          </G>
          <Path d="M272 20a15 15 0 1 0 10 26.2A19 19 0 1 1 272 20z" fill="url(#wds-moon)" opacity={0.9} />
          <Line x1={0} y1={126} x2={345} y2={126} stroke="rgba(255,255,255,0.10)" strokeWidth={1.2} />
          <Rect x={86} y={58} width={12} height={68} rx={4} fill="rgba(255,255,255,0.20)" />
          <Rect x={98} y={94} width={150} height={20} rx={6} fill="rgba(255,255,255,0.24)" />
          <Rect x={104} y={84} width={34} height={12} rx={5} fill="rgba(255,255,255,0.42)" />
          <Path d="M144 94 C160 80 200 78 240 92 L248 94 L144 94 Z" fill="rgba(255,255,255,0.14)" />
          <Rect x={102} y={114} width={6} height={12} rx={2} fill="rgba(255,255,255,0.18)" />
          <Rect x={238} y={114} width={6} height={12} rx={2} fill="rgba(255,255,255,0.18)" />
          <Circle cx={200} cy={78} r={34} fill="url(#wds-glow)" />
          {/* a transform string, never `rotation` — that leaks an origin of 0,0 */}
          <Rect x={193} y={66} width={13} height={22} rx={3} fill="#F0CE8E" transform="rotate(-18 199.5 77)" />
        </Svg>
      </View>

      {/* the three signals, on a dashed rule that runs behind their discs */}
      <View style={{ position: 'absolute', left: 24, right: 24, top: Y(404), height: 96 }}>
        <View style={{ position: 'absolute', left: 64, right: 64, top: 28, height: 0, borderTopWidth: 1.5, borderStyle: 'dashed', borderColor: 'rgba(0,0,0,0.16)' }} />
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 6 }}>
          {signals.map((label) => (
            <View key={label} style={{ alignItems: 'center', gap: 9, width: 100 }}>
              <View
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: 28,
                  backgroundColor: '#FFFFFF',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 0 0 1px rgba(0,0,0,0.09), 0 8px 18px rgba(40,38,32,0.10)',
                }}>
                <PlanGlyph label={label} />
              </View>
              {/* the frame states `white-space: nowrap` on this run: a label
                  wider than the 100pt column overflows it and stays one line,
                  16 tall. `numberOfLines` alone does not do that on
                  react-native-web — it is `-webkit-line-clamp`, which clamps
                  the paint but still lays the run out over two lines and grows
                  the box to 31 (D092). */}
              <AppText numberOfLines={1} center style={[sans('600'), { fontSize: 13.5, color: '#1D1C1A' }, NOWRAP]}>
                {chipLabel(label)}
              </AppText>
            </View>
          ))}
        </View>
      </View>

      <TailCopy top={520} inset={44} size={14.5} lineHeight={21} color="#55534E">
        These came up together in your answers.
      </TailCopy>

      {/* Two runs in a column at gap 2, not one wrapped paragraph. Neither
          states a `text-wrap`, so both take CSS's own `wrap` — `AppText`
          would otherwise give them `pretty` and break one word early
          (`DECISIONS.md` D052). */}
      <View style={{ position: 'absolute', left: 36, right: 36, top: Y(590), gap: 2 }}>
        <AppText center style={[sans('500'), { fontSize: 17, lineHeight: 26, color: '#1D1C1A' }, PLAIN_WRAP]}>
          You don’t need to change everything at once.
        </AppText>
        <AppText center style={[sans('500'), { fontSize: 17, lineHeight: 26, color: '#1D1C1A' }, PLAIN_WRAP]}>
          Start with this.
        </AppText>
      </View>

      <TailCta label="Continue" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── 28 · Start Here ──────────────────────────────────────────────────
/** The bed and the nightstand, the change, and the two ways past it. */
export function O3StartHere({
  change,
  signal,
  when,
  where,
  starter,
  onAccept,
  onAnother,
}: {
  change: FirstChange;
  /** The signal this board's proposal is built on — D054's `Choose another`. */
  signal: string;
  when: string;
  where: string;
  starter: string;
  onAccept: () => void;
  onAnother: () => void;
}) {
  return (
    <TailFrame>
      <ArtBox>
        <SoftBlob id="sh-glow" left={140} top={14} width={124} height={124} color="rgb(226,186,120)" alpha={0.4} stop={0.74} />
        <Bit l={22} t={64} w={108} h={46} r={8} bg="#E4E3DE" />
        <Bit l={14} t={102} w={134} h={32} r={10} gradient={['#F7F6F2', '#EDECE7']} />
        <Bit l={24} t={90} w={44} h={16} r={7} bg="#F7F6F2" />
        <Bit l={20} t={132} w={6} h={34} r={3} bg="#C6C5C0" />
        <Bit l={136} t={132} w={6} h={34} r={3} bg="#C6C5C0" />
        <SoftBlob id="sh-bed-shadow" left={10} top={160} width={146} height={14} color="rgb(0,0,0)" alpha={0.1} blur={5} />
        <SoftBlob id="sh-table-glow" left={166} top={146} width={76} height={26} color="rgb(226,186,120)" alpha={0.22} blur={5} />
        <Bit l={176} t={106} w={58} h={58} r={8} bg="#E0DFDA" />
        <Bit l={192} t={130} w={26} h={5} r={3} bg="#C6C5C0" />
        <Bit l={180} t={162} w={6} h={10} r={3} bg="#D6D5D0" />
        <Bit l={222} t={162} w={6} h={10} r={3} bg="#D6D5D0" />
        <Bit l={236} t={108} w={3} h={58} r={2} bg="#B4B1AB" />
        <Bit l={195} t={62} w={20} h={42} r={5} bg="#3A3934" />
        <Bit l={202} t={67} w={4} h={4} r="pill" bg="#8B8882" />
        <SoftBlob id="sh-table-shadow" left={172} top={166} width={66} height={10} color="rgb(0,0,0)" alpha={0.08} blur={5} />
      </ArtBox>

      <TailCopy top={432} inset={36} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
        {change.heading}
      </TailCopy>
      <TailCopy top={516} inset={44} size={15.5} lineHeight={23} color="#55534E">
        {evidenceLine(signal, when, where, starter)}
      </TailCopy>

      <TailCta label="I can do that" onPress={onAccept} y={688} h={56} />
      {/* the frame runs this one edge to edge, not at the pill's 24 */}
      {/* `minHeight: 0` because the frame draws a 393 x 18 run and no control
          around it — the same thing `TailCta` and every other bare text
          control in the app do to `PressScale`'s app-wide 44. */}
      <PressScale onPress={onAnother} accessibilityRole="button" style={{ position: 'absolute', left: 0, right: 0, top: Y(764), minHeight: 0 }}>
        {/* the canvas leaves this run on the platform's own line box, and
            states no `text-wrap` on it either */}
        <AppText center style={[sans('500'), { fontSize: 15, color: '#8B8882' }, PLAIN_WRAP]}>
          Choose another
        </AppText>
      </PressScale>
    </TailFrame>
  );
}

// ── 29 · Start Here Step 1 ───────────────────────────────────────────
/** The phone on the nightstand, charging, away from the bed. */
export function O3StartHereStep1({ change, next }: { change: FirstChange; next: () => void }) {
  return (
    <TailFrame>
      <StepDots at={0} />
      <ArtBox>
        <SoftBlob id="s1-glow" left={58} top={6} width={124} height={124} color="rgb(226,186,120)" alpha={0.4} stop={0.74} />
        <SoftBlob id="s1-table-glow" left={68} top={150} width={104} height={28} color="rgb(226,186,120)" alpha={0.22} blur={5} />
        <Bit l={84} t={100} w={72} h={64} r={9} bg="#E0DFDA" />
        <Bit l={106} t={128} w={28} h={5} r={3} bg="#C6C5C0" />
        <Bit l={90} t={164} w={6} h={12} r={3} bg="#D6D5D0" />
        <Bit l={144} t={164} w={6} h={12} r={3} bg="#D6D5D0" />
        <Bit l={158} t={94} w={3} h={72} r={2} bg="#B4B1AB" />
        <Bit l={150} t={166} w={20} h={12} r={4} bg="#C6C5C0" />
        <Bit l={108} t={48} w={24} h={50} r={6} bg="#3A3934" />
        <Bit l={116} t={54} w={8} h={3} r={2} bg="#8B8882" />
        <Bit l={118} t={80} w={4} h={4} r="pill" bg="#E2BA78" />
        <SoftBlob id="s1-shadow" left={78} top={168} width={84} height={12} color="rgb(0,0,0)" alpha={0.1} blur={5} />
      </ArtBox>
      <TailCopy top={432} inset={36} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
        {change.steps[0].title}
      </TailCopy>
      <TailCopy top={516} inset={44} size={15.5} lineHeight={23} color="#55534E">
        {change.steps[0].note}
      </TailCopy>
      <TailCta label="Next" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── 30 · Start Here Step 2 ───────────────────────────────────────────
/** The bed, the moon and the open door — getting out of the room. */
export function O3StartHereStep2({ change, next }: { change: FirstChange; next: () => void }) {
  return (
    <TailFrame>
      <StepDots at={1} />
      <ArtBox>
        <SoftBlob id="s2-glow" left={50} top={44} width={120} height={120} color="rgb(226,186,120)" alpha={0.4} stop={0.74} />
        <Bit l={20} t={14} w={34} h={34} r="pill" bg="#DCDED8" />
        <Bit l={12} t={8} w={34} h={34} r="pill" bg="#F4F3F0" />
        <Bit l={24} t={120} w={96} h={30} corners={[10, 10, 4, 4]} bg="#E0DFDA" />
        <Bit l={30} t={112} w={44} h={15} r={8} bg="#C6C5C0" />
        <Bit l={18} t={120} w={6} h={52} r={3} bg="#D6D5D0" />
        <Bit l={118} t={120} w={6} h={52} r={3} bg="#D6D5D0" />
        <Bit l={168} t={40} w={52} h={138} r={8} bg="#E4E3DE" />
        <Bit l={174} t={46} w={34} h={126} r={5} gradient={['#F7F6F2', '#EDECE7']} />
        <SoftBlob id="s2-door-glow" left={150} top={150} width={70} height={26} color="rgb(226,186,120)" alpha={0.22} blur={5} />
        <Bit l={136} t={96} w={10} h={22} r={5} bg="#B4B1AB" />
        <SoftBlob id="s2-bed-shadow" left={12} top={174} width={116} height={14} color="rgb(0,0,0)" alpha={0.1} blur={5} />
        <SoftBlob id="s2-door-shadow" left={160} top={180} width={66} height={12} color="rgb(0,0,0)" alpha={0.08} blur={4} />
        <Bit l={28} t={128} w={88} h={8} r={4} bg="#D6D5D0" />
        <Bit l={96} t={186} w={56} h={9} r={5} bg="#E4E3DE" />
        <Bit l={216} t={20} w={2} h={2} r="pill" bg="rgba(200,225,235,0.4)" />
        <Bit l={6} t={52} w={2} h={2} r="pill" bg="rgba(200,225,235,0.3)" />
      </ArtBox>
      <TailCopy top={432} inset={36} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
        {change.steps[1].title}
      </TailCopy>
      <TailCopy top={548} inset={44} size={15.5} lineHeight={23} color="#55534E">
        {change.steps[1].note}
      </TailCopy>
      <TailCta label="Continue" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── 31 · Your Plan ───────────────────────────────────────────────────
/**
 * Five rows on hairlines: when, where, what sets it off, the first change and
 * what SOS does about it.
 *
 * The icons are the frame's own and belong to the *row*, not to the answer.
 * Two of the five contradict the picker's glyph set outright — `In bed` here
 * is a different bed from `15 · Place`'s — and the last two name things no
 * picker produces, so the canvas is plainly not mapping an answer to a glyph
 * on this board. The words vary with his answers; the drawing does not.
 * `DECISIONS.md` D055.
 */
const PLAN_ROW_SUBS = ['When it usually happens', 'Where it usually happens', 'What tends to set it off', 'Your first change', 'When an urge hits'];

function PlanIcon({ i }: { i: number }) {
  const stroke = { stroke: '#131313', strokeWidth: 2.2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, fill: 'none' };
  if (i === 0)
    return (
      <Svg width={22} height={22} viewBox="0 0 30 30">
        <Path d="M17 4 A10.5 10.5 0 1 0 25 20 A8.2 8.2 0 1 1 17 4 Z" fill="#131313" />
      </Svg>
    );
  if (i === 1)
    return (
      <Svg width={24} height={24} viewBox="0 0 24 24">
        <Path d="M3 18V8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10" {...stroke} />
        <Path d="M3 13h18M3 18v2M21 18v2M7 9.5h4v3.5H7z" {...stroke} />
      </Svg>
    );
  if (i === 2)
    return (
      <Svg width={22} height={22} viewBox="0 0 24 24">
        <Rect x={7} y={2.5} width={10} height={19} rx={2.5} {...stroke} />
        <Path d="M12 8v6M10 12l2 2 2-2" {...stroke} />
      </Svg>
    );
  if (i === 3)
    return (
      <Svg width={22} height={22} viewBox="0 0 24 24">
        <Path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0V8zM12 17v4" {...stroke} />
      </Svg>
    );
  return (
    <Svg width={22} height={22} viewBox="0 0 24 24">
      <Circle cx={12} cy={12} r={9} {...stroke} />
      <Circle cx={12} cy={12} r={3.5} {...stroke} />
      <Path d="M12 3v3M12 18v3M3 12h3M18 12h3" {...stroke} />
    </Svg>
  );
}

export function O3YourPlan({
  when,
  where,
  starter,
  change,
  next,
}: {
  when: string;
  where: string;
  starter: string;
  change: FirstChange;
  next: () => void;
}) {
  const rows = [when, where, starterFor(starter).row, change.row, 'SOS gets you out first'];
  return (
    <TailFrame>
      <TailCopy top={126} inset={26} size={22} lineHeight={29.04} weight="500" color="#1D1C1A" tracking={0.1}>
        Your plan
      </TailCopy>
      <View style={{ position: 'absolute', left: 28, right: 28, top: Y(190) }}>
        {rows.map((label, i) => (
          <View
            key={label}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 16,
              paddingVertical: 15,
              ...(i < rows.length - 1 ? { borderBottomWidth: 1, borderBottomColor: 'rgba(0,0,0,0.07)' } : null),
            }}>
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 24,
                backgroundColor: '#FFFFFF',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
                boxShadow: '0 0 0 1px rgba(0,0,0,0.08), 0 6px 14px rgba(40,38,32,0.08)',
              }}>
              <PlanIcon i={i} />
            </View>
            <View style={{ flex: 1 }}>
              {/* neither run states a `text-wrap` on the frame (D052) */}
              <AppText style={[sans('600'), { fontSize: 17, lineHeight: 22, color: '#1D1C1A' }, PLAIN_WRAP]}>{label}</AppText>
              <AppText style={[sans('400'), { marginTop: 3, fontSize: 13.5, lineHeight: 18, color: '#8B8882' }, PLAIN_WRAP]}>
                {PLAN_ROW_SUBS[i]}
              </AppText>
            </View>
          </View>
        ))}
      </View>
      <TailCta label="Continue" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── what the five boards read off the questionnaire ──────────────────
/**
 * The triple the four boards after `27` all share.
 *
 * `16 · What starts it` is looked up by its answer rather than by its key: the
 * step it replaced (`What Happens First`) carried a different id, and the
 * funnel content is generated, so keying on the words the picker offers
 * survives the rename.
 */
export function planReading(a: Record<string, string | string[]>, pick: number) {
  const triggers = (a.triggers as string[]) || [];
  const places = (a.places as string[]) || [];
  const signals = planSignals(triggers);
  const candidates = changeCandidates(signals);
  const starter = Object.values(a)
    .flatMap((v) => (Array.isArray(v) ? v : [v]))
    .find((v) => typeof v === 'string' && STARTER[v]) as string | undefined;
  // Where a picker went unanswered the canvas's own answer stands in, the same
  // way `planSignals` tops the chips up — every one of these words is on the
  // face of a board with no state for "he didn't say".
  const signal = candidates[pick % candidates.length];
  return {
    when: triggers[0] ?? signals[0],
    where: places[0] ?? 'In bed',
    starter: starter ?? 'I start scrolling',
    // `Choose another` walks his own signals in `CHANGE_ORDER`, wrapping round.
    signal,
    change: firstChangeFor(signal),
  };
}
