/**
 * Onboarding v3 — "the campaign" funnel, a native port of the canvas
 * screens-onb3 / onb3-map / onb3-tool. The funnel opens on near-black night
 * water; light gathers low and slow as the questions pass and breaks to paper
 * exactly at the reading. Progress is one growing ink rule; days and weeks are
 * Roman numerals. No scores, no comparison stats, no countdowns, no fake deals.
 *
 * Exposes the step components + an O3Tone context so primitives flip between
 * the night register and the paper register automatically.
 */
import { createContext, useContext, useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { Platform, TextInput, View, type TextStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Defs, Ellipse, FeGaussianBlur, Filter, G, Line, LinearGradient as LinearGradientSvg, Path, Polygon, Polyline, RadialGradient, Rect, Stop, Text as SvgText } from 'react-native-svg';

import { AppText, Grain } from '@/components/ui';
import { PressScale } from '@/components/ui/press-scale';
import { FUNNEL_GLYPHS, FUNNEL_STEPS, type FunnelArt, type FunnelField, type FunnelMark, type FunnelStep, type FunnelSvgKid } from '@/content/onboardingFunnel';
import { WEEK_XII_LETTER } from '@/content/weekXiiLetter';
import { colors, sans } from '@/lib/theme';
import {
  CAMPAIGN_WEEKS,
  CampaignMapField,
  CampaignMapRail,
  CampaignWeekRow,
  OnbPaperField,
  PlanReadyField,
} from './art';

const noiseDark = require('../../../assets/images/noise-dark.png');

// ── the two registers ────────────────────────────────────────────────
export type Tone = {
  bg: string;
  card: string;
  ink: string;
  ink2: string;
  ink3: string;
  ink4: string;
  line: string;
  soft2: string;
  /** The unfilled half of the rule at the top of every funnel screen. */
  track: string;
  fill: string;
  onFill: string;
};
const NIGHT: Tone = {
  bg: '#0F0F0D',
  card: 'rgba(255,255,255,0.07)',
  ink: '#F4F3F0',
  ink2: 'rgba(244,243,240,0.7)',
  ink3: 'rgba(244,243,240,0.55)',
  ink4: 'rgba(244,243,240,0.3)',
  line: 'rgba(255,255,255,0.1)',
  soft2: 'rgba(255,255,255,0.22)',
  track: 'rgba(255,255,255,0.2)',
  fill: '#F4F3F0',
  onFill: '#131313',
};
const PAPER: Tone = {
  // Daylight paper is a shade brighter than the app's field — the reading is
  // meant to feel like the sun finally came up on it.
  bg: '#FAF9F8',
  card: colors.surface,
  ink: colors.text,
  ink2: colors.textMuted,
  ink3: colors.textSoft,
  ink4: colors.textSofter,
  line: colors.border,
  soft2: colors.borderStrong,
  track: 'rgba(0,0,0,0.12)',
  fill: colors.ink,
  onFill: colors.inkText,
};
const O3Tone = createContext<Tone>(NIGHT);
const useTone = () => useContext(O3Tone);

// ── the funnel's night field ─────────────────────────────────────────
/**
 * Every funnel frame authors its own field: the 180° ground, the low sun's box
 * and hang, and the two stated stops of its glow. The values live in
 * `src/content/onboardingFunnel.ts`, read off the canvas by
 * `scripts/vicifull/gen-funnel.mjs`, so nothing here is inferred from a
 * progress fraction.
 *
 * They do not ramp in this bundle's flow order, and the progress rule is not
 * monotonic: the reshuffle left each frame with the values it had in its old
 * position. DECISIONS.md D014 has the evidence and the reason it is built as
 * drawn rather than recomputed.
 */
export type O3Field = { rule: number; top: string; bot: string; sun: number; off: number; glow: string; a0: number; a45: number; hasSun: boolean };

export function o3Field(f: FunnelField): O3Field {
  return {
    rule: f.rule,
    top: f.top,
    bot: f.bottom,
    sun: f.sun?.size ?? 420,
    // the canvas hangs the sun off the bottom edge with a negative `bottom`
    off: f.sun?.bottom ?? -231,
    glow: f.sun?.color ?? '#FFECC4',
    a0: f.sun?.a0 ?? 0.1,
    a45: f.sun?.a45 ?? 0.05,
    // `16 · Impact` is the one funnel frame that draws no low sun; its ground
    // is the linear field and the corner bloom and nothing else.
    hasSun: f.sun != null,
  };
}

/** `06 · Start` — the field the funnel opens on, and the shell's fallback. */
const O3_OPENING_FIELD = o3Field(FUNNEL_STEPS[3].field);
/** `23 · Goal confirmation` — the last night frame, held by the paper tail. */
const O3_CLOSING_FIELD = o3Field(FUNNEL_STEPS[FUNNEL_STEPS.length - 1].field);

/**
 * Only the screen on the frame knows which frame it is — the funnel's step
 * index counts the reading pause and the whole paper tail as well. A screen
 * that knows its field publishes it here and the shell draws it.
 */
const O3FieldCtx = createContext<((v: O3Field | null) => void) | null>(null);
export function useO3Field(v: O3Field | null) {
  const publish = useContext(O3FieldCtx);
  // A field object rebuilt every render would republish on every render; the
  // funnel's fields are constants, so compare on their values.
  const key = v ? JSON.stringify(v) : null;
  useEffect(() => {
    if (!key) return;
    publish?.(JSON.parse(key) as O3Field);
    return () => publish?.(null);
  }, [publish, key]);
}

// ── roman numerals ───────────────────────────────────────────────────
export function o3Roman(n: number): string {
  const T: [number, string][] = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
  let s = '';
  let v = Math.max(1, Math.round(n));
  for (const [k, r] of T) while (v >= k) { s += r; v -= k; }
  return s;
}

/** Which paper field a lit frame states — 096 and 107 each carry their own. */
export type O3Paper = 'default' | 'plan' | 'map' | 'plain';

// ── the shell: night ground, gathering light, a growing ink rule ─────
export function O3Shell({
  progress = 0,
  onBack,
  bar = true,
  lit = false,
  paper = 'default',
  segments,
  backTop,
  children,
}: {
  progress?: number;
  onBack?: (() => void) | null;
  bar?: boolean;
  lit?: boolean;
  paper?: O3Paper;
  /** The eight-segment rule the paper tail draws, and how many are inked. */
  segments?: number;
  /** Back sits at y 94 on the night frames, 96 on the paper ones, 64 on the map. */
  backTop?: number;
  children: ReactNode;
}) {
  const tone = lit ? PAPER : NIGHT;
  const [frame, setFrame] = useState<O3Field | null>(null);
  // Screens outside the questionnaire publish no field: the paper tail stands
  // after it and holds the closing one, anything before it the opening one.
  const field = frame ?? (progress < 0.5 ? O3_OPENING_FIELD : O3_CLOSING_FIELD);
  // The canvas states the rule's width on the frame. Screens that state none
  // fall back to their position in the run.
  const pct = frame == null ? Math.round(Math.max(0.04, Math.min(1, progress)) * 100) : field.rule;
  // The chrome is drawn off the canvas frame: rule at y 66, Back at y 94, both
  // measured below the 54pt status bar the safe-area inset stands in for.
  const backInk = lit ? tone.ink2 : 'rgba(244,243,240,0.75)';
  return (
    <O3FieldCtx.Provider value={setFrame}>
      <O3Tone.Provider value={tone}>
        <View style={{ flex: 1, backgroundColor: tone.bg }}>
          {/* the ambient light gathering low, or daylight on paper */}
          <Ambient field={field} lit={lit} paper={paper} />
          <SafeAreaView edges={['top']} style={{ flex: 1 }}>
            {/* Yoga positions an absolutely-placed child from its parent's
                BORDER box and never consults padding, and SafeAreaView spends
                the inset as padding — so the rule and the Back row have to sit
                inside a plain view that already starts at the inset, or they
                draw across the status bar on device. */}
            <View style={{ flex: 1 }}>
              {bar && segments != null ? (
                /* the paper tail counts in eight ticks rather than one rule */
                <View style={{ position: 'absolute', left: 24, right: 24, top: 12, flexDirection: 'row', gap: 8 }}>
                  {Array.from({ length: 8 }, (_, k) => (
                    <View key={k} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: k < segments ? '#131313' : 'rgba(0,0,0,0.14)' }} />
                  ))}
                </View>
              ) : bar ? (
                <View style={{ position: 'absolute', left: 24, right: 24, top: 12, height: 4, borderRadius: 2, backgroundColor: tone.track }}>
                  <View style={{ height: 4, width: `${pct}%`, borderRadius: 2, backgroundColor: tone.ink }} />
                </View>
              ) : null}
              {onBack ? (
                <PressScale
                  onPress={onBack}
                  accessibilityRole="button"
                  accessibilityLabel="Back"
                  hitSlop={{ top: 16, bottom: 16, left: 16, right: 24 }}
                  style={{ position: 'absolute', left: 16, top: backTop ?? 40, minHeight: 0, flexDirection: 'row', alignItems: 'center', gap: 9 }}>
                  <Svg width={11} height={19} viewBox="0 0 11 19" fill="none">
                    <Path d="M9.5 1.5L2 9.5l7.5 8" stroke={backInk} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
                  </Svg>
                  <AppText style={[sans('400'), { fontSize: 17, color: backInk }]}>Back</AppText>
                </PressScale>
              ) : null}
              {/* Padding for the flowed screens; the canvas-placed ones position
                  absolutely, which Yoga measures from this box's edge, not its
                  content — so their lefts and tops are the frame's own numbers. */}
              <View style={{ flex: 1, paddingHorizontal: 24, paddingTop: 76, paddingBottom: 32 }}>{children}</View>
            </View>
          </SafeAreaView>
        </View>
      </O3Tone.Provider>
    </O3FieldCtx.Provider>
  );
}

// gathering light: a wide pale bloom low, a warmer core arriving later
function Ambient({ field, lit, paper = 'default' }: { field: O3Field; lit: boolean; paper?: O3Paper }) {
  // Daylight. Three of the paper frames state their own field, so each is drawn
  // from its own numbers rather than tinted off a shared one; 108 states none
  // at all and stands on flat white.
  if (lit) {
    if (paper === 'plain') return <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#FFFFFF' }} />;
    if (paper === 'plan') return <PlanReadyField />;
    if (paper === 'map') return <CampaignMapField />;
    return <OnbPaperField />;
  }
  // Night: every value is the frame's own, off O3_FIELD — the field ends, the
  // sun's box and hang, and the glow's colour and two stops.
  const { sun, off, glow, a0, a45, hasSun } = field;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
      <LinearGradient colors={[field.top, field.bot]} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      {/* the bloom off the top-left corner — the canvas blurs it 6px, and with
          no blur filter in RN SVG the gradient's own falloff carries it. Every
          frame in the run states the same box and stops.
          The canvas writes `rgba(19,19,19,0)` at the fade stop and that RGB is
          a null: CSS interpolates premultiplied, so only the alpha falls. SVG
          interpolates non-premultiplied, so the literal transcription ramps the
          wash toward black and paints it dark. The zero-alpha stop repeats the
          opaque stop's RGB instead (D105). Cross-group edit from the `tail`
          agent: the identical line, and the same measurement. */}
      <Svg width={540} height={270} style={{ position: 'absolute', left: -40, top: -140 }}>
        <Defs>
          <RadialGradient id="o3bloom" cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#B4AA96" stopOpacity={0.14} />
            <Stop offset="0.72" stopColor="#B4AA96" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={270} cy={135} rx={270} ry={135} fill="url(#o3bloom)" />
      </Svg>
      {hasSun ? (
        <Svg width={sun} height={sun} style={{ position: 'absolute', left: '50%', marginLeft: -sun / 2, bottom: off }}>
          <Defs>
            <RadialGradient id="o3sun" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor={glow} stopOpacity={a0} />
              <Stop offset="0.45" stopColor={glow} stopOpacity={a45} />
              <Stop offset="0.72" stopColor={glow} stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={sun / 2} cy={sun / 2} rx={sun / 2} ry={sun / 2} fill="url(#o3sun)" />
        </Svg>
      ) : null}
      <Grain source={noiseDark} opacity={0.12} />
    </View>
  );
}

// ── voice primitives ─────────────────────────────────────────────────
export function O3H({ children, size = 22, style }: { children: ReactNode; size?: number; style?: object }) {
  const tone = useTone();
  return (
    <AppText center style={[sans('500'), { fontSize: size, lineHeight: size * 1.32, letterSpacing: 0.1, color: tone.ink, maxWidth: 305, alignSelf: 'center' }, style]}>
      {children}
    </AppText>
  );
}
export function O3Sub({ children, style }: { children: ReactNode; style?: object }) {
  const tone = useTone();
  return (
    <AppText center style={[sans('400'), { fontSize: 15, lineHeight: 23, color: tone.ink2, maxWidth: 315, alignSelf: 'center', marginTop: 12 }, style]}>
      {children}
    </AppText>
  );
}
export function O3Eyebrow({ children, style }: { children: ReactNode; style?: object }) {
  const tone = useTone();
  return (
    <AppText center style={[sans('600'), { fontSize: 10.5, letterSpacing: 2.3, textTransform: 'uppercase', color: tone.ink3 }, style]}>
      {children}
    </AppText>
  );
}
export function O3Note({ children, style }: { children: ReactNode; style?: object }) {
  const tone = useTone();
  return (
    <AppText center style={[sans('400'), { fontSize: 12, lineHeight: 18, color: tone.ink3, maxWidth: 280, alignSelf: 'center' }, style]}>
      {children}
    </AppText>
  );
}
export function O3CTA({
  label,
  onClick,
  enabled = true,
  ghost = false,
  size = 'lg',
  style,
}: {
  label: string;
  onClick?: () => void;
  enabled?: boolean;
  ghost?: boolean;
  /** `md` is the questionnaire's 56pt pill, `lg` the 58pt one the last cards use. */
  size?: 'md' | 'lg';
  style?: object;
}) {
  const tone = useTone();
  if (ghost) {
    return (
      <View style={{ alignItems: 'center' }}>
        <PressScale onPress={onClick} style={{ paddingHorizontal: 20, paddingVertical: 14 }}>
          <AppText style={[sans('500'), { fontSize: 14, color: tone.ink2 }, style as object]}>{label}</AppText>
        </PressScale>
      </View>
    );
  }
  const md = size === 'md';
  return (
    <PressScale
      onPress={enabled ? onClick : undefined}
      disabled={!enabled}
      accessibilityRole="button"
      style={{
        height: md ? 56 : 58,
        backgroundColor: tone.fill,
        borderRadius: md ? 28 : 29,
        alignItems: 'center',
        justifyContent: 'center',
        opacity: enabled ? 1 : 0.26,
        ...(style as object),
      }}>
      <AppText style={[sans('600'), { fontSize: md ? 16.5 : 17, letterSpacing: md ? 0 : 0.2, color: tone.onFill }]}>{label}</AppText>
    </PressScale>
  );
}

/**
 * The 56pt pale pill — the section intros and every multi-select — sits at
 * y 744 on the 852 frame, so 52 up from the bottom. (The 58pt one the typed
 * and single-answer frames use sits at the same 744 and lands on 50.)
 */
export const O3_MD_CTA_BOTTOM = 852 - 744 - 56;

/**
 * The dark pill the paper tail ends on. Height, radius and tracking are the
 * frame's own — 097–105 draw 58/29, 096 draws 56/28, 108 draws 54/27, and
 * 106 · 107 widen the tracking to 0.3.
 */
function O3PaperCTA({ label, onPress, y, h = 58, ls = 0.2, enabled = true }: { label: string; onPress: () => void; /** The pill's canvas top. */ y: number; h?: 54 | 56 | 58; ls?: number; enabled?: boolean }) {
  return (
    <PressScale
      onPress={enabled ? onPress : undefined}
      disabled={!enabled}
      accessibilityRole="button"
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        bottom: 852 - y - h,
        height: h,
        minHeight: 0,
        borderRadius: h / 2,
        backgroundColor: '#131313',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: enabled ? 1 : 0.26,
      }}>
      <AppText style={[sans('600'), { fontSize: 17, letterSpacing: ls, color: '#FFFFFF' }]}>{label}</AppText>
    </PressScale>
  );
}

function O3Tick({ c }: { c: string }) {
  return (
    <Svg width={16} height={12} viewBox="0 0 16 12" fill="none">
      <Path d="M1.5 6l4.4 4.5L14.5 1.5" stroke={c} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

// ── the chip — one answer row, 60 tall, flooding ink when chosen ─────
export function O3Chip({ label, on, picked = false, onClick }: { label: string; on: boolean; picked?: boolean; onClick: () => void }) {
  const tone = useTone();
  const chosen = on || picked;
  return (
    <PressScale
      onPress={onClick}
      accessibilityRole="button"
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 12,
        paddingHorizontal: 22,
        borderRadius: 16,
        height: 60,
        backgroundColor: chosen ? tone.fill : tone.card,
        boxShadow: chosen ? undefined : `0 0 0 1px ${tone.soft2}`,
      }}>
      <AppText style={[sans('500'), { flex: 1, fontSize: 17, lineHeight: 20, color: chosen ? tone.onFill : tone.ink }]}>{label}</AppText>
      {chosen ? <O3Tick c={tone.onFill} /> : null}
    </PressScale>
  );
}

// ── option glyphs — the tile strokes from the canvas, path for path.
// Several tiles reuse one glyph across questions (the bed is both "Can’t
// sleep" and "Bedroom"), which is why the cases fall through ──

export type O3Opt = { label: string; fs?: number };
export type O3Kind = 'list' | 'grid' | 'check' | 'text' | 'number';

const INK = '#F4F3F0';
const ON_INK = '#131313';

/**
 * CSS's own wrapping, for a run the frame gives no `text-wrap`.
 *
 * `AppText` puts `text-wrap: pretty` on every body run on web, and the funnel's
 * frames state a `text-wrap` only on the title and the two notes. On a tile
 * label `pretty` pulls a word down and the label breaks one word early —
 * `11 · When` draws "When I can’t / sleep" and got "When I / can’t sleep".
 * Web only, the same guard `AppText` uses; `text-wrap` has no native analogue.
 */
const PLAIN_WRAP = Platform.OS === 'web' ? ({ textWrap: 'wrap' } as unknown as TextStyle) : null;

/**
 * The question engine — one shell across thirty-three frames.
 *
 * Everything is placed off the 393 × 852 canvas frame: title at y 158, the
 * "select all" line at 226, answer rows from 310 in 74pt steps, the pill at
 * 764. Absolute, because the frame holds the rows at a fixed y whether the
 * question wraps to one line or three.
 */
/**
 * One funnel step, drawn from its own frame's numbers.
 *
 * `FUNNEL_STEPS` carries every screen's copy, option list, per-option font
 * size, row tops and CTA straight off the canvas, so this renders a step
 * rather than a question shape: a typed field, a list, a 3-up glyph grid, a
 * checkbox list, a statement, or the one teaching card.
 *
 * Design y minus 54 throughout — the canvas frame's status bar is the safe-area
 * inset here (DECISIONS.md D009).
 */
const Y = (top: number) => top - 54;

/**
 * The three screens whose "none of these" answer clears the rest.
 *
 * A frame can draw a chosen row and an unchosen one; it cannot draw a rule
 * about which pairs are legal. These come from the questionnaire's own change
 * log (`.vicifull/QUESTIONNAIRE-CHANGES.txt` §5), which the run brief makes the
 * authority on branching and selection logic.
 */
const O3_EXCLUSIVE: Record<string, string> = {
  emotions: 'Nothing in particular', // 12 · Beforehand
  before: 'Nothing obvious', //         14 · What starts it
  tried: 'Nothing yet', //              22 · What you’ve tried
};
/** `17 · What it affects` says "Choose up to three" and means it. */
const O3_MAX_PICKS: Record<string, number> = { affects: 3 };

/**
 * `23 · Goal confirmation` reads the man's stated goal back to him, and the
 * canvas draws one of its five readings: goal "stop", with the masturbation
 * clarifier under it. The other four exist only in the questionnaire doc (§23),
 * which governs the variants no frame draws.
 *
 * The doc writes the shared second line as "That’s what we’ll build around";
 * the frame draws "That’s what we’ll work toward" for the case it shows, and
 * the brief says the frame wins for anything visible. The doc gives stop,
 * reduce and limit the *same* second line as each other, so the frame's
 * revision is read as a revision of that shared line and all three carry it.
 * "I’m not sure yet" has its own line in the doc and no frame, so it keeps it.
 */
const O3_GOAL_CONFIRM: Record<string, [string, string]> = {
  'Stop completely': ['You want to stop.', 'That’s what we’ll work toward.'],
  'Watch much less': ['You want porn to take up a lot less of your life.', 'That’s what we’ll work toward.'],
  'Set a limit and stick to it': ['You want to set a limit and actually keep it.', 'That’s what we’ll work toward.'],
  'I’m not sure yet': ['You don’t need to decide forever today.', 'We’ll start with getting the choice back.'],
};
/** The fifth line is drawn only for the one masturbation answer that earns it. */
const O3_GOAL_CONFIRM_MAST = 'Keep it, just without porn';

export function O3FunnelStep({
  step,
  value,
  onSet,
  next,
  name,
  answers,
}: {
  step: FunnelStep;
  value: string | string[] | undefined;
  onSet: (v: string | string[]) => void;
  next: () => void;
  /** The canvas writes the sample name "Sam" into two screens' copy. */
  name?: string;
  /** `23 · Goal confirmation` is the one board that reads earlier answers. */
  answers?: Record<string, string | string[]>;
}) {
  const [picked, setPicked] = useState<string | null>(null);
  useO3Field(o3Field(step.field));

  const multi = step.multi;
  const chosen = multi ? ((value as string[]) || []) : [];
  const hasCta = step.cta != null;

  // A frame the canvas gives no button turns itself over — one beat, so the
  // ink flood reads as the answer before the next question arrives.
  useEffect(() => {
    if (!picked || hasCta) return;
    const id = setTimeout(next, 260);
    return () => clearTimeout(id);
  }, [picked, hasCta, next]);

  const isOn = (label: string) => (multi ? chosen.includes(label) : value === label || picked === label);
  const pick = (label: string) => {
    if (multi) {
      if (chosen.includes(label)) {
        onSet(chosen.filter((x) => x !== label));
        return;
      }
      const solo = O3_EXCLUSIVE[step.id];
      if (solo === label) {
        onSet([label]);
        return;
      }
      const rest = solo ? chosen.filter((x) => x !== solo) : chosen;
      // The cap is the hint's own promise, so a fourth tap is refused rather
      // than silently dropping the answer he chose first.
      const cap = O3_MAX_PICKS[step.id];
      if (cap != null && rest.length >= cap) return;
      onSet([...rest, label]);
      return;
    }
    onSet(label);
    setPicked(label);
  };
  // `17 · What it affects` takes an empty answer from a man who has just said
  // porn is not really in the way — the doc's own exception to "select all
  // that apply" needing one.
  const zeroOk = step.id === 'affects' && answers?.impact === 'Not really';
  const goal = step.id === 'goalConfirm' ? O3_GOAL_CONFIRM[String(answers?.goalPorn ?? '')] : undefined;
  // The clarifier belongs to one masturbation answer; every other reading of
  // `21 · Masturbation goal` leaves the board at two lines.
  const showFine = step.id !== 'goalConfirm' || answers?.goalMast === O3_GOAL_CONFIRM_MAST;

  let body: ReactNode = null;

  if (step.kind === 'text' || step.kind === 'number') {
    const isNum = step.kind === 'number';
    const text = String(value || '');
    body = (
      <View
        style={{
          position: 'absolute',
          left: 24,
          right: 24,
          top: Y(step.fieldTop ?? 281),
          height: 60,
          borderRadius: 16,
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 22,
          gap: 3,
          backgroundColor: 'rgba(255,255,255,0.07)',
          boxShadow: '0 0 0 1px rgba(255,255,255,0.22)',
        }}>
        {isNum ? (
          <>
            {/* `04 · Age` draws the value and then a 2 x 22 caret bar 3pt after
                it. A stretched field would push the bar to the row's edge, so
                the value is a text run and the field is a transparent layer
                over the whole row that takes the typing. */}
            <AppText style={[sans('500'), { fontSize: 17, color: INK, fontVariant: ['tabular-nums'] as const }]}>{text}</AppText>
            <View style={{ width: 2, height: 22, borderRadius: 1, backgroundColor: INK }} />
          </>
        ) : (
          /* `03 · Name` puts the bar *before* the placeholder, in flow, with
             the row's 3pt gap after it — the frame's stand-in for a caret,
             which a static div cannot show. It keeps its space once there is a
             value so nothing shifts, and hands the blinking over to the native
             caret. */
          <View style={{ width: 2, height: 22, borderRadius: 1, backgroundColor: INK, opacity: text ? 0 : 1 }} />
        )}
        <TextInput
          value={text}
          onChangeText={onSet}
          placeholder={isNum ? '' : step.placeholder}
          placeholderTextColor="rgba(244,243,240,0.45)"
          keyboardType={isNum ? 'number-pad' : 'default'}
          autoCapitalize={isNum ? 'none' : 'words'}
          maxLength={isNum ? 3 : 40}
          selectionColor={INK}
          caretHidden={isNum || !text}
          style={[
            sans(isNum ? '500' : '400'),
            isNum
              ? { position: 'absolute', left: 0, right: 0, top: 0, height: 60, opacity: 0, fontSize: 17, paddingHorizontal: 22 }
              : { flex: 1, height: 60, fontSize: 17, color: INK },
          ]}
        />
      </View>
    );
  } else if (step.kind === 'grid') {
    const rows: typeof step.options[] = [];
    for (let i = 0; i < step.options.length; i += 3) rows.push(step.options.slice(i, i + 3));
    body = rows.map((row, r) => (
      <View key={r} style={{ position: 'absolute', left: 24, right: 24, top: Y(step.rowTops?.[r] ?? 278 + 102 * r), flexDirection: 'row', gap: 10 }}>
        {row.map((opt) => {
          const on = isOn(opt.label);
          return (
            <PressScale
              key={opt.label}
              onPress={() => pick(opt.label)}
              accessibilityRole="button"
              accessibilityState={{ selected: on }}
              style={{
                flex: 1,
                height: 94,
                borderRadius: 16,
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                paddingHorizontal: 4,
                backgroundColor: on ? INK : 'rgba(255,255,255,0.07)',
                boxShadow: on ? '0 0 0 1px rgba(0,0,0,0)' : '0 0 0 1px rgba(255,255,255,0.2)',
              }}>
              {on ? (
                <View style={{ position: 'absolute', right: 8, top: 8, width: 15, height: 15, borderRadius: 7.5, backgroundColor: ON_INK, alignItems: 'center', justifyContent: 'center' }}>
                  <Svg width={8} height={6} viewBox="0 0 16 12" fill="none">
                    <Path d="M1.5 6l4.4 4.5L14.5 1.5" stroke={INK} strokeWidth={2.8} strokeLinecap="round" strokeLinejoin="round" />
                  </Svg>
                </View>
              ) : null}
              <FunnelGlyphMark label={opt.label} color={on ? ON_INK : INK} />
              {/* two tiles carry a `<br>` and a `max-width`, so the canvas's
                  own break is kept rather than left to the measurer */}
              <AppText center style={[sans('500'), PLAIN_WRAP, { fontSize: opt.size, lineHeight: 15, color: on ? ON_INK : INK, maxWidth: opt.maxWidth }]}>
                {opt.lines ? opt.lines.join('\n') : opt.label}
              </AppText>
            </PressScale>
          );
        })}
        {row.length < 3 ? Array.from({ length: 3 - row.length }, (_, k) => <View key={`gap${k}`} style={{ flex: 1 }} />) : null}
      </View>
    ));
  } else if (step.kind === 'check') {
    body = step.options.map((opt) => {
      const on = isOn(opt.label);
      return (
        <PressScale
          key={opt.label}
          onPress={() => pick(opt.label)}
          accessibilityRole="checkbox"
          accessibilityState={{ checked: on }}
          style={{
            position: 'absolute',
            left: 24,
            right: 24,
            top: Y(opt.top ?? 276),
            height: 52,
            borderRadius: 15,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 14,
            paddingHorizontal: 18,
            backgroundColor: on ? 'rgba(255,255,255,0.13)' : 'rgba(255,255,255,0.06)',
            boxShadow: on ? '0 0 0 1px rgba(255,255,255,0.45)' : '0 0 0 1px rgba(255,255,255,0.18)',
          }}>
          <View
            style={{
              width: 22,
              height: 22,
              borderRadius: 7,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: on ? INK : undefined,
              boxShadow: on ? undefined : 'inset 0 0 0 1.5px rgba(244,243,240,0.4)',
            }}>
            {on ? (
              <Svg width={12} height={9} viewBox="0 0 16 12" fill="none">
                <Path d="M1.5 6l4.4 4.5L14.5 1.5" stroke={ON_INK} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
            ) : null}
          </View>
          <AppText style={[sans('500'), PLAIN_WRAP, { flexShrink: 1, fontSize: opt.size, lineHeight: 19, color: INK }]}>{opt.label}</AppText>
          {/* `margin-left:auto` on the canvas — it stays #F4F3F0 at 55% in both
              states, so it takes no ink swap */}
          {opt.mark ? <FunnelRowMark mark={opt.mark} on={false} style={{ marginLeft: 'auto', flexShrink: 0 }} /> : null}
        </PressScale>
      );
    });
  } else if (step.kind === 'list') {
    body = step.options.map((opt) => {
      const on = isOn(opt.label);
      return (
        <PressScale
          key={opt.label}
          onPress={() => pick(opt.label)}
          accessibilityRole="button"
          accessibilityState={{ selected: on }}
          style={{
            position: 'absolute',
            left: 24,
            right: 24,
            top: Y(opt.top ?? 310),
            height: 60,
            borderRadius: 16,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 12,
            paddingHorizontal: 22,
            backgroundColor: on ? INK : 'rgba(255,255,255,0.07)',
            // the canvas keeps a 1px ring on the selected pill too, at zero alpha
            boxShadow: on ? '0 0 0 1px rgba(0,0,0,0)' : '0 0 0 1px rgba(255,255,255,0.22)',
          }}>
          {opt.mark ? <FunnelRowMark mark={opt.mark} on={on} style={{ flexShrink: 0 }} /> : null}
          {/* the boards that gained a mark stretch the label with `flex: 1`;
              `05 · Gender`, which gained neither, keeps a span that takes its
              own words' width and would measure differently if stretched */}
          <AppText style={[sans('500'), PLAIN_WRAP, opt.flex1 ? { flex: 1 } : { flexShrink: 1 }, { fontSize: opt.size, lineHeight: 20, color: on ? ON_INK : INK }]}>{opt.label}</AppText>
          {on ? <O3Tick c={ON_INK} /> : null}
        </PressScale>
      );
    });
  } else if (step.kind === 'card') {
    body = <FirstPrincipleArt />;
  }

  const title = step.title ? withName(goal?.[0] ?? step.title.text, name) : null;

  return (
    <>
      {step.title ? (
        <AppText
          center
          style={[
            sans('500'),
            {
              position: 'absolute',
              left: step.title.inset ?? 44,
              right: step.title.inset ?? 44,
              top: Y(step.title.top),
              fontSize: step.title.size,
              lineHeight: (step.title.size ?? 22) * (step.title.lineHeight ?? 1.32),
              letterSpacing: step.title.tracking,
              color: INK,
            },
            // The canvas balances the three statement boards' headline and
            // lets the questions wrap `pretty`. Neither has an RN equivalent on
            // iOS; React Native Web passes both straight to CSS, so the frames'
            // own breaks come out on the preview and the greedy wrap stands on
            // device.
            Platform.OS === 'web' ? ({ textWrap: step.title.wrap ?? 'wrap' } as unknown as TextStyle) : null,
          ]}>
          {title}
        </AppText>
      ) : null}
      {step.hint ? (
        <AppText center style={[sans('500'), PLAIN_WRAP, { position: 'absolute', left: 0, right: 0, top: Y(step.hint.top), fontSize: 13, color: 'rgba(244,243,240,0.55)' }]}>
          {step.hint.text}
        </AppText>
      ) : null}
      {step.art ? <FunnelArtBlock art={step.art} /> : null}
      {body}
      {step.note2 ? (
        <AppText
          center
          style={[
            sans('400'),
            {
              position: 'absolute',
              left: step.note2.inset ?? 44,
              right: step.note2.inset ?? 44,
              top: Y(step.note2.top),
              fontSize: step.note2.size,
              lineHeight: step.note2.lineHeight,
              color: step.note2.size === 13.5 ? 'rgba(244,243,240,0.6)' : step.kind === 'card' ? 'rgba(244,243,240,0.75)' : 'rgba(244,243,240,0.7)',
            },
            Platform.OS === 'web' ? ({ textWrap: step.note2.wrap ?? 'wrap' } as unknown as TextStyle) : null,
          ]}>
          {withName(goal?.[1] ?? step.note2.text, name)}
        </AppText>
      ) : null}
      {step.fine && showFine ? (
        <AppText
          center
          style={[
            sans('400'),
            {
              position: 'absolute',
              left: step.fine.inset ?? 44,
              right: step.fine.inset ?? 44,
              top: Y(step.fine.top),
              fontSize: step.fine.size,
              lineHeight: step.fine.lineHeight,
              color: 'rgba(244,243,240,0.5)',
            },
            Platform.OS === 'web' ? ({ textWrap: step.fine.wrap ?? 'wrap' } as unknown as TextStyle) : null,
          ]}>
          {withName(step.fine.text, name)}
        </AppText>
      ) : null}
      {step.kind === 'card' ? <O3PagerDots count={4} index={0} top={Y(712)} /> : null}
      {step.cta ? (
        <O3CTA
          size={step.cta.height === 56 ? 'md' : 'lg'}
          label={step.cta.label}
          enabled={multi ? chosen.length > 0 || zeroOk : true}
          onClick={next}
          style={{ position: 'absolute', left: 24, right: 24, top: Y(step.cta.top) }}
        />
      ) : null}
    </>
  );
}

/**
 * The canvas writes the sample name "Sam" into two screens' copy. The app knows
 * the real one, and the man told it to us three screens earlier.
 */
function withName(text: string, name?: string): string {
  const given = (name ?? '').trim();
  if (!given) return text;
  return text.replace(/^Sam\b/, given);
}

/**
 * Where an under-18 leaves the funnel.
 *
 * `04 · Age` states its own gate — "if age < 18, leave the adult onboarding
 * flow and show an age-appropriate support message" — in the questionnaire doc
 * and nowhere else: the bundle draws no frame for the board he lands on. So it
 * is built out of the vocabulary the two statement boards either side of it
 * already state (`06 · Start`, `15 · Transition`): the age board's own night
 * field, a 26/500 headline at design y 338 on a 36 inset, a 15.5/400 line at
 * 434 on a 44 inset, the Back row, and no way forward — which is the point.
 *
 * The words are the one thing here the bundle does not supply. They are
 * written plainly and flagged in REPORT.md; if the canvas draws this board
 * later, the frame wins.
 */
export const O3_AGE_MIN = 18;
export function O3AgeGate() {
  useO3Field(o3Field(FUNNEL_STEPS[1].field));
  return (
    <>
      <AppText
        center
        style={[
          sans('500'),
          { position: 'absolute', left: 36, right: 36, top: Y(338), fontSize: 26, lineHeight: 26 * 1.3, letterSpacing: -0.2, color: INK },
          Platform.OS === 'web' ? ({ textWrap: 'balance' } as unknown as TextStyle) : null,
        ]}>
        This one is for over-18s.
      </AppText>
      <AppText
        center
        style={[
          sans('400'),
          { position: 'absolute', left: 44, right: 44, top: Y(434), fontSize: 15.5, lineHeight: 24, color: 'rgba(244,243,240,0.7)' },
          Platform.OS === 'web' ? ({ textWrap: 'pretty' } as unknown as TextStyle) : null,
        ]}>
        Come back when you are. If porn is already getting in the way, someone you trust — a doctor, a counsellor, a parent — is a better first step than an app.
      </AppText>
    </>
  );
}

/** The four dots under the one teaching card the bundle still draws. */
function O3PagerDots({ count, index, top }: { count: number; index: number; top: number }) {
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top, flexDirection: 'row', justifyContent: 'center', gap: 10 }}>
      {Array.from({ length: count }, (_, i) => (
        <View key={i} style={{ width: 7, height: 7, borderRadius: 3.5, backgroundColor: i === index ? '#F4F3F0' : 'rgba(255,255,255,0.25)' }} />
      ))}
    </View>
  );
}

/**
 * `10 · First Principle` — the wave that breaks, with the gap where the urge
 * passes and three thin arcs running through it.
 *
 * The block is `left:0 right:0 top:206` and 310 tall; everything below is the
 * canvas's own offset inside it.
 */
function FirstPrincipleArt() {
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: Y(206), height: 310 }}>
      {/* the warm bloom — blurred 7px on the canvas, and a closest-side radial
          already dies at its own edge, so the gradient carries it.
          The canvas states two stops and both name the same RGB, so the CSS
          ramp is linear in alpha and a two-stop SVG radial reproduces it
          exactly (D048). D010's `x 0.42` midpoint at half radius — 0.126 where
          the linear ramp is 0.15 — was still here, and it is the whole of the
          band's 2–6/255 shortfall against the frame. */}
      <Svg width={220} height={200} style={{ position: 'absolute', left: '50%', marginLeft: -110, top: 60 }}>
        <Defs>
          <RadialGradient id="fpGlow" cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#FFECC4" stopOpacity={0.3} />
            <Stop offset="0.74" stopColor="#FFECC4" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={110} cy={100} rx={110} ry={100} fill="url(#fpGlow)" />
      </Svg>
      {/* The ground shadow is the one blur in the whole funnel that is NOT a
          soft-edged radial: a flat rgba(0,0,0,0.4) ellipse 180 x 18 under
          `filter: blur(10px)`. D010's substitution — the same box ramped to
          nothing — is wrong for it, because a σ=10 blur on an 18pt-tall solid
          drops the peak to about 0.25 and spreads it three times as far; drawn
          as a radial it read as a hard dark band. So the canvas's own blur is
          stated, per D063: react-native-svg carries `<FeGaussianBlur>` on both
          builds. The board is padded 60 each way (3σ = 30) and the filter
          region is given in user space, because the default region is 10% of
          an 18pt box and would clip the blur inside itself. */}
      <Svg width={300} height={138} style={{ position: 'absolute', left: '50%', marginLeft: -150, top: 98 }}>
        <Defs>
          <Filter id="fpShadow" filterUnits="userSpaceOnUse" x={0} y={0} width={300} height={138}>
            <FeGaussianBlur stdDeviation={10} />
          </Filter>
        </Defs>
        <Ellipse cx={150} cy={69} rx={90} ry={9} fill="#000000" fillOpacity={0.4} filter="url(#fpShadow)" />
      </Svg>
      <Svg width={230} height={180} viewBox="0 0 230 180" style={{ position: 'absolute', left: '50%', marginLeft: -115, top: 36 }}>
        <Defs>
          <LinearGradientSvg id="obW" x1="0" y1="0" x2="1" y2="0">
            <Stop offset="0" stopColor="#F7F6F2" />
            <Stop offset="1" stopColor="#C9C6BD" />
          </LinearGradientSvg>
        </Defs>
        <Path d="M14 96 C40 88 62 86 92 90" stroke="url(#obW)" strokeWidth={15} fill="none" strokeLinecap="round" />
        <Path d="M138 92 C168 96 194 104 216 114" stroke="url(#obW)" strokeWidth={15} fill="none" strokeLinecap="round" />
        <Path d="M92 88 C104 84 112 86 120 90" stroke="rgba(244,243,240,0.55)" strokeWidth={3.5} fill="none" strokeLinecap="round" />
        <Path d="M94 94 C106 94 116 92 134 92" stroke="rgba(244,243,240,0.4)" strokeWidth={3.5} fill="none" strokeLinecap="round" />
        <Path d="M96 100 C106 104 118 100 136 97" stroke="rgba(244,243,240,0.28)" strokeWidth={3.5} fill="none" strokeLinecap="round" />
        <Circle cx={115} cy={76} r={4} fill="#E9D2A4" />
      </Svg>
    </View>
  );
}

/**
 * A canvas SVG subtree, replayed element for element.
 *
 * Nine of the question boards now carry a bespoke header drawing and every
 * answer row on them a 30 x 30 mark, all of it transcribed into
 * `onboardingFunnel.ts` by the generator. Redrawing forty pictures by hand
 * would be forty chances to mistype a control point, so this maps the canvas's
 * own attribute names onto `react-native-svg`'s props instead.
 */
const SVG_TAG = {
  path: Path,
  rect: Rect,
  circle: Circle,
  ellipse: Ellipse,
  line: Line,
  polyline: Polyline,
  polygon: Polygon,
  g: G,
  text: SvgText,
  defs: Defs,
  lineargradient: LinearGradientSvg,
  radialgradient: RadialGradient,
  stop: Stop,
} as const;

/** `stroke-width` → `strokeWidth`; `d`, `id` and the rest pass through. */
function svgProps(attrs: Record<string, string>, swap?: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v0] of Object.entries(attrs)) {
    const v = swap?.[v0] ?? v0;
    out[k.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase())] = v;
  }
  return out;
}

function FunnelSvgKids({ kids, swap }: { kids: FunnelSvgKid[]; swap?: Record<string, string> }) {
  return (
    <>
      {kids.map((k, i) => {
        const Tag = SVG_TAG[k.tag as keyof typeof SVG_TAG];
        if (!Tag) return null;
        const P = Tag as ComponentType<Record<string, unknown>>;
        return (
          <P key={i} {...svgProps(k.attrs, swap)}>
            {k.text ?? (k.kids ? <FunnelSvgKids kids={k.kids} swap={swap} /> : null)}
          </P>
        );
      })}
    </>
  );
}

/**
 * The header drawing nine boards carry: a blurred bloom, then the drawing.
 *
 * The bloom is a `closest-side` radial under `filter: blur(8px)`; a radial that
 * already dies at its own edge needs no blur (D010), so the gradient carries it.
 */
function FunnelArtBlock({ art }: { art: FunnelArt }) {
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: Y(art.top), height: art.height }}>
      {art.bloom ? (
        <Svg
          width={art.bloom.w}
          height={art.bloom.h}
          style={{ position: 'absolute', left: '50%', marginLeft: -art.bloom.w / 2, top: art.height / 2 - art.bloom.h / 2 }}>
          <Defs>
            <RadialGradient id={`fa${art.top}`} cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor={art.bloom.color} stopOpacity={art.bloom.a0} />
              <Stop offset="0.72" stopColor={art.bloom.color} stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={art.bloom.w / 2} cy={art.bloom.h / 2} rx={art.bloom.w / 2} ry={art.bloom.h / 2} fill={`url(#fa${art.top})`} />
        </Svg>
      ) : null}
      {/* the canvas centres the drawing in the frame with a flex row; absolute
          because an `<Svg>` beside a positioned sibling is painted under it on
          web (see the SVG trap in the run brief) */}
      <Svg width={art.w} height={art.h} viewBox={art.viewBox} style={{ position: 'absolute', left: '50%', marginLeft: -art.w / 2, top: 0 }}>
        <FunnelSvgKids kids={art.kids} />
      </Svg>
    </View>
  );
}

/**
 * The mark at the head of an answer row (or, on `22 · What you’ve tried`, at
 * its tail). The frame draws one row already chosen, so the generator stores
 * every mark in the night ink and the paper pair is swapped back in here.
 */
const MARK_ON_PAPER: Record<string, string> = { '#F4F3F0': '#131313', 'rgba(244,243,240,0.18)': 'rgba(19,19,19,0.14)' };
function FunnelRowMark({ mark, on, style }: { mark: FunnelMark; on: boolean; style?: object }) {
  return (
    <Svg width={mark.size} height={mark.size} viewBox={mark.viewBox} style={style}>
      <FunnelSvgKids kids={mark.kids} swap={on ? MARK_ON_PAPER : undefined} />
    </Svg>
  );
}

/** A grid tile's 22 x 22 glyph, transcribed from the canvas child by child. */
function FunnelGlyphMark({ label, color }: { label: string; color: string }) {
  const g = FUNNEL_GLYPHS[label];
  if (!g) return null;
  return (
    <Svg width={22} height={22} viewBox={g.viewBox} fill="none">
      {g.kids.map((k, i) => {
        const a = k.attrs;
        const common = {
          // Only a child the canvas actually strokes takes a stroke. The moon
          // on `11 · When` is a bare filled path; inking its outline as well
          // put a 1pt default stroke round it and drew it a point fat.
          stroke: a['stroke-width'] ? color : undefined,
          strokeWidth: a['stroke-width'] ? Number(a['stroke-width']) : undefined,
          strokeLinecap: a['stroke-linecap'] as 'round' | undefined,
          strokeLinejoin: a['stroke-linejoin'] as 'round' | undefined,
          strokeDasharray: a['stroke-dasharray'],
        };
        // The canvas fills a shape or strokes it, never both: a child with no
        // stated stroke is a filled one and takes the tile's ink as its fill.
        const filled = a.fill !== 'none' && !a['stroke-width'];
        if (k.tag === 'circle') return <Circle key={i} cx={Number(a.cx)} cy={Number(a.cy)} r={Number(a.r)} fill={filled ? color : 'none'} {...common} />;
        if (k.tag === 'rect') return <Rect key={i} x={Number(a.x)} y={Number(a.y)} width={Number(a.width)} height={Number(a.height)} rx={a.rx ? Number(a.rx) : undefined} fill={filled ? color : 'none'} {...common} />;
        return <Path key={i} d={a.d} fill={filled ? color : 'none'} {...common} />;
      })}
    </Svg>
  );
}

/**
 * 90B · 90C · 90D — the campaign map, twelve weeks over three pages.
 *
 * Four weeks to a page with week I at the foot of the first, so the eye starts
 * where he is standing and climbs. Each row is a tile with its own small
 * drawing and its own halo, the light burning a little brighter every week up
 * the stack — and the ramp restarts on every page. That is the whole argument
 * for staying, made without a sentence.
 *
 * The rail on the right is a page indicator, not a scrollbar: its thumb is
 * exactly one third of the track and travels in thirds.
 */
/** The line at y 692 on each of the three pages, in page order. */
const CAMPAIGN_PAGE_LINES = [
  'In the first four weeks, you’ll reset, rethink the habit, and learn what to do in the moment.',
  'In weeks five to eight, you’ll build discipline and learn how to handle relapse and boredom.',
  'By week XII, the aim is simple: porn takes up less of your time, attention, and headspace.',
];

export function O3Reading({ next }: { answers?: Record<string, string | string[]>; next: () => void }) {
  const [page, setPage] = useState(1);
  return (
    <>
      <AppText center style={[sans('500'), { position: 'absolute', left: 26, right: 26, top: 72, fontSize: 22, lineHeight: 29.04, letterSpacing: 0.1, color: '#1D1C1A' }]}>
        The next twelve weeks.
      </AppText>
      {CAMPAIGN_WEEKS.map((w, i) => (w.page === page ? <CampaignWeekRow key={w.week} i={i} /> : null))}
      <CampaignMapRail page={page} />
      {/* The bundle draws exactly one control on these three frames and it is
          the pill: "Next" on the first two pages, "Continue" on the third. The
          rail at the right edge is a position indicator, not a control, so the
          invisible tap zones the previous bundle implied are gone. */}
      {/* all three pages now carry a closing line — the first two gained one in
          this drop, and each names the four weeks the page is showing */}
      <AppText center style={[sans('400'), { position: 'absolute', left: 26, right: 26, top: 638, fontSize: 14, lineHeight: 21, color: '#55534E' }]}>
        {CAMPAIGN_PAGE_LINES[page - 1]}
      </AppText>
      <O3PaperCTA
        label={page === 3 ? 'Continue' : 'Next'}
        onPress={page === 3 ? next : () => setPage((p) => Math.min(3, p + 1))}
        y={764}
        ls={0.3}
      />
    </>
  );
}

// ── letter ───────────────────────────────────────────────────────────
/** The week-XII letter, assembled from the user's own intake answers
 * (canvas: O3_Letter) — the fork where he and the other ending part ways. */
/**
 * `38 · A Letter From Week XII`.
 *
 * The previous bundle assembled this letter out of the answers; `UI Final 1`
 * writes it in full, so the prose is the design's and only the name is his.
 * The shape of the return is unchanged, because the Log keeps a copy.
 */
export function buildWeekXiiLetter(a: Record<string, string | string[]>): { name: string; paragraphs: string[] } {
  return { name: String(a.name || '').trim(), paragraphs: WEEK_XII_LETTER };
}

// ── Day I ────────────────────────────────────────────────────────────
/**
 * The window the reminders guard, in `11 · When`'s own labels.
 *
 * Returns the hour, the phrase the old primer used for it, and the name
 * `42 · Reminders` puts in its headline ("Late night is when you're most likely
 * to watch.").
 *
 * `11 · When` renamed all nine of its options in this drop — "Late nights" is
 * "Late at night", "After stress" is "When I’m stressed", and so on — so seven
 * of these tests had stopped matching anything and every answer but one fell
 * through to the default. The old labels are kept beside the new ones because
 * an account answered before the rename still carries them.
 */
export function windowFor(a: Record<string, string | string[]>): [string, string, string] {
  const t = (a.triggers as string[]) || [];
  const has = (...names: string[]) => names.some((n) => t.includes(n));
  if (has('Late at night', 'When I can’t sleep', 'Phone in bed', 'Can’t sleep', 'Late night')) return ['11:00 pm', 'before the tide rises', 'Late night'];
  if (has('When I’m stressed', 'After stress')) return ['6:00 pm', 'as the day lets go', 'After stress'];
  if (has('When I’m bored', 'Bored in the day', 'Bored daytime')) return ['9:00 pm', 'when the evening goes slack', 'Boredom in the day'];
  if (has('After drinking')) return ['10:00 pm', 'before the evening turns', 'After drinking'];
  if (has('When I’m home alone', 'Home alone')) return ['8:00 pm', 'while the house is empty', 'Being home alone'];
  if (has('On weekends', 'Weekends')) return ['9:30 pm', 'before the quiet hours', 'The weekend'];
  if (has('In the morning', 'Early morning')) return ['6:30 am', 'before the day starts', 'Early morning'];
  if (has('While scrolling')) return ['9:00 pm', 'when the scrolling starts', 'Scrolling'];
  return ['9:30 pm', 'before the quiet hours', 'Late night'];
}
