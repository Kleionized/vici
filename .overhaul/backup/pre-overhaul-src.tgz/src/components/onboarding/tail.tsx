/**
 * The onboarding tail — `24 · Build plan` (Enlisting Aegis), then
 * `28 · Your VICI Rating` … `34 · What You Want Back`.
 *
 * The numbers are the canvas's own badges, taken from `.vicifull/FLOW.txt`,
 * which the run's brief makes the authority on them. They are NOT the frame
 * ordinals the group lists were cut on — this drop renumbered onboarding, and
 * the two schemes collide (Change the Line is frame 36 and badge 32, Starting
 * Score is frame 32 and badge 28). Each section names both.
 *
 * None of these frames draws the eight-segment rule or the Back row the
 * bundle before last gave them. Each owns its whole frame, so each is rendered
 * whole rather than inside the funnel’s shell.
 *
 * `Latest Vici FULL` withdrew `Root Loop`, `What Comes Before It` and
 * `Results Pattern` — the three read-back boards that used to sit between the
 * plan and the rating — and the plan sub-flow (`25 · This Is Where We’d Start`
 * … `27 · Your Plan`) now stands where they did. It added `32B · A Clean Day`.
 *
 * Six of the eight share one field — a `#FAF9F8 → #FDFDFC` ground, a
 * `rgba(180,170,150,0.14)` bloom off the top-left corner, a 560pt warm sun
 * hung 300 below the bottom edge, and grain at 0.12. `31 · If Nothing Changes`
 * is a night sky, `32B · A Clean Day` is flat white with no field at all, and
 * `24 · Build plan` is the sunrise the funnel breaks on.
 *
 * Design y minus 54 throughout (`DECISIONS.md` D009). Numbers come from
 * `src/content/onboardingTail.ts`, generated from the frames.
 */
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, type ReactNode } from 'react';
import { Platform, View, type TextStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, ClipPath, Defs, Ellipse, FeGaussianBlur, Filter, G, Line, Path, RadialGradient, Rect, Stop, Text as SvgText } from 'react-native-svg';

import { AppText, Grain } from '@/components/ui';
import { PressScale } from '@/components/ui/press-scale';
import { AGE_80_STARS, COST_30, COST_365, SCORE_CURVE, SCORE_RING } from '@/content/onboardingTail';
import { fonts, sans } from '@/lib/theme';

const noiseDark = require('../../../assets/images/noise-dark.png');

/** Design y → the app's y under the safe-area inset. */
const Y = (top: number) => top - 54;

// ── the field ten of the eleven frames share ─────────────────────────
export function TailField({
  ground = ['#FAF9F8', '#FDFDFC'] as const,
  bloomAlpha = 0.14,
  sun = { size: 560, bottom: -300, a0: 0.42, a45: 0.19 },
  grain = 0.12,
}: {
  ground?: readonly [string, string];
  bloomAlpha?: number;
  sun?: { size: number; bottom: number; a0: number; a45: number } | null;
  grain?: number;
}) {
  return (
    <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
      <LinearGradient colors={[ground[0], ground[1]]} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      {/* the corner bloom — the canvas blurs it 6px, and a closest-side radial
          already dies at its own edge, so the gradient's falloff carries it.
          The canvas writes `rgba(19,19,19,0)` at the fade stop; that RGB is a
          null in CSS, which interpolates premultiplied, but SVG interpolates
          non-premultiplied and would ramp the wash toward black as the alpha
          falls. The zero-alpha stop therefore repeats the opaque stop's RGB
          (D105), which measured exact against the canvas where #131313 read up
          to 5/255 dark. */}
      <Svg width={540} height={270} style={{ position: 'absolute', left: -40, top: -140 }}>
        <Defs>
          <RadialGradient id="tailBloom" cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#B4AA96" stopOpacity={bloomAlpha} />
            <Stop offset="0.72" stopColor="#B4AA96" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={270} cy={135} rx={270} ry={135} fill="url(#tailBloom)" />
      </Svg>
      {sun ? (
        <Svg width={sun.size} height={sun.size} style={{ position: 'absolute', left: '50%', marginLeft: -sun.size / 2, bottom: sun.bottom }}>
          <Defs>
            <RadialGradient id="tailSun" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#FFECC4" stopOpacity={sun.a0} />
              <Stop offset="0.45" stopColor="#FFECC4" stopOpacity={sun.a45} />
              <Stop offset="0.72" stopColor="#FFECC4" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={sun.size / 2} cy={sun.size / 2} rx={sun.size / 2} ry={sun.size / 2} fill="url(#tailSun)" />
        </Svg>
      ) : null}
      <Grain source={noiseDark} opacity={grain} />
    </View>
  );
}

/** The frame under the safe-area inset that every tail screen positions inside. */
export function TailFrame({ children, field }: { children: ReactNode; field?: ReactNode }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#FAF9F8' }}>
      {field ?? <TailField />}
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        {/* Yoga places an absolute child from its parent's border box and never
            consults padding, and SafeAreaView spends the inset as padding — so
            the content has to sit in a plain view that already starts at it. */}
        <View style={{ flex: 1 }}>{children}</View>
      </SafeAreaView>
    </View>
  );
}

// ── shared pieces ────────────────────────────────────────────────────

/**
 * The ground shadow the two art boards cast: a flat `rgba(0,0,0,0.10)` ellipse
 * under `filter: blur(5px)`.
 *
 * D010 absorbs the blur on a `radial-gradient(closest-side, …)`, which has no
 * edge for it to soften. A **solid** fill is the case D082 carves out and the
 * one both of these are: the blur *is* the shape, so the fill holds its stated
 * alpha across the middle and carries on past the box, where a radial falling
 * to zero at the box edge is both too light in the middle and gone by its own
 * rim. `react-native-svg` 15.15 ships a real Gaussian on all three targets, so
 * it is drawn rather than fitted (D091) — `filter: blur(r)` states sigma
 * directly, unlike a box-shadow's radius, which is two.
 *
 * The `<Svg>` is padded 3 sigma on every side, where a Gaussian has spent
 * 99.7% of itself, and the filter region is stated in user space over that
 * whole padded box: the default `-10% … 120%` of the ellipse's own box is
 * nowhere near a 14pt-tall shadow's 5pt blur and would cut it off square. The
 * art box's own `overflow: hidden` still trims the result exactly where the
 * canvas trims it.
 */
function GroundShadow({ id, left, top, width, height, color, alpha, blur = 5 }: { id: string; left: number; top: number; width: number; height: number; color: string; alpha: number; blur?: number }) {
  const pad = Math.ceil(blur * 3);
  const w = width + pad * 2;
  const h = height + pad * 2;
  return (
    <Svg width={w} height={h} pointerEvents="none" style={{ position: 'absolute', left: left - pad, top: top - pad }}>
      <Defs>
        <Filter id={id} x={0} y={0} width={w} height={h} filterUnits="userSpaceOnUse">
          <FeGaussianBlur stdDeviation={blur} />
        </Filter>
      </Defs>
      <Ellipse cx={w / 2} cy={h / 2} rx={width / 2} ry={height / 2} fill={color} fillOpacity={alpha} filter={`url(#${id})`} />
    </Svg>
  );
}

/** The tail's pill: 58 tall at radius 29, or 56 at 28. */
export function TailCta({
  label,
  onPress,
  y,
  h = 58,
  tone = 'ink',
  tracking = 0.2,
}: {
  label: string;
  onPress: () => void;
  /** the pill's own top on the canvas */
  y: number;
  h?: 56 | 58;
  tone?: 'ink' | 'paper';
  tracking?: number;
}) {
  const ink = tone === 'ink';
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        top: Y(y),
        height: h,
        minHeight: 0,
        borderRadius: h / 2,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: ink ? '#131313' : '#FFFFFF',
      }}>
      <AppText style={[sans('600'), { fontSize: 17, letterSpacing: tracking, color: ink ? '#FFFFFF' : '#131313' }]}>{label}</AppText>
    </PressScale>
  );
}

/**
 * A centred run of copy at the canvas's own inset, top, size and leading.
 *
 * `wrap` is the frame's own `text-wrap`, and it has to be stated: `AppText`
 * gives every body run `text-wrap: pretty` on web, and the canvas marks only
 * some of these runs `pretty` and others `balance` or nothing at all. Where
 * the frame says nothing, `pretty` pulls a word down off the second line and
 * the copy breaks one word early — visible on `29 · The Next 30 Days`, both runs.
 * Web only, the same guard `AppText` uses; `text-wrap` has no native analogue.
 */
export function TailCopy({
  children,
  top,
  inset,
  size,
  lineHeight,
  weight = '400',
  color = '#55534E',
  tracking,
  wrap,
}: {
  children: ReactNode;
  top: number;
  inset: number;
  size: number;
  /** Omitted where the canvas states none — the platform's own line box then. */
  lineHeight?: number;
  weight?: '400' | '500' | '600';
  color?: string;
  tracking?: number;
  /** the frame's own `text-wrap`; omit where the frame says `pretty`. */
  wrap?: 'wrap' | 'balance';
}) {
  return (
    <AppText
      center
      style={[
        sans(weight),
        {
          position: 'absolute',
          left: inset,
          right: inset,
          top: Y(top),
          fontSize: size,
          color,
          ...(lineHeight != null ? { lineHeight } : null),
          ...(tracking != null ? { letterSpacing: tracking } : null),
        },
        wrap && Platform.OS === 'web' ? ({ textWrap: wrap } as unknown as TextStyle) : null,
      ]}>
      {children}
    </AppText>
  );
}

/**
 * A chart the canvas sizes with `width: 100%` and a viewBox.
 *
 * An SVG given a width and a viewBox takes its height from the ratio; give it a
 * fixed height instead and `preserveAspectRatio` centres the drawing inside a
 * viewport of the wrong shape, which shifts every label. The aspect ratio is
 * carried on the wrapper so the box grows with the card.
 */
function TailChart({ vb, children }: { vb: [number, number]; children: ReactNode }) {
  return (
    <View style={{ width: '100%', aspectRatio: vb[0] / vb[1] }}>
      <Svg width="100%" height="100%" viewBox={`0 0 ${vb[0]} ${vb[1]}`}>
        {children}
      </Svg>
    </View>
  );
}

/**
 * The floating card `30 · One Year From Now` and `31 · If Nothing Changes`
 * hang 120 off the bottom edge.
 *
 * It was a one-line pill last drop and is now a 300-wide three-line card: a
 * 15/500 lead, a 28/600 figure 6 under it and a 13/18 foot 8 under that,
 * inside `padding: 18px 24px` — 119 tall, so its own top lands on 613.
 *
 * The canvas gives it `backdrop-filter: blur(12px)` under a 94%-opaque fill.
 * React Native has no backdrop filter, so the blur is an `expo-blur` layer
 * inside the card with the stated colour painted over it — see DECISIONS.md
 * D018 for the intensity mapping.
 */
function TailPill({ tint, fill, ring, shadow, lead, leadColor, figure, figureColor, foot, footColor }: { tint: 'light' | 'dark'; fill: string; ring: string; shadow: string; lead: string; leadColor: string; figure: string; figureColor: string; foot: string; footColor: string }) {
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, bottom: 120, alignItems: 'center' }}>
      <View style={{ width: 300, borderRadius: 16, overflow: 'hidden', boxShadow: `0 0 0 1px ${ring}, ${shadow}` }}>
        <BlurView intensity={24} tint={tint} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <View style={{ backgroundColor: fill, paddingTop: 18, paddingBottom: 18, paddingHorizontal: 24 }}>
          <AppText center style={[sans('500'), { fontSize: 15, color: leadColor }]}>{lead}</AppText>
          <AppText center style={[sans('600'), { marginTop: 6, fontSize: 28, letterSpacing: -0.5, color: figureColor }]}>{figure}</AppText>
          {/* the only one of the three the canvas gives a line height of its own */}
          <AppText center style={[sans('400'), { marginTop: 8, fontSize: 13, lineHeight: 18, color: footColor }]}>{foot}</AppText>
        </View>
      </View>
    </View>
  );
}

/**
 * A white paper card with the tail's hairline. `29 · The Next 30 Days` is the
 * one that lays no grain over itself; `33 · One Bad Day` still does.
 */
function TailCard({ top, padding, children, height, grain = true }: { top: number; padding: string; children: ReactNode; height?: number; grain?: boolean }) {
  const [pt, px, pb] = padding.split(' ').map(Number);
  return (
    <View
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        top: Y(top),
        ...(height != null ? { height } : null),
        borderRadius: 20,
        backgroundColor: '#FFFFFF',
        boxShadow: '0 0 0 1px rgba(0,0,0,0.09)',
        paddingTop: pt,
        paddingHorizontal: px,
        paddingBottom: pb ?? px,
        overflow: 'hidden',
      }}>
      {grain ? <Grain source={noiseDark} opacity={0.05} /> : null}
      {children}
    </View>
  );
}

// ── 23 · Putting Your Plan Together ──────────────────────────────────
/**
 * The sunrise the funnel breaks on: a five-stop ground from `#131313` to white,
 * a progress rule 311 wide with 186 filled, three checklist rows, and a 399pt
 * white disc rising off the bottom edge.
 */
// `24 · Build plan` rewrote all three lines in this drop. The questionnaire
// doc writes them differently again ("Finding where you usually get caught",
// "Looking at what tends to lead into it", "Choosing what to change first");
// the frame is what is visible, so the frame wins.
const AEGIS_ROWS = ['Finding where you usually struggle', 'Looking at what tends to set it off', 'Choosing where to start'];
/** How long the board holds before it hands over. The app's own timing. */
const AEGIS_MS = 6800;

export function O3PuttingTogether({ next }: { next: () => void }) {
  // The canvas draws no control here — the board hands over on its own.
  useEffect(() => {
    const id = setTimeout(next, AEGIS_MS);
    return () => clearTimeout(id);
  }, [next]);
  return (
    <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
        <LinearGradient
          colors={['#131313', '#2A2924', '#6E7069', '#C9C8C4', '#FFFFFF']}
          locations={[0, 0.26, 0.52, 0.74, 1]}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
        />
        <Grain source={noiseDark} opacity={0.12} />
      </View>
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <AppText center style={[sans('400'), { position: 'absolute', left: 0, right: 0, top: Y(150), fontSize: 15, color: 'rgba(244,243,240,0.8)' }]}>
            Putting your plan together…
          </AppText>
          <View style={{ position: 'absolute', left: 41, top: Y(177), width: 311, height: 3, borderRadius: 2, backgroundColor: 'rgba(244,243,240,0.25)' }}>
            <View style={{ width: 186, height: 3, borderRadius: 2, backgroundColor: '#F4F3F0' }} />
          </View>
          <View style={{ position: 'absolute', left: 0, right: 0, top: Y(262), alignItems: 'center', gap: 16 }}>
            {AEGIS_ROWS.map((label, i) => {
              const done = i < 2;
              return (
                <View key={label} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  {done ? (
                    <Svg width={15} height={15} viewBox="0 0 15 15" fill="none">
                      <Path d="M2.5 8l3.2 3.2L12.5 4" stroke="#F4F3F0" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
                    </Svg>
                  ) : (
                    /* the third row's mark is a 13pt ring with its top edge cut
                       away — a spinner frozen at one frame on the canvas */
                    <View
                      style={{
                        width: 13,
                        height: 13,
                        borderRadius: 6.5,
                        borderWidth: 2,
                        borderColor: 'rgba(244,243,240,0.55)',
                        borderTopColor: 'transparent',
                      }}
                    />
                  )}
                  <AppText style={[sans('500'), { fontSize: 15.5, color: done ? '#F4F3F0' : 'rgba(244,243,240,0.75)' }]}>{label}</AppText>
                </View>
              );
            })}
          </View>
          {/* the frame carries a 20px/500 line at y 434 with no words in it */}
          <View
            pointerEvents="none"
            style={{ position: 'absolute', left: -3, top: Y(563), width: 399, height: 399, borderRadius: 199.5, backgroundColor: '#FFFFFF', overflow: 'hidden', boxShadow: '0 -20px 70px rgba(255,255,255,0.6)' }}>
            <Grain source={noiseDark} opacity={0.08} />
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ── 28 · Your VICI Rating (frame `Starting Score`) ───────────────────
const SCORE_MAX = 3000;
const CURVE_W = 345;
const CURVE_H = 88;

/**
 * The ring gauge and the ELO curve.
 *
 * The board is renamed in this drop — `YOUR VICI RATING`, and the denominator
 * under the number is gone: the sub-label now reads `Starting point`. The ring
 * keeps its old `stroke-dasharray: 89.7 653.5`, which is 13.73% of a 104pt
 * circle and was exactly the 412 of 3,000 the frame used to print. The frame
 * now prints 842 against that same arc, so the two halves of the drawing no
 * longer agree — the readout was restyled and the arc was not (DECISIONS D050).
 *
 * The app keeps the arithmetic the arc states — the arc is `rating / 3000` —
 * and shows its own opening rating, because the app owns what a number means
 * (D017) and 842 is below `SCORE_BASE` just as 412 was.
 */
export function O3StartingPoint({ score, next }: { score: number; next: () => void }) {
  const frac = Math.max(0, Math.min(1, score / SCORE_MAX));
  const dash = SCORE_RING.circumference * frac;
  const angle = -Math.PI / 2 + frac * Math.PI * 2;
  const mx = 120 + SCORE_RING.trackR * Math.cos(angle);
  const my = 120 + SCORE_RING.trackR * Math.sin(angle);
  const markerX = CURVE_W * frac;
  // the bell the canvas samples: y = 80 − 68·exp(−((x−172.5)/63.8)²)
  const curveY = (x: number) => 80 - 68 * Math.exp(-(((x - 172.5) / 63.8) ** 2));
  const line = SCORE_CURVE.map(([x, y], i) => `${i ? 'L ' : ''}${x},${y}`).join(' ');
  const area = `M0,${CURVE_H} L${line} L${CURVE_W},${CURVE_H} Z`;
  return (
    <TailFrame>
      <AppText center style={[sans('600'), { position: 'absolute', left: 0, right: 0, top: Y(150), fontSize: 12.5, letterSpacing: 1.2, color: '#8B8882' }]}>
        YOUR VICI RATING
      </AppText>
      <View style={{ position: 'absolute', left: '50%', marginLeft: -120, top: Y(192), width: 240, height: 240 }}>
        <Svg width={240} height={240} viewBox="0 0 240 240" style={{ position: 'absolute', left: 0, top: 0 }}>
          {SCORE_RING.ticks.map(([x1, y1, x2, y2], i) => (
            <Line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#DDDAD2" strokeWidth={1.4} />
          ))}
          <Circle cx={120} cy={120} r={SCORE_RING.trackR} fill="none" stroke="#ECEAE4" strokeWidth={SCORE_RING.strokeW} />
          <Circle
            cx={120}
            cy={120}
            r={SCORE_RING.trackR}
            fill="none"
            stroke="#131313"
            strokeWidth={SCORE_RING.strokeW}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${SCORE_RING.circumference}`}
            transform="rotate(-90 120 120)"
          />
          <Circle cx={mx} cy={my} r={7.5} fill="#D9A441" />
          <Circle cx={mx} cy={my} r={7.5} fill="none" stroke="#FFFFFF" strokeWidth={2.5} />
        </Svg>
        <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, alignItems: 'center', justifyContent: 'center', gap: 4 }}>
          <AppText style={[sans('500'), { fontSize: 60, letterSpacing: 1.5, lineHeight: 60, color: '#1D1C1A', fontVariant: ['tabular-nums'] as const }]}>{score.toLocaleString('en-US')}</AppText>
          <AppText style={[sans('600'), { fontSize: 12.5, color: '#8B8882' }]}>Starting point</AppText>
        </View>
      </View>
      <View style={{ position: 'absolute', left: 24, right: 24, top: Y(474), height: CURVE_H }}>
        {/* the canvas states `preserveAspectRatio="none"`: this svg is given both
            a width and a height, so on any screen wider than the canvas's 393
            the default `xMidYMid meet` would letterbox the curve at 345 and
            centre it instead of stretching it across the inset */}
        <Svg width="100%" height={CURVE_H} viewBox={`0 0 ${CURVE_W} ${CURVE_H}`} preserveAspectRatio="none">
          <Defs>
            <ClipPath id="vici-elo-clip">
              <Rect x={0} y={0} width={markerX} height={CURVE_H} />
            </ClipPath>
          </Defs>
          <Path d={area} fill="#F1F0EB" />
          <G clipPath="url(#vici-elo-clip)">
            <Path d={area} fill="rgba(217,164,65,0.32)" />
          </G>
          <Path d={`M${line}`} fill="none" stroke="#D8D5CE" strokeWidth={1.5} />
          <Line x1={markerX} y1={curveY(markerX)} x2={markerX} y2={CURVE_H} stroke="#131313" strokeWidth={1.8} />
          <Circle cx={markerX} cy={curveY(markerX)} r={5} fill="#D9A441" stroke="#FFFFFF" strokeWidth={2} />
        </Svg>
      </View>
      <TailCopy top={584} inset={44} size={14.5} lineHeight={21} wrap="wrap">
        This is where you start. What you do from here matters more than the questionnaire.
      </TailCopy>
      <TailCta label="Next" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── 29 · The Next 30 Days (frame `Cost Next 30`) ─────────────────────
export function O3Next30({ times, next }: { times: number; next: () => void }) {
  return (
    <TailFrame>
      <TailCopy top={150} inset={32} size={26} weight="500" color="#1D1C1A" tracking={-0.2} wrap="wrap">
        This is your next 30 days.
      </TailCopy>
      <TailCopy top={198} inset={44} size={14.5} lineHeight={21} wrap="wrap">
        {`If the rate you reported stayed the same, about ${times} of the next 30 days could end with porn.`}
      </TailCopy>
      <TailCard top={284} padding="16 16 16" grain={false}>
        {/* `grid-template-columns: repeat(6,1fr); gap:8` with square cells */}
        <View style={{ gap: 8 }}>
          {Array.from({ length: Math.ceil(COST_30.length / 6) }, (_, r) => (
            <View key={r} style={{ flexDirection: 'row', gap: 8 }}>
              {COST_30.slice(r * 6, r * 6 + 6).map((on, i) => (
                <View
                  key={i}
                  style={{
                    flex: 1,
                    aspectRatio: 1,
                    borderRadius: 10,
                    backgroundColor: on ? '#131313' : '#F7F6F3',
                    boxShadow: on ? undefined : 'inset 0 0 0 1px rgba(0,0,0,0.06)',
                  }}
                />
              ))}
            </View>
          ))}
        </View>
      </TailCard>
      {/* the key the redraw added: two 14pt swatches on a 16pt line, 22 apart */}
      <View style={{ position: 'absolute', left: 0, right: 0, top: Y(606), flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 22 }}>
        <CostKey fill="#131313">Relapse</CostKey>
        <CostKey fill="#F7F6F3" ring="inset 0 0 0 1px rgba(0,0,0,0.10)">
          Clean day
        </CostKey>
      </View>
      <TailCopy top={660} inset={44} size={15.5} lineHeight={22} weight="500" color="#1D1C1A" wrap="wrap">
        The line can start changing with the next one.
      </TailCopy>
      <TailCta label="Next" onPress={next} y={744} />
    </TailFrame>
  );
}

/** One entry of the month key: a 14pt swatch and a 13pt label, 8 apart. */
function CostKey({ fill, ring, children }: { fill: string; ring?: string; children: ReactNode }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
      <View style={{ width: 14, height: 14, borderRadius: 4, backgroundColor: fill, boxShadow: ring }} />
      <AppText style={[sans('500'), { fontSize: 13, color: '#55534E' }]}>{children}</AppText>
    </View>
  );
}

// ── 30 · One Year From Now (frame `Cost Next 365`) ───────────────────
/**
 * 365 square cells, 17 across, edge to edge.
 *
 * The canvas grid is `repeat(17,1fr)` with `gap:4` inside `padding:0 4px` on
 * the full 393, so a cell is (393 − 8 − 16×4) / 17 = 18.88 square. 365 fills
 * twenty-one whole rows and eight of the twenty-second; the frame pads the
 * rest with `visibility:hidden` cells, which carry no aspect ratio and so add
 * a zero-height twenty-third row — reproduced here so the grid's own box
 * measures the canvas's 503.8 rather than 499.8.
 */
const YEAR_COLS = 17;

export function O3OneYear({ days, next }: { days: number; next: () => void }) {
  const rows = Math.ceil(COST_365.length / YEAR_COLS);
  return (
    <TailFrame>
      <View style={{ position: 'absolute', left: 0, right: 0, top: Y(60), paddingHorizontal: 4, gap: 4 }}>
        {Array.from({ length: rows }, (_, r) => {
          const cells = COST_365.slice(r * YEAR_COLS, r * YEAR_COLS + YEAR_COLS);
          return (
            <View key={r} style={{ flexDirection: 'row', gap: 4 }}>
              {cells.map((on, i) => (
                <View
                  key={i}
                  style={{
                    flex: 1,
                    aspectRatio: 1,
                    borderRadius: 4,
                    backgroundColor: on ? '#131313' : '#FFFFFF',
                    boxShadow: on ? undefined : 'inset 0 0 0 1px rgba(0,0,0,0.06)',
                  }}
                />
              ))}
              {Array.from({ length: YEAR_COLS - cells.length }, (_, k) => (
                <View key={'g' + k} style={{ flex: 1 }} />
              ))}
            </View>
          );
        })}
        <View />
      </View>
      <TailPill
        tint="light"
        fill="rgba(255,255,255,0.94)"
        ring="rgba(0,0,0,0.08)"
        shadow="0 18px 44px rgba(40,38,32,0.26)"
        lead="One year from now."
        leadColor="#55534E"
        figure={`About ${days} days`}
        figureColor="#1D1C1A"
        foot="Where you’re predicted to relapse."
        footColor="#55534E"
      />
      <TailCta label="Next" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── 31 · If Nothing Changes (frame `Cost By Age 80`) ─────────────────
export function O3IfNothingChanges({ days, next }: { days: number; next: () => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#060606' }}>
      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
        <Svg width="100%" height="100%" style={{ position: 'absolute', top: 0, left: 0 }}>
          {AGE_80_STARS.map(([x, y], i) => (
            <Circle key={i} cx={x} cy={y} r={1.3} fill="#FFFFFF" />
          ))}
        </Svg>
      </View>
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <TailPill
            tint="dark"
            fill="rgba(19,19,19,0.82)"
            ring="rgba(255,255,255,0.16)"
            shadow="0 18px 44px rgba(0,0,0,0.5)"
            lead="By age 80"
            leadColor="rgba(255,255,255,0.7)"
            figure={`About ${days.toLocaleString('en-US')} days`}
            figureColor="#FFFFFF"
            foot="If nothing changes."
            footColor="rgba(255,255,255,0.6)"
          />
          <TailCta label="Next" onPress={next} y={744} tone="paper" />
        </View>
      </SafeAreaView>
    </View>
  );
}

// ── 32 · Change the Line ─────────────────────────────────────────────
export function O3ChangeTheLine({ next }: { next: () => void }) {
  return (
    <TailFrame>
      <TailCopy top={148} inset={32} size={26} weight="500" color="#1D1C1A" tracking={-0.2} wrap="wrap">
        You don’t have to fix the next year tonight.
      </TailCopy>
      {/* the veil that takes the year grid down to black. It sits under the
          title, which states no z-index, and over the paragraph and the pill,
          which both state 6 */}
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(6,6,6,0)', 'rgba(6,6,6,0.45)', 'rgba(6,6,6,0.85)', '#060606']}
        locations={[0.38, 0.5, 0.58, 0.66]}
        style={{ position: 'absolute', left: 0, right: 0, top: -54, bottom: 0 }}
      />
      <TailCopy top={237} inset={44} size={14.5} lineHeight={22}>
        You only have to make the next decision different. Then the next one. Then come back tomorrow.
      </TailCopy>
      <TailCta label="Start with today" onPress={next} y={744} tone="paper" />
    </TailFrame>
  );
}

// ── 32B · A Clean Day ────────────────────────────────────────────────
/**
 * The one tail board with no field at all: flat `#FFFFFF`, no bloom, no sun,
 * no grain — a seedling in a pot at 76,300, and two lines above it.
 */
export function O3CleanDay({ next }: { next: () => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <View pointerEvents="none" style={{ position: 'absolute', left: 76, top: Y(300), width: 240, height: 200 }}>
            <View style={{ position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
              <Svg width={128} height={128} style={{ position: 'absolute', left: 56, top: 0 }}>
                <Defs>
                  <RadialGradient id="cdGlow" cx="50%" cy="50%" rx="50%" ry="50%">
                    <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.42} />
                    <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
                  </RadialGradient>
                </Defs>
                <Circle cx={64} cy={64} r={64} fill="url(#cdGlow)" />
              </Svg>
              <GroundShadow id="cdShadow" left={90} top={152} width={60} height={16} color="rgb(0,0,0)" alpha={0.1} />
              <LinearGradient
                colors={['#EDECE7', '#E0DFDA']}
                style={{ position: 'absolute', left: 86, top: 112, width: 68, height: 46, borderTopLeftRadius: 8, borderTopRightRadius: 8, borderBottomLeftRadius: 14, borderBottomRightRadius: 14 }}
              />
              <View style={{ position: 'absolute', left: 82, top: 106, width: 76, height: 12, borderRadius: 6, backgroundColor: '#F1EFE9' }} />
              <View style={{ position: 'absolute', left: 118, top: 52, width: 4, height: 60, borderRadius: 2, backgroundColor: '#8E8B84' }} />
              {/* the two leaves are `border-radius: 100% 0 100% 0` boxes swung off
                  one end — a percentage radius is elliptical, which is the shape,
                  so it is written as the canvas writes it rather than as a path */}
              <View
                style={{
                  position: 'absolute',
                  left: 120,
                  top: 66,
                  width: 36,
                  height: 20,
                  borderTopLeftRadius: '100%',
                  borderBottomRightRadius: '100%',
                  backgroundColor: '#B9B5AC',
                  transform: [{ rotate: '-14deg' }],
                  transformOrigin: '0% 50%',
                }}
              />
              <View
                style={{
                  position: 'absolute',
                  left: 84,
                  top: 78,
                  width: 36,
                  height: 20,
                  borderTopRightRadius: '100%',
                  borderBottomLeftRadius: '100%',
                  backgroundColor: '#C6C2B8',
                  transform: [{ rotate: '14deg' }],
                  transformOrigin: '100% 50%',
                }}
              />
              <View
                style={{
                  position: 'absolute',
                  left: 112,
                  top: 40,
                  width: 16,
                  height: 26,
                  borderTopLeftRadius: '100% 120%',
                  borderTopRightRadius: '100% 120%',
                  borderBottomLeftRadius: '100% 80%',
                  borderBottomRightRadius: '100% 80%',
                  backgroundColor: '#A9A59B',
                }}
              />
              <View style={{ position: 'absolute', left: 152, top: 44, width: 6, height: 6, borderRadius: 3, backgroundColor: '#E2BA78', opacity: 0.9 }} />
              <View style={{ position: 'absolute', left: 74, top: 92, width: 4, height: 4, borderRadius: 2, backgroundColor: '#E2BA78', opacity: 0.7 }} />
            </View>
          </View>
          <TailCopy top={150} inset={36} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
            One clean day.
          </TailCopy>
          <TailCopy top={194} inset={44} size={15.5} lineHeight={23}>
            That’s all today has to be.
          </TailCopy>
          <TailCta label="Continue" onPress={next} y={744} />
        </View>
      </SafeAreaView>
    </View>
  );
}

// ── 33 · One Bad Day ─────────────────────────────────────────────────
export function O3OneBadDay({ day, next }: { day: number; next: () => void }) {
  return (
    <TailFrame>
      <TailCopy top={170} inset={40} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
        One bad day is one bad day.
      </TailCopy>
      <TailCopy top={230} inset={48} size={14} lineHeight={21}>
        It doesn’t erase the work before it. Your lessons, logs, rating history and medallions stay.
      </TailCopy>
      <TailCard top={316} padding="20 16 16">
        <TailChart vb={[320, 190]}>
          <Line x1={16} y1={152} x2={304} y2={152} stroke="rgba(19,19,19,0.16)" strokeWidth={1.5} />
          <Circle cx={24} cy={148} r={4.5} fill="#131313" />
          <Path d="M24,148 C100,136 180,92 288,34" fill="none" stroke="#131313" strokeWidth={3} strokeLinecap="round" />
          <Path d="M288,34 l-10.5,-1 M288,34 l-4,9.5" stroke="#131313" strokeWidth={3} strokeLinecap="round" />
          <Path d="M118,116 l8 8 M212,74 l8 8" stroke="#E2BA78" strokeWidth={3.6} strokeLinecap="round" />
          <SvgText x={122} y={140} fontFamily={fonts.sans} fontSize={11} fontWeight="500" fill="#C99F5F">slip</SvgText>
          <SvgText x={216} y={98} fontFamily={fonts.sans} fontSize={11} fontWeight="500" fill="#C99F5F">slip</SvgText>
          <SvgText x={24} y={170} fontFamily={fonts.sans} fontSize={10.5} fontWeight="500" fill="#8B8882">day 0</SvgText>
          <SvgText x={304} y={170} fontFamily={fonts.sans} fontSize={10.5} fontWeight="500" fill="#8B8882" textAnchor="end">{`today · day ${day}`}</SvgText>
        </TailChart>
      </TailCard>
      <TailCopy top={572} inset={44} size={15.5} lineHeight={22} weight="500" color="#1D1C1A" wrap="wrap">
        What matters is that you come back.
      </TailCopy>
      <TailCta label="Continue" onPress={next} y={744} />
    </TailFrame>
  );
}

// ── 34 · What You Want Back ──────────────────────────────────────────
/**
 * The bar chart is gone. In its place: a sunrise over two hills, and three
 * named things under it — `FOCUS`, `SLEEP`, `CONFIDENCE`.
 *
 * The canvas names those three and draws a bespoke glyph for each. `19 · What
 * it affects` offers nine answers and the bundle draws an icon for none of the
 * other six, so the trio is the board's own copy rather than a readout of what
 * he picked, and it is drawn as stated (DECISIONS D051).
 */
const WANT_BACK: { label: string; icon: ReactNode }[] = [
  {
    label: 'FOCUS',
    icon: (
      <Svg width={22} height={22} viewBox="0 0 24 24">
        <Path d="M7 15a5 5 0 0 1 10 0" fill="none" stroke="#131313" strokeWidth={2.5} />
        <Path d="M3 18h18M12 4v3M5 7l2 2M19 7l-2 2" stroke="#131313" strokeWidth={2.5} strokeLinecap="round" />
      </Svg>
    ),
  },
  {
    label: 'SLEEP',
    icon: (
      <Svg width={22} height={22} viewBox="0 0 30 30">
        <Path d="M17 4 A10.5 10.5 0 1 0 25 20 A8.2 8.2 0 1 1 17 4 Z" fill="#131313" />
      </Svg>
    ),
  },
  {
    label: 'CONFIDENCE',
    icon: (
      <Svg width={22} height={22} viewBox="0 0 24 24">
        <Path d="M3 16l5-6 4 4 6-8" fill="none" stroke="#131313" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    ),
  },
];

export function O3WhatYouWantBack({ next }: { next: () => void }) {
  return (
    <TailFrame>
      <TailCopy top={130} inset={36} size={24} lineHeight={32} weight="500" color="#1D1C1A" tracking={-0.2} wrap="balance">
        This is what you’re doing it for.
      </TailCopy>
      <View pointerEvents="none" style={{ position: 'absolute', left: 76, top: Y(176), width: 240, height: 200 }}>
        <View style={{ position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
          <Svg width={140} height={140} style={{ position: 'absolute', left: 50, top: 20 }}>
            <Defs>
              <RadialGradient id="wybGlow" cx="50%" cy="50%" rx="50%" ry="50%">
                <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.5} />
                <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
              </RadialGradient>
            </Defs>
            <Circle cx={70} cy={70} r={70} fill="url(#wybGlow)" />
          </Svg>
          {/* the sun's own fill is `radial-gradient(circle at 50% 38%, …)`, whose
              implicit farthest-corner radius on an 88pt square is 70.1 — 79.65% */}
          <View style={{ position: 'absolute', left: 76, top: 54, width: 88, height: 88, borderRadius: 44, boxShadow: '0 6px 18px rgba(226,186,120,0.45)' }}>
            <Svg width={88} height={88} style={{ position: 'absolute', left: 0, top: 0 }}>
              <Defs>
                <RadialGradient id="wybSun" cx="50%" cy="38%" r="79.65%">
                  <Stop offset="0" stopColor="#F8E9CB" />
                  <Stop offset="0.7" stopColor="#EFD3A2" />
                  <Stop offset="1" stopColor="#E3BE85" />
                </RadialGradient>
              </Defs>
              <Circle cx={44} cy={44} r={44} fill="url(#wybSun)" />
            </Svg>
          </View>
          <View style={{ position: 'absolute', left: 28, top: 74, width: 40, height: 14, borderRadius: 7, backgroundColor: '#F7F6F2' }} />
          <View style={{ position: 'absolute', left: 168, top: 60, width: 48, height: 14, borderRadius: 7, backgroundColor: '#F7F6F2' }} />
          <View style={{ position: 'absolute', left: 6, top: 110, width: 228, height: 34, borderRadius: 17, backgroundColor: '#E4E3DE' }} />
          <View style={{ position: 'absolute', left: 20, top: 126, width: 200, height: 26, borderRadius: 13, backgroundColor: '#EDECE7' }} />
          <GroundShadow id="wybShadow" left={16} top={152} width={208} height={14} color="rgb(0,0,0)" alpha={0.1} />
        </View>
      </View>
      <View style={{ position: 'absolute', left: 24, right: 24, top: Y(398), flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 6 }}>
        {WANT_BACK.map((it) => (
          <View key={it.label} style={{ alignItems: 'center', gap: 9, width: 100 }}>
            <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: '#FFFFFF', boxShadow: '0 0 0 1px rgba(0,0,0,0.09), 0 8px 18px rgba(40,38,32,0.10)', alignItems: 'center', justifyContent: 'center' }}>
              {it.icon}
            </View>
            <AppText center style={[sans('600'), { fontSize: 13.5, letterSpacing: 1.2, color: '#1D1C1A' }]}>
              {it.label}
            </AppText>
          </View>
        ))}
      </View>
      <TailCopy top={540} inset={40} size={17} lineHeight={26} weight="500" color="#1D1C1A" wrap="wrap">
        Not a perfect streak for its own sake.
      </TailCopy>
      <TailCopy top={574} inset={44} size={14.5} lineHeight={21}>
        More of your time and attention going where you actually want them.
      </TailCopy>
      <TailCta label="See the twelve weeks" onPress={next} y={744} />
    </TailFrame>
  );
}
