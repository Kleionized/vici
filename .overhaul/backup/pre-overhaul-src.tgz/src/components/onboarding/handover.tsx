/**
 * The handover — `34 · Twelve Weeks` … `43 · Day 0`.
 *
 * Where the funnel stops asking and starts giving things: the map of the twelve
 * weeks, the letter from the man at week XII, the vow, the first medallion, the
 * reminders, and day zero.
 *
 * Like the tail, none of these frames draws the funnel's rule, and only the map
 * keeps a Back row, so each is rendered whole. Design y minus 54 throughout
 * (`DECISIONS.md` D009).
 */
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { Fragment, useId, type ReactNode } from 'react';
import { Platform, ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, Ellipse, FeGaussianBlur, Filter, Path, RadialGradient, Stop } from 'react-native-svg';

import { AppText, Grain, Hill } from '@/components/ui';
import { PressScale } from '@/components/ui/press-scale';
import { cssLineHeight, fonts, sans } from '@/lib/theme';

const noiseDark = require('../../../assets/images/noise-dark.png');
const laurelMark = require('../../../assets/images/laurel-mark.webp');

const Y = (top: number) => top - 54;

/* `AppText` gives every body run `text-wrap: pretty` on web, and most of the
   canvas states it too. Where a frame states something else — or states nothing,
   whose initial value is `wrap` — the run has to say so, or the line breaks in a
   different place from the frame's. Web-only either way: RN ignores it. (D052) */
const WRAP = Platform.OS === 'web' ? ({ textWrap: 'wrap' } as object) : null;
const BALANCE = Platform.OS === 'web' ? ({ textWrap: 'balance' } as object) : null;

/* The two struck discs. Their inset segments are held apart from the drop
   shadows because each has to be painted twice: once on the View, and again on
   an overlay above the <Svg> face, which CSS otherwise paints over the parent's
   own inset shadow. `letter.tsx` does this with `insetOf(shadow)`; it is written
   out here rather than imported, because that module already imports
   `O3LetterRead` from this one. */
const SEAL_RIM = 'inset 0 0 0 3px rgba(255,255,255,0.25)';
const SEAL_SHADOW = `${SEAL_RIM}, 0 5px 12px rgba(180,140,70,0.45)`;
const DISC_RIM = 'inset 0 0 0 4px rgba(255,255,255,0.25), inset 0 -8px 18px rgba(120,88,40,0.28)';
const DISC_SHADOW = `${DISC_RIM}, 0 14px 30px rgba(180,140,70,0.45)`;

/**
 * A blurred SOLID — `background: <flat colour>` under `filter: blur(r)` — which
 * is the case D082 carves out of D010. A blurred *gradient* has no edge for the
 * blur to soften and a radial falloff stands in for it exactly; a solid is the
 * opposite. The blur IS the shape: the fill holds most of its stated alpha flat
 * across the middle, never quite reaches it on a shape thinner than its own
 * blur, and carries on well past the box. A box-sized radial gets all three
 * wrong. `react-native-svg` 15.15.4 ships a real Gaussian on web and native
 * alike (D063), so these are drawn as the canvas states them rather than fitted.
 *
 * The `<Svg>` overhangs the canvas's box by 4σ because an `<Svg>` clips to its
 * viewport, and `filter: blur(r)` states σ directly — a box-shadow's radius is
 * two of them, and the two are not the same Gaussian.
 */
function BlurredSolid({ left, top, width, height, fill, blur }: { left: number; top: number; width: number; height: number; fill: string; blur: number }) {
  // a hard-coded filter id binds to whichever copy of the art mounted first, so
  // the same board pushed over itself loses its shadow (FINDINGS F20)
  const id = `blur${useId().replace(/:/g, '')}`;
  const pad = blur * 4;
  return (
    <Svg width={width + pad * 2} height={height + pad * 2} style={{ position: 'absolute', left: left - pad, top: top - pad }}>
      <Defs>
        {/* the default filter region is 10% of the bounding box and would clip
            the falloff inside itself (D063) */}
        <Filter id={id} x="-100%" y="-100%" width="300%" height="300%">
          <FeGaussianBlur stdDeviation={String(blur)} />
        </Filter>
      </Defs>
      <Ellipse cx={pad + width / 2} cy={pad + height / 2} rx={width / 2} ry={height / 2} fill={fill} filter={`url(#${id})`} />
    </Svg>
  );
}

/**
 * The field `37 · A Letter Arrived` and `43 · Day 0` share with
 * `25 · What Comes Before It`: flat paper, light grain, a wide top wash and a
 * 520pt sun hung 260 below the bottom edge.
 */
export function PaperArrivalField({ sun = true, grain = 0.07 }: { sun?: boolean; grain?: number }) {
  return (
    <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
      <Grain source={noiseDark} opacity={grain} />
      <Svg width="100%" height="100%" style={{ position: 'absolute', top: 0, left: 0 }}>
        <Defs>
          <RadialGradient id="arrTop" cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#B4AA96" stopOpacity={0.32} />
            <Stop offset="0.55" stopColor="#B4AA96" stopOpacity={0.1} />
            <Stop offset="0.75" stopColor="#B4AA96" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx="50%" cy={-40} rx="65%" ry={150} fill="url(#arrTop)" />
      </Svg>
      {sun ? (
        <Svg width={520} height={520} style={{ position: 'absolute', left: '50%', marginLeft: -260, bottom: -260 }}>
          <Defs>
            <RadialGradient id="arrSun" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#FFECC4" stopOpacity={0.4} />
              <Stop offset="0.45" stopColor="#FFECC4" stopOpacity={0.18} />
              <Stop offset="0.72" stopColor="#FFECC4" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={260} cy={260} rx={260} ry={260} fill="url(#arrSun)" />
        </Svg>
      ) : null}
    </View>
  );
}

/** The frame every handover screen positions inside. */
function Frame({ children, bg, field }: { children: ReactNode; bg: string; field?: ReactNode }) {
  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      {field}
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>{children}</View>
      </SafeAreaView>
    </View>
  );
}

/** The close cross three of these frames put at `right: 20/22, top: 66/26`. */
function CloseCross({ onPress, size, right, top, stroke, width }: { onPress: () => void; size: number; right: number; top: number; stroke: string; width: number }) {
  const a = size === 18 ? 3 : 3;
  const b = size - a;
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel="Close"
      hitSlop={{ top: 14, bottom: 14, left: 14, right: 14 }}
      style={{ position: 'absolute', right, top, width: size, height: size, minHeight: 0 }}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} fill="none">
        <Path d={`M${a} ${a}l${b - a} ${b - a}M${b} ${a}L${a} ${b}`} stroke={stroke} strokeWidth={width} strokeLinecap="round" />
      </Svg>
    </PressScale>
  );
}

/** The ink pill these frames close on — 56 tall at radius 28, or 54 at 27. */
function Cta({ label, onPress, y, h = 56, tracking = 0.2, tone = 'ink' }: { label: string; onPress: () => void; y: number; h?: 54 | 56 | 58; tracking?: number; tone?: 'ink' | 'paper' }) {
  const ink = tone === 'ink';
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        top: Y(y),
        height: h,
        minHeight: 0,
        borderRadius: h / 2,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: ink ? '#131313' : '#FFFFFF',
      }}>
      <AppText style={[sans('600'), { fontSize: 17, letterSpacing: tracking, color: ink ? '#FFFFFF' : '#131313' }]}>{label}</AppText>
    </PressScale>
  );
}

/** The quiet line under the pill — 15px/500 `#8B8882`, centred. */
function Quiet({ label, onPress, y }: { label: string; onPress: () => void; y: number }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      hitSlop={{ top: 14, bottom: 14, left: 24, right: 24 }}
      style={{ position: 'absolute', left: 0, right: 0, top: Y(y), minHeight: 0 }}>
      {/* the canvas centres the words inside a full-width box, so the box is
          full width here too rather than shrunk to the words */}
      <AppText center style={[sans('500'), { fontSize: 15, color: '#8B8882' }]}>{label}</AppText>
    </PressScale>
  );
}

// ── 37 · A Letter Arrived ────────────────────────────────────────────
/** An envelope on its back with a wax seal, tilted 2°. */
export function O3LetterArrived({ next, skip }: { next: () => void; skip: () => void }) {
  return (
    <Frame bg="#F4F3F0" field={<PaperArrivalField />}>
      <CloseCross onPress={skip} size={18} right={20} top={Y(66)} stroke="#55534E" width={2.2} />
      <View style={{ position: 'absolute', left: '50%', marginLeft: -130, top: Y(160), width: 260, height: 260 }}>
        <Svg width={180} height={180} style={{ position: 'absolute', left: 40, top: 10 }}>
          <Defs>
            <RadialGradient id="letGlow" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.5} />
              <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Circle cx={90} cy={90} r={90} fill="url(#letGlow)" />
        </Svg>
        <BlurredSolid left={40} top={226} width={180} height={16} fill="rgba(0,0,0,0.10)" blur={6} />
        <View
          style={{
            position: 'absolute',
            left: 46,
            top: 70,
            width: 168,
            height: 118,
            borderRadius: 10,
            boxShadow: '0 0 0 1px rgba(0,0,0,0.07), 0 16px 32px rgba(40,38,32,0.18)',
            transform: [{ rotate: '-2deg' }],
            overflow: 'hidden',
          }}>
          <LinearGradient colors={['#FCFAF4', '#F1EEE4']} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
          <Grain source={noiseDark} opacity={0.07} />
          <Svg width={168} height={118} viewBox="0 0 168 118" style={{ position: 'absolute', top: 0, left: 0 }}>
            <Path d="M2 4 L84 66 L166 4" fill="none" stroke="rgba(0,0,0,0.12)" strokeWidth={1.6} />
          </Svg>
        </View>
        <View
          style={{
            position: 'absolute',
            left: 106,
            top: 112,
            width: 48,
            height: 48,
            borderRadius: 24,
            boxShadow: SEAL_SHADOW,
            transform: [{ rotate: '-2deg' }],
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
          }}>
          <Svg width={48} height={48} style={{ position: 'absolute', top: 0, left: 0 }}>
            <Defs>
              {/* `radial-gradient(circle at 38% 30%, …)` states no size, so CSS
                  takes farthest-corner: from (38%, 30%) of a square that is
                  √(0.62² + 0.70²) = 93.5% of the box, not the 72% a
                  closest-side wash would use. `r` is stated alongside `rx`/`ry`
                  because only `r` reaches the DOM on web, where the other two
                  fall back to 50% and darken the rim (D064). */}
              <RadialGradient id="letSeal" cx="38%" cy="30%" r="93.5%" rx="93.5%" ry="93.5%">
                <Stop offset="0" stopColor="#F0DBB4" />
                <Stop offset="0.62" stopColor="#E2BA78" />
                <Stop offset="1" stopColor="#C99F5F" />
              </RadialGradient>
            </Defs>
            <Circle cx={24} cy={24} r={24} fill="url(#letSeal)" />
          </Svg>
          {/* CSS paints an inset shadow over the element's own background; here
              the background is that <Svg>, which lands on top of it instead — so
              the rim light is drawn again above the face (D098) */}
          <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 24, boxShadow: SEAL_RIM }} />
          {/* positioned for the same reason the medallion's strike is: an
              unstyled <Svg> lays out static beside three absolute siblings */}
          <Svg width={20} height={13} viewBox="0 0 40 26" style={{ position: 'relative', opacity: 0.55 }}>
            <Path d="M21 3 L21 16 L12 16 Z" fill="#5b4a28" />
            <Path d="M7 18 L33 18 Q30 24 20 24 Q10 24 7 18 Z" fill="#5b4a28" />
          </Svg>
        </View>
      </View>
      <AppText center style={[sans('500'), { position: 'absolute', left: 36, right: 36, top: Y(472), fontSize: 24, lineHeight: 32, letterSpacing: -0.1, color: '#1D1C1A' }, BALANCE]}>
        A letter arrived.
      </AppText>
      <AppText center style={[sans('400'), { position: 'absolute', left: 44, right: 44, top: Y(522), fontSize: 15.5, lineHeight: 23, color: '#55534E' }]}>
        From you, twelve weeks from now.
      </AppText>
      <Cta label="Open it" onPress={next} y={688} />
      <Quiet label="Save it for later" onPress={skip} y={764} />
    </Frame>
  );
}

// ── 38 · A Letter From Week XII ──────────────────────────────────────
/** A sheet from y 52 with a grab handle, a close cross and the letter in it. */
export function O3LetterRead({ name, paragraphs, onKeep, next }: { name: string; paragraphs: string[]; onKeep: () => void; next: () => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#EDECE7' }}>
      <View style={{ position: 'absolute', left: 0, right: 0, top: 52, bottom: 0, borderTopLeftRadius: 24, borderTopRightRadius: 24, backgroundColor: '#F4F3F0', overflow: 'hidden' }}>
        <Grain source={noiseDark} opacity={0.07} />
        <View style={{ position: 'absolute', left: 0, right: 0, top: 12, alignItems: 'center' }}>
          <View style={{ width: 38, height: 5, borderRadius: 3, backgroundColor: 'rgba(19,19,19,0.16)' }} />
        </View>
        <CloseCross onPress={next} size={20} right={22} top={26} stroke="#55534E" width={2} />
        <ScrollView
          style={{ position: 'absolute', left: 34, right: 34, top: 84, bottom: 80 }}
          showsVerticalScrollIndicator={false}
          contentInsetAdjustmentBehavior="never">
          <AppText style={[sans('600'), { fontSize: 18, letterSpacing: -0.1, color: '#1D1C1A', marginBottom: 22 }]}>{name ? `${name} —` : 'Friend —'}</AppText>
          {/* A Fragment, not a wrapping View: the frame lays these out as a flat
              run of block <p>s, and a wrapping View put a flex level between
              each paragraph and the scroll. It made no difference to the
              geometry, but it is nine boxes the frame does not have. */}
          {paragraphs.map((p, i) => (
            <Fragment key={i}>
              <AppText style={[sans('400'), { fontSize: 15.5, lineHeight: cssLineHeight(15.5, 1.8), color: '#3A3934', marginBottom: 20 }]}>{p}</AppText>
              {i === 2 ? <LetterMark /> : null}
            </Fragment>
          ))}
          {/* The canvas gives the sign-off `margin: 26px 0 8px` and the pill
              `margin: 56px 0 6px`, each following a box that already carries a
              bottom margin (20 on the last paragraph, 8 on the sign-off). CSS
              collapses the pair to the larger; Yoga adds them, so each top
              margin here is the canvas's less the one above it — D023, the same
              subtraction `LetterMark` makes. */}
          <AppText style={[sans('600'), { fontSize: 16, color: '#1D1C1A', marginTop: 6, marginBottom: 8 }]}>{name ? `— ${name}, at week XII` : '— you, at week XII'}</AppText>
          <PressScale
            onPress={onKeep}
            accessibilityRole="button"
            style={{ marginTop: 48, marginBottom: 6, height: 54, minHeight: 0, borderRadius: 27, backgroundColor: '#131313', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 }}>
            <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
              <Path
                d="M6 4.4h12a1 1 0 0 1 1 1v14.3a.8.8 0 0 1-1.27.65L12 16.7l-5.73 3.65A.8.8 0 0 1 5 19.7V5.4a1 1 0 0 1 1-1z"
                stroke="#FFFFFF"
                strokeWidth={2}
                strokeLinejoin="round"
              />
            </Svg>
            <AppText style={[sans('600'), { fontSize: 16.5, letterSpacing: 0.2, color: '#FFFFFF' }]}>Keep this letter</AppText>
          </PressScale>
        </ScrollView>
        <PressScale
          onPress={next}
          accessibilityRole="button"
          hitSlop={{ top: 14, bottom: 14, left: 24, right: 24 }}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 36, minHeight: 0, alignItems: 'center' }}>
          <AppText style={[sans('500'), { fontSize: 14.5, color: '#8B8882' }]}>Continue</AppText>
        </PressScale>
      </View>
    </View>
  );
}

/** The picture set into the letter after its third paragraph: a man on a shore. */
function LetterMark() {
  return (
    /* The canvas gives this block `margin: 36px auto 40px` and the paragraph
       above it `margin: 0 0 20px`. CSS collapses adjacent vertical margins to
       the larger of the two, so the gap the frame draws is 36, not 56; Yoga
       does not collapse, so the top margin is the difference. See D023. */
    <View style={{ width: 240, height: 186, marginTop: 16, marginBottom: 40, alignSelf: 'center', overflow: 'hidden' }}>
      <Svg width={112} height={112} style={{ position: 'absolute', left: 128, top: 4 }}>
        <Defs>
          <RadialGradient id="letMoon" cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.38} />
            <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx={56} cy={56} r={56} fill="url(#letMoon)" />
      </Svg>
      <View style={{ position: 'absolute', left: 162, top: 32, width: 34, height: 34, borderRadius: 17, backgroundColor: '#E9D2A4' }} />
      <View style={{ position: 'absolute', left: 14, top: 24, width: 2, height: 2, borderRadius: 1, backgroundColor: 'rgba(200,225,235,0.4)' }} />
      <View style={{ position: 'absolute', left: 44, top: 52, width: 2, height: 2, borderRadius: 1, backgroundColor: 'rgba(200,225,235,0.3)' }} />
      {/* three swells, each a box whose top edge is an elliptical arc — the
          canvas states 48 / 42 / 36pt of rise on a 50% horizontal radius */}
      <Hill height={100} rise={48} color="#DEDDD6" style={{ position: 'absolute', left: -40, right: -40, top: 100 }} />
      <Hill height={100} rise={42} color="#CFCEC7" style={{ position: 'absolute', left: -90, right: -30, top: 126 }} />
      <Hill height={100} rise={36} color="#C5C4BD" style={{ position: 'absolute', left: -30, right: -100, top: 148 }} />
      <View style={{ position: 'absolute', left: 34, top: 150, width: 13, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.55)', transform: [{ rotate: '14deg' }] }} />
      <View style={{ position: 'absolute', left: 58, top: 136, width: 13, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.55)', transform: [{ rotate: '10deg' }] }} />
      <View style={{ position: 'absolute', left: 84, top: 124, width: 13, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.55)', transform: [{ rotate: '6deg' }] }} />
      {/* the standard he plants, and the man beside it */}
      <View style={{ position: 'absolute', left: 139, top: 56, width: 3, height: 46, borderRadius: 2, backgroundColor: '#C6C5C0' }} />
      <View style={{ position: 'absolute', left: 142, top: 57, width: 15, height: 10, borderTopLeftRadius: 1, borderBottomLeftRadius: 1, borderTopRightRadius: 3, borderBottomRightRadius: 3, backgroundColor: '#E9D2A4' }} />
      <View style={{ position: 'absolute', left: 112, top: 64, width: 11, height: 11, borderRadius: 5.5, backgroundColor: '#B4B1AB' }} />
      <View style={{ position: 'absolute', left: 110, top: 77, width: 15, height: 27, borderRadius: 7, backgroundColor: '#C6C5C0' }} />
      <BlurredSolid left={100} top={100} width={44} height={10} fill="rgba(0,0,0,0.10)" blur={4} />
    </View>
  );
}

// ── 39 · The Vow ─────────────────────────────────────────────────────
export function O3TheVow({ name, date, onSign, skip }: { name: string; date: string; onSign: () => void; skip: () => void }) {
  return (
    <Frame bg="#FFFFFF">
      <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, top: Y(130), fontSize: 22, letterSpacing: 0.1, color: '#1D1C1A' }]}>
        The vow.
      </AppText>
      <AppText center style={[sans('400'), { position: 'absolute', left: 44, right: 44, top: Y(190), fontSize: 15.5, lineHeight: 24, color: '#55534E' }]}>
        I’m giving this twelve weeks. I don’t need to be perfect. When I want to watch, I’ll use the plan first. If I have a bad day, I’ll come back the next day.
      </AppText>
      <Svg width={200} height={200} style={{ position: 'absolute', left: '50%', marginLeft: -100, top: Y(316) }}>
        <Defs>
          <RadialGradient id="vowGlow" cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.38} />
            <Stop offset="0.72" stopColor="#E2BA78" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx={100} cy={100} r={100} fill="url(#vowGlow)" />
      </Svg>
      <View style={{ position: 'absolute', left: '50%', marginLeft: -28, top: Y(342), width: 56, height: 56, borderRadius: 28, boxShadow: '0 6px 18px rgba(226,186,120,0.45)', overflow: 'hidden' }}>
        <Svg width={56} height={56} style={{ position: 'absolute', top: 0, left: 0 }}>
          <Defs>
            {/* farthest-corner from (50%, 38%) of a square is
                √(0.50² + 0.62²) = 79.7% of the box; `r` as well as `rx`/`ry`,
                or the web build falls back to 50% (D064) */}
            <RadialGradient id="vowSun" cx="50%" cy="38%" r="79.7%" rx="79.7%" ry="79.7%">
              <Stop offset="0" stopColor="#F8E9CB" />
              <Stop offset="0.7" stopColor="#EFD3A2" />
              <Stop offset="1" stopColor="#E3BE85" />
            </RadialGradient>
          </Defs>
          <Circle cx={28} cy={28} r={28} fill="url(#vowSun)" />
        </Svg>
      </View>
      {/* the signature block: the name in a hand, a cross, a rule, and the date */}
      <View style={{ position: 'absolute', left: 36, right: 36, top: Y(442), height: 142 }}>
        <View style={{ position: 'absolute', left: 0, right: 0, top: 34, alignItems: 'center' }}>
          <AppText style={{ fontFamily: fonts.script, fontSize: 44, lineHeight: 44, color: '#1D1C1A', transform: [{ rotate: '-3deg' }] }}>{name || 'Friend'}</AppText>
        </View>
        <AppText style={[sans('400'), { position: 'absolute', left: 14, bottom: 44, fontSize: 14, color: '#B0AEA8' }]}>×</AppText>
        <View style={{ position: 'absolute', left: 12, right: 12, bottom: 40, height: 1.5, backgroundColor: 'rgba(0,0,0,0.24)' }} />
        <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, bottom: 14, fontSize: 12, color: '#B0AEA8' }]}>{date}</AppText>
      </View>
      <Cta label="I sign it" onPress={onSign} y={688} h={54} />
      <Quiet label="Not now" onPress={skip} y={760} />
    </Frame>
  );
}

// ── 40 · Medallion Earned ────────────────────────────────────────────
/**
 * This drop stripped the frame back to the object: the MEDALLION EARNED eyebrow
 * and the "Tier I" chip are both gone, and the line that stood under the chip
 * moved up into the space they left (530 → 482) and now names the medallion.
 */
export function O3MedallionEarned({ title, body, next, skip }: { title: string; body: string; next: () => void; skip: () => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#F6EEDD' }}>
      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' }}>
        <LinearGradient colors={['#F6EEDD', '#F0E1C2']} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <Svg width={340} height={340} style={{ position: 'absolute', left: '50%', marginLeft: -170, top: 70 }}>
          <Defs>
            <RadialGradient id="medHalo" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.38} />
              <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Circle cx={170} cy={170} r={170} fill="url(#medHalo)" />
        </Svg>
        <Grain source={noiseDark} opacity={0.07} />
      </View>
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <CloseCross onPress={skip} size={18} right={20} top={Y(66)} stroke="#55534E" width={2.2} />
          <View style={{ position: 'absolute', left: '50%', marginLeft: -130, top: Y(140), width: 260, height: 260 }}>
            <Svg width={200} height={200} style={{ position: 'absolute', left: 30, top: 20 }}>
              <Defs>
                <RadialGradient id="medGlow" cx="50%" cy="50%" rx="50%" ry="50%">
                  <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.55} />
                  <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
                </RadialGradient>
              </Defs>
              <Circle cx={100} cy={100} r={100} fill="url(#medGlow)" />
            </Svg>
            <BlurredSolid left={52} top={230} width={156} height={16} fill="rgba(0,0,0,0.11)" blur={6} />
            <View
              style={{
                position: 'absolute',
                left: 62,
                top: 52,
                width: 136,
                height: 136,
                borderRadius: 68,
                boxShadow: DISC_SHADOW,
                transform: [{ rotate: '-3deg' }],
                alignItems: 'center',
                justifyContent: 'center',
                gap: 7,
                overflow: 'hidden',
              }}>
              <Svg width={136} height={136} style={{ position: 'absolute', top: 0, left: 0 }}>
                <Defs>
                  {/* farthest-corner again — 93.5% of the 136pt disc, with `r`
                      stated for the web build (D064) */}
                  <RadialGradient id="medFace" cx="38%" cy="30%" r="93.5%" rx="93.5%" ry="93.5%">
                    <Stop offset="0" stopColor="#F0DBB4" />
                    <Stop offset="0.62" stopColor="#E2BA78" />
                    <Stop offset="1" stopColor="#C99F5F" />
                  </RadialGradient>
                </Defs>
                <Circle cx={68} cy={68} r={68} fill="url(#medFace)" />
              </Svg>
              {/* the rim light and the warm floor again, above the face: the
                  disc's background is an absolutely-positioned <Svg>, and CSS
                  paints that over the parent View's own inset shadows (D098) */}
              <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 68, boxShadow: DISC_RIM }} />
              <View style={{ position: 'absolute', left: 9, top: 9, right: 9, bottom: 9, borderRadius: 59, boxShadow: 'inset 0 0 0 1.5px rgba(91,74,40,0.35)' }} />
              {/* the canvas sets only `width: 42px`; a 40x26 viewBox makes the
                  height 27.3, and rounding it to 27 walks the strike up 0.15.
                  Positioned like `letter.tsx`'s `LaurelStrike`: react-native-svg
                  lays an unstyled <Svg> out `position: static` and the face and
                  the two rims beside it are absolute. Measured both ways the
                  board is identical here, but the guard costs nothing (D140) */}
              <Svg width={42} height={27.3} viewBox="0 0 40 26" style={{ position: 'relative', opacity: 0.55 }}>
                <Path d="M21 3 L21 16 L12 16 Z" fill="#5b4a28" />
                <Path d="M7 18 L33 18 Q30 24 20 24 Q10 24 7 18 Z" fill="#5b4a28" />
              </Svg>
              <AppText style={{ fontFamily: fonts.quote, fontSize: 17, fontWeight: '600', letterSpacing: 3, color: '#5b4a28', opacity: 0.6, marginRight: -3 }}>V</AppText>
            </View>
          </View>
          <AppText center style={[sans('600'), { position: 'absolute', left: 36, right: 36, top: Y(432), fontSize: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>{title}</AppText>
          <AppText center style={[sans('400'), { position: 'absolute', left: 44, right: 44, top: Y(482), fontSize: 15.5, lineHeight: 23, color: '#55534E' }]}>{body}</AppText>
          <Cta label="Take it" onPress={next} y={688} />
          {/* the frame draws a 15px/500 line at y 764 with no words in it */}
        </View>
      </SafeAreaView>
    </View>
  );
}

// ── 41 · Reminders ───────────────────────────────────────────────────
/** A notification as the OS would show it, used twice: live, then dimmed. */
function NotificationCard({ top, opacity, title, when, body }: { top: number; opacity: number; title: string; when: string; body: string }) {
  return (
    <View
      style={{
        position: 'absolute',
        left: 24,
        right: 24,
        top: Y(top),
        borderRadius: 16,
        backgroundColor: '#FFFFFF',
        boxShadow: '0 0 0 1px rgba(0,0,0,0.09)',
        paddingVertical: 16,
        paddingHorizontal: 18,
        opacity,
      }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Image source={laurelMark} contentFit="contain" style={{ width: 24, height: 24, opacity: 0.8 }} />
        <AppText style={[sans('600'), { flex: 1, fontSize: 15.5, color: '#1D1C1A' }]}>{title}</AppText>
        <AppText style={[sans('500'), { fontSize: 12.5, color: '#8B8882' }]}>{when}</AppText>
      </View>
      <AppText style={[sans('400'), { marginTop: 8, fontSize: 14.5, lineHeight: 21, color: '#55534E' }, WRAP]}>{body}</AppText>
    </View>
  );
}

/**
 * The second note no longer states a clock time: this drop replaced "10:41 PM"
 * with "You pick the time", so the screen promises a reminder without claiming
 * to know an hour the person has not chosen yet.
 */
export function O3Reminders({ window: riskWindow, onAllow, skip }: { window: string; onAllow: () => void; skip: () => void }) {
  return (
    <Frame bg="#F4F3F0">
      <AppText center style={[sans('500'), { position: 'absolute', left: 26, right: 26, top: Y(140), fontSize: 22, lineHeight: 29.04, letterSpacing: 0.1, color: '#1D1C1A' }]}>
        {`${riskWindow} is when you’re most likely to watch.`}
      </AppText>
      <AppText center style={[sans('400'), { position: 'absolute', left: 30, right: 30, top: Y(214), fontSize: 15.5, lineHeight: 23, color: '#55534E' }]}>
        Want VICI there before that time?
      </AppText>
      <NotificationCard top={280} opacity={1} title="Morning check-in" when="now" body="Twenty seconds — where's your head at today?" />
      <NotificationCard top={392} opacity={0.55} title="Late night ahead" when="You pick the time" body="The time you told us about. SOS is one tap away." />
      <Cta label="Turn on reminders" onPress={onAllow} y={688} tracking={0.3} />
      <Quiet label="Not now" onPress={skip} y={764} />
    </Frame>
  );
}

// ── 43 · Day 0 ───────────────────────────────────────────────────────
/** The first lesson, on a card whose top half is a night shore. */
export function O3DayZero({ lesson, next }: { lesson: string; next: () => void }) {
  return (
    <Frame bg="#F4F3F0" field={<Grain source={noiseDark} opacity={0.07} />}>
      <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, top: Y(118), fontSize: 22, letterSpacing: 0.1, color: '#1D1C1A' }]}>
        Day 0
      </AppText>
      <AppText center style={[sans('400'), { position: 'absolute', left: 44, right: 44, top: Y(158), fontSize: 14.5, lineHeight: 21, color: '#55534E' }]}>
        Your first lesson is ready. Start with one thing today.
      </AppText>
      <View
        style={{
          position: 'absolute',
          left: 56,
          right: 56,
          top: Y(236),
          borderRadius: 18,
          overflow: 'hidden',
          backgroundColor: '#FFFFFF',
          boxShadow: '0 0 0 1px rgba(0,0,0,0.05), 0 10px 24px rgba(40,38,32,0.07)',
        }}>
        <View style={{ height: 248, overflow: 'hidden' }}>
          <LinearGradient colors={['#0B0C0F', '#12151B', '#1A2027']} locations={[0, 0.6, 1]} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
          <View style={{ position: 'absolute', left: 64, top: 40, width: 2, height: 2, borderRadius: 1, backgroundColor: 'rgba(244,243,240,0.45)' }} />
          <View style={{ position: 'absolute', left: 104, top: 72, width: 1.5, height: 1.5, borderRadius: 0.75, backgroundColor: 'rgba(244,243,240,0.3)' }} />
          <View style={{ position: 'absolute', right: 40, top: 34, width: 2, height: 2, borderRadius: 1, backgroundColor: 'rgba(244,243,240,0.35)' }} />
          <View style={{ position: 'absolute', right: 96, top: 58, width: 1.5, height: 1.5, borderRadius: 0.75, backgroundColor: 'rgba(244,243,240,0.3)' }} />
          <Svg width={56} height={56} style={{ position: 'absolute', left: 22, top: 26 }}>
            <Defs>
              <RadialGradient id="dzMoonGlow" cx="50%" cy="50%" rx="50%" ry="50%">
                <Stop offset="0" stopColor="#DFDCD3" stopOpacity={0.16} />
                <Stop offset="0.72" stopColor="#DFDCD3" stopOpacity={0} />
              </RadialGradient>
            </Defs>
            <Circle cx={28} cy={28} r={28} fill="url(#dzMoonGlow)" />
          </Svg>
          <Svg width={26} height={26} viewBox="0 0 24 24" style={{ position: 'absolute', left: 37, top: 41 }}>
            <Path d="M14 3 A9 9 0 1 0 21 12 A7.2 7.2 0 0 1 14 3Z" fill="#E8E6DC" />
          </Svg>
          {/* the far shore */}
          <Svg width="100%" height="100%" viewBox="0 0 281 248" preserveAspectRatio="none" style={{ position: 'absolute', top: 0, left: 0 }}>
            <Path d="M-4,248 L-4,196 Q60,178 140,190 Q210,200 285,186 L285,248 Z" fill="#171B22" />
          </Svg>
          {/* the bench, and the man on it */}
          <View style={{ position: 'absolute', left: 38, top: 152, width: 8, height: 58, borderRadius: 3, backgroundColor: '#2C3844' }} />
          <View style={{ position: 'absolute', left: 44, top: 178, width: 82, height: 21, borderRadius: 6, backgroundColor: '#394656' }} />
          <View style={{ position: 'absolute', left: 50, top: 169, width: 28, height: 11, borderRadius: 5, backgroundColor: '#55677C' }} />
          <View style={{ position: 'absolute', left: 118, top: 199, width: 6, height: 12, borderRadius: 2, backgroundColor: '#26303C' }} />
          {/* the lamp, and the phone face-down under it */}
          <Svg width={92} height={92} style={{ position: 'absolute', right: 24, top: 118 }}>
            <Defs>
              <RadialGradient id="dzLamp" cx="50%" cy="50%" rx="50%" ry="50%">
                <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.2} />
                <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
              </RadialGradient>
            </Defs>
            <Circle cx={46} cy={46} r={46} fill="url(#dzLamp)" />
          </Svg>
          <View style={{ position: 'absolute', right: 56, top: 168, width: 52, height: 9, borderRadius: 3, backgroundColor: '#2C3844' }} />
          <View style={{ position: 'absolute', right: 76, top: 177, width: 8, height: 34, borderRadius: 2, backgroundColor: '#26303C' }} />
          <View style={{ position: 'absolute', right: 70, top: 140, width: 15, height: 26, borderRadius: 3, backgroundColor: '#DCE3EA' }} />
          <View style={{ position: 'absolute', right: 48, top: 128, width: 19, height: 19, borderRadius: 9.5, backgroundColor: '#E9D2A4', alignItems: 'center', justifyContent: 'center' }}>
            <Svg width={10} height={9} viewBox="0 0 9 8" fill="none">
              <Path d="M1.5 4l2 2 4-4.5" stroke="#131313" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" />
            </Svg>
          </View>
        </View>
        <View style={{ paddingTop: 16, paddingHorizontal: 18, paddingBottom: 18, gap: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: '#131313', alignItems: 'center', justifyContent: 'center' }}>
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
                <Circle cx={12} cy={12} r={4.5} fill="#F4F3F0" />
                <Path
                  d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5 5l2.1 2.1M16.9 16.9L19 19M19 5l-2.1 2.1M7.1 16.9L5 19"
                  stroke="#F4F3F0"
                  strokeWidth={2}
                  strokeLinecap="round"
                />
              </Svg>
            </View>
            <AppText style={[sans('600'), { fontSize: 13, color: '#1D1C1A' }]}>Today</AppText>
          </View>
          <AppText style={[sans('500'), { fontSize: 15, lineHeight: 22, color: '#1D1C1A' }]}>{lesson}</AppText>
        </View>
      </View>
      <View style={{ position: 'absolute', left: 16, right: 16, bottom: 84, height: 54, flexDirection: 'row', gap: 12 }}>
        <PressScale
          onPress={next}
          accessibilityRole="button"
          style={{ flex: 1, height: 54, minHeight: 0, borderRadius: 27, backgroundColor: '#131313', alignItems: 'center', justifyContent: 'center' }}>
          <AppText style={[sans('600'), { fontSize: 16.5, letterSpacing: 0.2, color: '#FFFFFF' }]}>Begin</AppText>
        </PressScale>
      </View>
    </Frame>
  );
}
