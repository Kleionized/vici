import { useId } from 'react';
import { View } from 'react-native';
import Svg, { Circle, ClipPath, Defs, Ellipse, G, LinearGradient as SvgLinearGradient, Path, RadialGradient, Rect, Stop } from 'react-native-svg';

/**
 * 088–089 · The medallions.
 *
 * Every face is the same struck disc: a metal (or, unearned, plain stock), two
 * dunes rolling across its bottom third, a raked highlight, and one small dark
 * device on top. The tier is not written on the coin — it is the coin. Paper is
 * the first metal, not the absence of one: a face that has reached tier I is
 * struck in paper, and a face that has reached nothing is the same stock with
 * no sun behind it.
 *
 * The ladder is five rungs on every tiered face — Paper I, Bronze II, Silver
 * III, Gold IV, Platinum V — and the four faces that mint once mint straight to
 * platinum (`Tiers One-offs`: "One tier only · platinum").
 */

export type KeepsakeSceneKey =
  | 'veni'
  | 'firstlight'
  | 'vidi'
  | 'vici'
  | 'breakwater'
  | 'rebound'
  | 'logbook'
  | 'pulse'
  | 'blackbox'
  | 'lessons'
  | 'archive'
  | 'return';

/**
 * The five treatments a medallion passes through as its tier climbs. Paper is
 * tier one; after that the coin is struck in a real material, and the material
 * is the reward: you can read how far someone is across a room, without a
 * number.
 */
export const KK_METALS = ['paper', 'bronze', 'silver', 'gold', 'platinum'] as const;
export type KKMetal = (typeof KK_METALS)[number];

// ── the disc: what the coin is struck from ───────────────────────────
type Face =
  | { kind: 'stock'; from: string; to: string }
  | { kind: 'struck'; cx: number; cy: number; r: number; c0: string; c1: string; mid: number; c2: string };

/**
 * `r` is the farthest-corner distance CSS gives a `radial-gradient(circle at
 * x% y%, …)` in a square box — the canvas's default sizing, computed once here
 * so the falloff lands in the same place.
 */
const DISC: Record<KKMetal, { face: Face; dunes: [string, string]; sheen: boolean }> = {
  paper: {
    face: { kind: 'stock', from: '#F1F0EB', to: '#ECEAE3' },
    dunes: ['#DEDDD6', '#CFCEC7'],
    sheen: false,
  },
  bronze: {
    face: { kind: 'struck', cx: 36, cy: 28, r: 96.33, c0: '#E0A96F', c1: '#B87F4C', mid: 0.58, c2: '#7E5527' },
    dunes: ['rgba(70,40,10,0.20)', 'rgba(70,40,10,0.32)'],
    sheen: false,
  },
  silver: {
    face: { kind: 'struck', cx: 36, cy: 28, r: 96.33, c0: '#F2F3F5', c1: '#C6CBD1', mid: 0.6, c2: '#969DA6' },
    dunes: ['rgba(55,65,78,0.15)', 'rgba(55,65,78,0.24)'],
    sheen: false,
  },
  gold: {
    face: { kind: 'struck', cx: 36, cy: 28, r: 96.33, c0: '#F8E3AC', c1: '#E7BE72', mid: 0.58, c2: '#BC8536' },
    dunes: ['rgba(140,90,20,0.22)', 'rgba(140,90,20,0.34)'],
    sheen: false,
  },
  platinum: {
    face: { kind: 'struck', cx: 35, cy: 26, r: 98.49, c0: '#FFFFFF', c1: '#EDF0F4', mid: 0.55, c2: '#C7CDD8' },
    dunes: ['rgba(90,100,118,0.14)', 'rgba(90,100,118,0.22)'],
    sheen: true,
  },
};

/**
 * The accents every device is drawn in — the same set on every metal.
 *
 * An earlier drop's app carried a five-row `ACCENT` table that recoloured each
 * device per metal. Nothing in `Latest Vici FULL` does that: the eight `Tiers`
 * frames draw byte-identical device markup on all five rows, and
 * `Breakwater-Gold` still fills the lamp's warm dot `#E2BA78` and its mast
 * `#C4C3BC` over a gold disc. The device is struck art, not painted art — it
 * reads the same whatever the coin is made of.
 */
const ACCENT = {
  /** horizons, quill nibs — the structural grey */
  struct: '#8A857C',
  /** the standards and masts the devices are raised on */
  pole: '#C4C3BC',
  /** seals, suns, sparks — the warm mark */
  warm: '#E2BA78',
  /** first light's rays */
  ray: '#C99F5F',
  /** the ruled lines on Lessons' cards, upper and lower */
  rule: '#DBDAD3',
  rule2: '#E1E0D9',
  /** Vidi's four stars, near to far */
  starA: '#CFCEC7',
  starB: '#C7C6BF',
  starC: '#D2D1CA',
  starD: '#D6D5CE',
} as const;

/** The grounding smudge every device but the two horizon scenes sits on. */
const GROUND = 'rgba(40,38,32,0.14)';

type SceneCtx = {
  a: typeof ACCENT;
  /** the dark two-stop wash every device is cut from */
  ink: string;
  /** Vidi's moon, and the paper circle that takes the bite out of it */
  moon: string;
  bite: string;
  /** Lessons' two cards — always the paper sheet, on every metal */
  sheet: string;
  /**
   * The standard Vici is planted on, and the mast Breakwater hangs its lamp
   * from. Every frame in the bundle strikes it in the pole accent — except the
   * five `Detail *` frames, which blow Vici up to 150pt and hold its staff at
   * the darker `#8A857C`. That override is Vici's alone: `Breakwater Paper`
   * draws the same 150pt disc with the mast still at `#C4C3BC`.
   */
  staff: string;
};

// ── the devices, one per medallion, drawn in a 100 × 100 disc ─────────
const KK_SCENES: Record<KeepsakeSceneKey, (c: SceneCtx) => React.ReactNode> = {
  // veni — the sail and the hull: stepped off the old shore
  veni: ({ ink }) => (
    <G>
      <Ellipse cx={50} cy={68} rx={21} ry={3.5} fill={GROUND} />
      <Path d="M52 24 L52 50 L35 50 Z" fill="#3A3934" />
      <Path d="M29 54 L73 54 Q69 64 51 64 Q33 64 29 54 Z" fill={ink} />
      <Path d="M34 56.5 L68 56.5" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth={2} strokeLinecap="round" />
    </G>
  ),
  // first light — half a sun on the horizon, three rays
  firstlight: ({ a }) => (
    <G>
      <Path d="M28 58 L72 58" fill="none" stroke={a.struct} strokeWidth={3} strokeLinecap="round" />
      <Path d="M38 58 a12 12 0 0 1 24 0 Z" fill={a.warm} />
      <Path d="M50 34 v-6 M35 41 l-4 -4 M65 41 l4 -4" fill="none" stroke={a.ray} strokeWidth={3} strokeLinecap="round" />
    </G>
  ),
  // vidi — the moon over four stars: days witnessed, one after another. The
  // canvas takes the crescent's bite with an opaque paper circle rather than a
  // mask, so the bite stays pale stock even on a struck coin.
  vidi: ({ a, moon, bite }) => (
    <G>
      <Circle cx={40} cy={32} r={15} fill={moon} />
      <Circle cx={48} cy={26} r={14} fill={bite} />
      <Circle cx={34} cy={38} r={2.2} fill={a.starA} />
      <Circle cx={41} cy={29} r={1.5} fill={a.starD} />
      <Circle cx={66} cy={20} r={1.8} fill={a.starB} />
      <Circle cx={24} cy={46} r={1.5} fill={a.starC} />
    </G>
  ),
  // vici — the standard planted: urges met and outlasted
  vici: ({ ink, staff }) => (
    <G>
      <Ellipse cx={48} cy={72} rx={16} ry={3} fill={GROUND} />
      <Rect x={44} y={22} width={4.5} height={48} rx={2.2} fill={staff} />
      <Path d="M50 24 C57 21.5 61 25.5 69 24 L69 37 C61 38.5 57 34.5 50 40 Z" fill={ink} />
    </G>
  ),
  // breakwater — the lamp that stayed lit on its mast through the worst of it
  breakwater: ({ a, ink, staff }) => (
    <G>
      <Ellipse cx={50} cy={70} rx={14} ry={3} fill={GROUND} />
      <Rect x={47} y={38} width={6} height={30} rx={3} fill={staff} />
      <Rect x={40} y={24} width={20} height={14} rx={6} fill={ink} />
      <Rect x={42} y={27} width={16} height={2.5} rx={1.2} fill="rgba(255,255,255,0.16)" />
      <Circle cx={50} cy={31} r={2.2} fill={a.warm} />
    </G>
  ),
  // rebound — the arrow back up, drawn the morning after
  rebound: ({ ink }) => (
    <G>
      <Ellipse cx={50} cy={70} rx={19} ry={3} fill={GROUND} />
      <Path d="M50 64 L50 36" fill="none" stroke={ink} strokeWidth={6} strokeLinecap="round" />
      <Path d="M37 47 L50 33 L63 47" fill="none" stroke={ink} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
    </G>
  ),
  // logbook — the ship's book, ruled and kept whatever the night held
  logbook: ({ ink }) => (
    <G>
      <Ellipse cx={50} cy={71} rx={19} ry={3} fill={GROUND} />
      <Rect x={31} y={30} width={38} height={38} rx={4} fill={ink} />
      <Rect x={31} y={30} width={7} height={38} rx={3} fill="#1D1C19" />
      <Path d="M46 40 L62 40 M46 48 L62 48 M46 56 L58 56" fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth={2.5} strokeLinecap="round" />
    </G>
  ),
  // pulse — the trace one check-in leaves on the chart
  pulse: ({ ink }) => (
    <G>
      <Ellipse cx={50} cy={68} rx={20} ry={3} fill={GROUND} />
      <Path d="M24 52 L38 52 L45 36 L54 64 L61 52 L73 52" fill="none" stroke={ink} strokeWidth={5.5} strokeLinecap="round" strokeLinejoin="round" />
      <Circle cx={76} cy={52} r={3.5} fill="#1D1C19" />
    </G>
  ),
  // black box — the recorder that survives the crash and says what happened
  blackbox: ({ ink }) => (
    <G>
      <Ellipse cx={50} cy={71} rx={20} ry={3} fill={GROUND} />
      <Rect x={31} y={41} width={38} height={26} rx={3.5} fill={ink} />
      <Rect x={28} y={33} width={44} height={10} rx={3} fill="#1D1C19" />
      <Rect x={45} y={50} width={10} height={7} rx={2} fill="rgba(255,255,255,0.2)" />
    </G>
  ),
  // lessons — two lesson cards and the pen across them
  lessons: ({ a, ink, sheet }) => (
    <G>
      <Ellipse cx={50} cy={77} rx={26} ry={4.5} fill="rgba(40,38,32,0.10)" />
      <G transform="rotate(-5 37 52)">
        <Rect x={21} y={33} width={30} height={40} rx={3.5} fill={sheet} />
        <Rect x={27} y={42} width={16} height={3} rx={1.5} fill={a.rule} />
        <Rect x={27} y={49} width={18} height={3} rx={1.5} fill={a.rule2} />
      </G>
      <G transform="rotate(3 64 52)">
        <Rect x={49} y={31} width={30} height={40} rx={3.5} fill={sheet} />
        <Rect x={55} y={40} width={15} height={3} rx={1.5} fill={a.rule} />
        <Rect x={55} y={47} width={17} height={3} rx={1.5} fill={a.rule2} />
      </G>
      <Rect x={44} y={44} width={36} height={4.5} rx={2.2} fill={ink} transform="rotate(-33 62 46)" />
    </G>
  ),
  // archive — the quill, laid down mid-sentence
  archive: ({ a, ink }) => (
    <G>
      <Ellipse cx={50} cy={71} rx={18} ry={3} fill={GROUND} />
      <Path d="M34 70 Q50 66 66 70" fill="none" stroke={a.struct} strokeWidth={2.5} strokeLinecap="round" />
      <G transform="rotate(-38 50 48)">
        <Rect x={46} y={26} width={9} height={34} rx={2} fill={ink} />
        <Path d="M46 60 L55 60 L50.5 70 Z" fill={a.struct} />
        <Rect x={46} y={26} width={9} height={5} rx={2} fill={a.warm} />
      </G>
    </G>
  ),
  // return — the arch you walk back through after a week away
  return: ({ ink }) => (
    <G>
      <Ellipse cx={50} cy={72} rx={20} ry={3} fill={GROUND} />
      <Path d="M33 70 L33 44 A17 17 0 0 1 67 44 L67 70 Z" fill={ink} />
      <Path d="M41 70 L41 47 A9 9 0 0 1 59 47 L59 70 Z" fill="rgba(255,255,255,0.26)" />
    </G>
  ),
};

/**
 * The rim the canvas presses into the disc. The album face is 68px, the tier
 * row's 64px and the detail face 150px, and the shadow is stated in device
 * pixels either way, so the numbers are carried literally and converted per
 * size. A tier row's bevel is the detail one byte for byte — `inset:3px` with
 * `inset 0 -7px 12px rgba(0,0,0,0.14)` — even though its coin is the album's
 * size, which is why the bevel and the 150pt staff are two separate choices.
 */
/**
 * The standard normal CDF at −2, −1, 0, 1 and 2 sigma. Five stops is enough to
 * hold a Gaussian ramp to about 1/255 at these alphas, and a straight two-stop
 * ramp is not: it runs ~3/255 dark at the top of the falloff and light below.
 */
const SEAT: [number, number][] = [[-2, 0.023], [-1, 0.159], [0, 0.5], [1, 0.841], [2, 0.977]];

const INNER: Record<'album' | 'tier' | 'detail', { inset: number; hair: number; lift: number; blur: number; alpha: number }> = {
  album: { inset: 2, hair: 1.5, lift: 6, blur: 10, alpha: 0.12 },
  tier: { inset: 3, hair: 1.5, lift: 7, blur: 12, alpha: 0.14 },
  detail: { inset: 3, hair: 1.5, lift: 7, blur: 12, alpha: 0.14 },
};

/**
 * The low sun 088 floats behind an album face, hand-placed per device so it
 * never lands on the device itself. The canvas states it as a `%` box with
 * `border-radius:50%` and `radial-gradient(closest-side, …)`, which is the
 * box's own circle — carried here as centre and radius in the 100-unit disc.
 * Only the 68pt album card carries one; no tier row and none of the ten 150pt
 * boards does.
 */
const SUN: Record<KeepsakeSceneKey, { cx: number; cy: number; r: number } | null> = {
  veni: { cx: 44, cy: 34, r: 28 },
  firstlight: { cx: 44, cy: 34, r: 28 },
  vidi: { cx: 72, cy: 56, r: 22 },
  vici: { cx: 51, cy: 31, r: 27 },
  breakwater: { cx: 51, cy: 27, r: 25 },
  rebound: { cx: 44, cy: 34, r: 28 },
  logbook: { cx: 72, cy: 56, r: 22 },
  pulse: { cx: 72, cy: 56, r: 22 },
  blackbox: { cx: 72, cy: 56, r: 22 },
  // `Album Earned II` draws Lessons earned and sunless, so Lessons has no
  // placement to state (D100).
  lessons: null,
  // Archive is the one placement no frame states: the canvas only ever draws it
  // unearned, and unearned is sunless. Its device is the quill, which sits where
  // Veni's does, so it takes Veni's box if it is ever struck.
  archive: { cx: 44, cy: 34, r: 28 },
  return: { cx: 72, cy: 56, r: 22 },
};

/**
 * Does a face's album card float the low sun?
 *
 * Twenty of the twenty-two cards the three album frames draw say the sun is the
 * mark of a struck face. The other two state themselves and are followed:
 * `Album Earned II` draws Lessons **earned with no sun**, and `Medallions Still
 * To Earn` draws Return **unearned with one**. D100 — the frames win over the
 * rule inferred from them, and the two exceptions are the only places the app
 * departs from it.
 */
export function kkSun(scene: KeepsakeSceneKey, earned: boolean): boolean {
  if (scene === 'lessons') return false;
  if (scene === 'return') return true;
  return earned;
}

export function KKMedallion({
  scene,
  size = 68,
  metal = 'paper',
  sun = false,
  variant = 'album',
}: {
  scene: KeepsakeSceneKey;
  size?: number;
  /** The treatment the coin is struck in. Paper is tier one, and also the stock an unearned face sits on. */
  metal?: KKMetal;
  /** Float the low sun behind the device — 088's mark of a struck face. */
  sun?: boolean;
  /** Which rim the canvas presses at this size. */
  variant?: 'album' | 'tier' | 'detail';
}) {
  const uid = useId().replace(/:/g, '');
  const disc = DISC[metal];
  const a = ACCENT;
  // The rim is quoted in device pixels; the drawing is a 100-unit viewBox.
  const u = 100 / size;
  const rim = INNER[variant];
  // Lessons states no placement at all, so `sun` alone is not enough to draw one.
  const glow = sun ? SUN[scene] : null;
  // The bevel's own circle: an inset shadow is clipped to the box it is set on,
  // and the canvas sets it on a div at `inset:<inset>px`, not on the disc.
  const innerR = 50 - rim.inset * u;
  const ringR = innerR - (rim.hair * u) / 2;
  // CSS states a blur *radius*; the Gaussian behind it has sigma = radius / 2.
  const sigma = (rim.blur * u) / 2;
  const seatR = innerR + 2 * sigma;

  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size} viewBox="0 0 100 100" fill="none">
        <Defs>
          <ClipPath id={`kkd-${uid}`}>
            <Circle cx={50} cy={50} r={50} />
          </ClipPath>
          <SvgLinearGradient id={`kkv-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#4A4843" />
            <Stop offset="1" stopColor="#1D1C19" />
          </SvgLinearGradient>
          {/* the moon and the lesson sheets are pale stock on every metal */}
          <SvgLinearGradient id={`kkm-${uid}`} x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor="#E6E5DE" />
            <Stop offset="1" stopColor="#C3C2BB" />
          </SvgLinearGradient>
          <SvgLinearGradient id={`kkp-${uid}`} x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor="#FFFFFF" />
            <Stop offset="1" stopColor="#EBEAE3" />
          </SvgLinearGradient>
          {disc.face.kind === 'stock' ? (
            <SvgLinearGradient id={`kkf-${uid}`} x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={disc.face.from} />
              <Stop offset="1" stopColor={disc.face.to} />
            </SvgLinearGradient>
          ) : (
            <RadialGradient id={`kkf-${uid}`} gradientUnits="userSpaceOnUse" cx={disc.face.cx} cy={disc.face.cy} r={disc.face.r}>
              <Stop offset="0" stopColor={disc.face.c0} />
              <Stop offset={disc.face.mid} stopColor={disc.face.c1} />
              <Stop offset="1" stopColor={disc.face.c2} />
            </RadialGradient>
          )}
          {/* The canvas's gloss, `linear-gradient(135deg, rgba(255,255,255,0.5),
              rgba(255,255,255,0) 40%, rgba(0,0,0,0.10))`. CSS interpolates
              premultiplied, so its middle stop is colourless and the second half
              is pure black rising from nothing; SVG interpolates
              non-premultiplied and ramps white → black through grey, which
              measured 6/255 too light across the lower-right of every struck
              coin. The doubled stop at 0.4 restores the discontinuity CSS has
              for free — D048's rule extended to a transparent stop that is not
              the end of the ramp (D104). */}
          <SvgLinearGradient id={`kkg-${uid}`} gradientUnits="userSpaceOnUse" x1={0} y1={0} x2={100} y2={100}>
            <Stop offset="0" stopColor="#FFFFFF" stopOpacity={0.5} />
            <Stop offset="0.4" stopColor="#FFFFFF" stopOpacity={0} />
            <Stop offset="0.4" stopColor="#000000" stopOpacity={0} />
            <Stop offset="1" stopColor="#000000" stopOpacity={0.1} />
          </SvgLinearGradient>
          {disc.sheen ? (
            <SvgLinearGradient id={`kks-${uid}`} gradientUnits="userSpaceOnUse" x1={-10.21} y1={21.92} x2={110.21} y2={78.08}>
              <Stop offset="0.3" stopColor="#FFFFFF" stopOpacity={0} />
              <Stop offset="0.42" stopColor="#FFFFFF" stopOpacity={0.75} />
              <Stop offset="0.54" stopColor="#FFFFFF" stopOpacity={0} />
            </SvgLinearGradient>
          ) : null}
          {/* The canvas's `inset 0 -Npx Mpx rgba(0,0,0,A)` seat. An inset
              box-shadow is the element's own shape lifted by the y-offset and
              Gaussian-blurred, painted wherever that lifted shape does not
              cover — so on a disc it is a crescent that hugs the rim and
              follows its curve, not a horizontal band. Modelled as a radial
              about the lifted centre whose stops are the Gaussian's own CDF
              across ±2 sigma. The vertical wash this replaces measured 12–16%
              of a struck coin's pixels over 8/255 (D103). */}
          <RadialGradient id={`kkb-${uid}`} gradientUnits="userSpaceOnUse" cx={50} cy={50 - rim.lift * u} r={seatR}>
            {SEAT.map(([k, phi]) => (
              <Stop key={k} offset={Math.max(0, (innerR + k * sigma) / seatR)} stopColor="#000000" stopOpacity={rim.alpha * phi} />
            ))}
          </RadialGradient>
          {glow ? (
            <RadialGradient id={`kku-${uid}`} gradientUnits="userSpaceOnUse" cx={glow.cx} cy={glow.cy} r={glow.r}>
              <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.42} />
              <Stop offset="0.75" stopColor="#E2BA78" stopOpacity={0} />
            </RadialGradient>
          ) : null}
        </Defs>

        <G clipPath={`url(#kkd-${uid})`}>
          <Circle cx={50} cy={50} r={50} fill={`url(#kkf-${uid})`} />
          {/* the sun sits on the field and under the land, as 088 stacks it */}
          {glow ? <Circle cx={glow.cx} cy={glow.cy} r={glow.r} fill={`url(#kku-${uid})`} /> : null}
          {/* the two dunes: CSS boxes with half-ellipse tops, traced as arcs */}
          <Path d="M-25 100.8 A75 36.8 0 0 1 125 100.8 L125 144 L-25 144 Z" fill={disc.dunes[0]} />
          <Path d="M-45 110 A80 32 0 0 1 115 110 L115 158 L-45 158 Z" fill={disc.dunes[1]} />
          {disc.face.kind === 'struck' ? (
            <>
              <Rect x={0} y={0} width={100} height={100} fill={`url(#kkg-${uid})`} />
              {disc.sheen ? <Rect x={0} y={0} width={100} height={100} fill={`url(#kks-${uid})`} /> : null}
              <Circle cx={50} cy={50} r={innerR} fill={`url(#kkb-${uid})`} />
              <Circle cx={50} cy={50} r={ringR} fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth={rim.hair * u} />
            </>
          ) : null}
          {KK_SCENES[scene]({
            a,
            ink: `url(#kkv-${uid})`,
            moon: `url(#kkm-${uid})`,
            bite: '#F1F0EB',
            sheet: `url(#kkp-${uid})`,
            staff: variant === 'detail' && scene === 'vici' ? '#8A857C' : a.pole,
          })}
        </G>
      </Svg>
    </View>
  );
}

// ── the album: which faces there are, and what each one costs ─────────

export type KKFace = {
  key: KeepsakeSceneKey;
  name: string;
  /**
   * What earns it, in one line. This is the `Tiers` page's own subtitle, and
   * the line the detail screen carries under the coin — `Tiers Breakwater`'s
   * subtitle and the `Breakwater *` blurb are the same string. A one-off's
   * blurb is the requirement sentence `Tiers One-offs` lists beside it, and
   * the canvas leaves those four without a full stop.
   */
  blurb: string;
  /** The longer telling the detail screen prefers where the canvas draws one. */
  long?: string;
  /** The line an unearned one-off carries on its album card. */
  ahead?: string;
  /** the rungs the medallion climbs; empty when it mints once */
  steps: number[];
  /** how a rung reads: days are set as `Day N`, everything else as a count */
  unit: 'day' | 'count' | null;
  /** what the rungs are counted in, for the unearned album card's "9 of 10 entries" */
  noun?: string;
  /** the line the medallion carries at each rung it reaches */
  stories: string[];
};

/**
 * The twelve faces the canvas draws, in the album's own order — `Medallions`
 * pages one and two hold the first ten, `Medallions Still To Earn` the last
 * two. Everything the two Medallions segments, the tier ladder and the detail
 * screen read about a face comes from here; the live counts are laid over it
 * by the screens.
 */
export const KK_ALBUM: KKFace[] = [
  {
    key: 'veni',
    name: 'Veni',
    blurb: 'Finished onboarding',
    steps: [],
    unit: null,
    stories: ['Nothing was asked of you yet. Just this: you stepped off the old shore. Everything since has been built on that alone.'],
  },
  {
    key: 'firstlight',
    name: 'First light',
    blurb: 'The first completed check-in',
    steps: [],
    unit: null,
    stories: ['Twenty seconds on an ordinary morning. Everything since has stacked on this.'],
  },
  {
    key: 'vidi',
    name: 'Vidi',
    blurb: 'Days Vici was opened and something recorded.',
    steps: [7, 30, 90, 180, 365],
    unit: 'day',
    noun: 'days',
    stories: [
      'Seven check-ins, two waves ridden, zero perfect days required.',
      'Around here, “trying something” turns into “how you live.”',
      'The long walk. By now the view is just… Tuesday.',
      'Six months witnessed, one day at a time. Vidi only asks that you stayed on it.',
      'A full year, witnessed. The campaign outlived the season it started in.',
    ],
  },
  {
    key: 'vici',
    name: 'Vici',
    blurb: 'Urge logs that did not end in a slip.',
    long: 'Urges met and outlasted — the conquering half of the campaign.',
    steps: [5, 25, 100, 250, 1000],
    unit: 'count',
    noun: 'logs',
    stories: [
      'Five ridden. Each one shortens the next.',
      'Twenty-five behind you now — the pattern is unmistakable.',
      'A hundred waves met and outlasted. This stopped being a fight you were unsure of a while ago.',
      'Two hundred and fifty. Vici isn’t a moment anymore. It’s just what you do.',
      'A thousand. The sea hasn’t changed. You’re just not the one it moves anymore.',
    ],
  },
  {
    key: 'breakwater',
    name: 'Breakwater',
    // The canvas keeps the mid-sentence capital on all six Breakwater frames:
    // "Overwhelming" is the top intensity band in the urge log, not an adjective.
    blurb: 'An Overwhelming urge that ended without a slip.',
    steps: [1, 5, 10, 25, 50],
    unit: 'count',
    noun: 'waves',
    stories: [
      'The first wave broke against you, not over you.',
      'Five storms met at full height. The wall is real now.',
      'Ten overwhelming urges, none of them decisive.',
      'Twenty-five. What used to flood you now only gets loud.',
      'Fifty waves. The sea hasn’t changed. The wall did.',
    ],
  },
  {
    key: 'rebound',
    name: 'Rebound',
    blurb: 'A check-in on the day after a slip.',
    steps: [1, 10, 25, 50, 100],
    unit: 'count',
    noun: 'mornings',
    stories: [
      'You slipped. The next morning you were back before breakfast. No spiral, no vanishing week.',
      'Ten bounces now. Ten is past the point where luck explains it.',
      'Twenty-five times down, twenty-five mornings back. The second number is the one that keeps up.',
      'Fifty. Falling has stopped meaning anything except that you get up.',
      'A hundred mornings after. The bounce is the strongest predictor there is, and you’re the proof of it.',
    ],
  },
  {
    key: 'logbook',
    name: 'Logbook',
    blurb: 'Urge logs saved, whatever the outcome.',
    steps: [5, 25, 75, 200, 500],
    unit: 'count',
    noun: 'logs',
    stories: [
      'Five logged. The point was never the outcome — it was writing it down at all.',
      'Twenty-five entries. The log is long enough now to argue with a bad memory.',
      'Seventy-five. Every one of them is a night you looked at instead of away from.',
      'Two hundred logs. There is nothing mysterious left about how an urge behaves.',
      'Five hundred. The record is the reason you can see the weather coming.',
    ],
  },
  {
    key: 'pulse',
    name: 'Pulse',
    blurb: 'Check-ins completed.',
    steps: [5, 25, 75, 200, 500],
    unit: 'count',
    noun: 'check-ins',
    stories: [
      'Five check-ins. Twenty seconds each, and already a line on the chart.',
      'Twenty-five. Enough mornings to tell a mood from a pattern.',
      'Seventy-five. The app knows your ordinary now, so the unusual shows up.',
      'Two hundred. This is the record of a life, kept a day at a time.',
      'Five hundred check-ins. Turning up stopped being a decision a long way back.',
    ],
  },
  {
    key: 'blackbox',
    name: 'Black Box',
    blurb: 'First slip recorded in an urge log',
    steps: [],
    unit: null,
    stories: ['You wrote down the one you lost. That entry is what the next ten are built on.'],
  },
  {
    key: 'lessons',
    name: 'Lessons',
    blurb: 'Lessons completed.',
    steps: [5, 25, 50, 75, 110],
    unit: 'count',
    noun: 'lessons',
    stories: [
      'Five lessons in. Early enough this still feels like homework. That won’t last.',
      'A quarter of the curriculum, done. More scaffolding built than it feels like.',
      'Halfway. The back half moves faster because the front half already changed how you think.',
      'Three-quarters through. What’s left is mostly deepening, not learning from scratch.',
      'Every lesson, finished. The curriculum’s done its job. The rest is just living it.',
    ],
  },
  {
    key: 'archive',
    name: 'Archive',
    blurb: 'Journal entries saved.',
    steps: [10, 50, 100, 200, 365],
    unit: 'count',
    noun: 'entries',
    stories: [
      'Ten entries in. A dozen specific paragraphs beat a hundred vague ones.',
      'Fifty pages of accounting. The patterns page runs on this ink.',
      'A hundred entries. You know your own weather better than most people know their week.',
      'Two hundred. The record’s long enough now to argue with your own memory, and win.',
      'A year of entries, one for almost every day. This is a diary of a life, not a habit tracker.',
    ],
  },
  {
    key: 'return',
    name: 'Return',
    blurb: 'A check-in after 7+ days away',
    // The album card writes the same requirement shorter — the one place the
    // two screens word it differently, so both strings are carried.
    ahead: 'After 7 days away',
    steps: [],
    unit: null,
    stories: ['A week gone, and you came back anyway. Nobody was watching. That is the whole of it.'],
  },
];

export function kkFace(key: string): KKFace | undefined {
  return KK_ALBUM.find((face) => face.key === key);
}

const ROMAN: [number, string][] = [
  [1000, 'M'],
  [900, 'CM'],
  [500, 'D'],
  [400, 'CD'],
  [100, 'C'],
  [90, 'XC'],
  [50, 'L'],
  [40, 'XL'],
  [10, 'X'],
  [9, 'IX'],
  [5, 'V'],
  [4, 'IV'],
  [1, 'I'],
];

export function kkRoman(n: number): string {
  let out = '';
  let left = n;
  for (const [value, glyph] of ROMAN) while (left >= value) { out += glyph; left -= value; }
  return out || '0';
}

/**
 * A rung as the album writes it: `Day XXX` for time, `×25` for everything else.
 *
 * The two screens that draw a day rung disagree on its numerals — the album
 * card writes `Tier I · Day VII` and `Tiers Vidi` writes `Tier I · Day 7` — so
 * the ladder screen asks for `arabic` and everything else takes the default.
 */
export function kkRung(face: KKFace, step: number, numerals: 'roman' | 'arabic' = 'roman'): string {
  if (face.unit !== 'day') return `×${step.toLocaleString('en-US')}`;
  return `Day ${numerals === 'roman' ? kkRoman(step) : step.toLocaleString('en-US')}`;
}

/** How many rungs a count has cleared. A face that mints once clears its one rung or none. */
export function kkStanding(face: KKFace, count: number): number {
  if (!face.steps.length) return count >= 1 ? 1 : 0;
  return face.steps.filter((step) => count >= step).length;
}

/**
 * Which treatment a face is struck in, given how many rungs are behind it.
 * The ladder is five rungs and there are five metals, so the rung *is* the
 * metal — and a face that mints once mints straight to platinum, which is what
 * `Tiers One-offs` draws under "One tier only · platinum".
 */
export function kkMetal(face: KKFace, standing: number): KKMetal {
  if (standing < 1) return 'paper';
  if (!face.steps.length) return 'platinum';
  return KK_METALS[Math.min(KK_METALS.length, standing) - 1];
}

/** The rung a treatment stands on — the inverse of `kkMetal`, for a detail route's `?tier=`. */
export function kkStandingFor(face: KKFace, metal: KKMetal): number {
  if (!face.steps.length) return 1;
  return KK_METALS.indexOf(metal) + 1;
}
