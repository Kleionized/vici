import { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, ScrollView, View, useWindowDimensions } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import type { PurchasesOffering } from 'react-native-purchases';

import { LinearGradient } from 'expo-linear-gradient';

import { PW_PROMISES, PW_SERIF, PW_SMALL_X, PaywallFlow, PwBand, PwCTA, PwPlanRow, PwPromiseColumn, PwX } from '@/components/paywall/PaywallFlow';
import { AppText, PressScale } from '@/components/ui';
import { usePurchases } from '@/lib/purchases';
import { bestValueId, describePackage, type PackageView } from '@/lib/purchases/plans';
import { offeringCopy } from '@/lib/purchases/metadata';
import { sans } from '@/lib/theme';

/**
 * The offering paywall — `48 · Paywall`, drawn from whatever the RevenueCat
 * offering contains.
 *
 * `PaywallFlow` is the canvas: two rows, two prices, three days, all pinned to
 * the frame they were drawn at. This is the same board with none of that fixed
 * — it renders every package the offering carries, in the dashboard's own
 * order, names each one from its package type rather than its identifier, takes
 * prices, cycles and introductory offers from the store, and takes its
 * headline, badges and call to action from the offering's metadata where the
 * dashboard sets any. Adding a six-month plan, reordering the rows, changing a
 * price, or A/B testing the copy is then a dashboard change and not a release —
 * which is what RevenueCat's guidance on displaying products asks for, and what
 * the drawn paywall cannot do.
 *
 * It used to draw `Free Trial Paywall` — a board this drop withdrew — and since
 * it is what a build with a RevenueCat key presents, the withdrawn paywall was
 * the shipping one while the measured one only ever appeared offline
 * (FINDINGS F25, D152). Everything above the rows is now `48 · Paywall`'s own,
 * at `48 · Paywall`'s own y: the head is pinned exactly where `PwMain` pins it,
 * and only the stack from the rows down is laid out in flow, so an offering
 * with the two packages VICI sells reproduces the frame to the point and one
 * with three simply grows downward.
 *
 * Every string still has the canvas's own word behind it, so an offering with
 * no metadata renders the paywall as drawn. With no packages at all — offline,
 * or an offering that failed to load — it hands back to `PaywallFlow` rather
 * than showing an empty board.
 */

/** The band's drawn height below the safe area, from `48 · Paywall`'s 290. */
const BAND = 236;

/**
 * The line under a package's name, in this order: the introductory offer if the
 * customer is eligible for one, then the comparable monthly price where it says
 * something the headline price does not, then the store's own description.
 * `48 · Paywall` writes those two as "$3.33 a month" and "Cancel anytime".
 */
function subtitleFor(view: PackageView): string {
  if (view.intro) {
    const period = view.intro.periodLabel;
    if (view.intro.isFree) return period ? `${period} free` : 'Free to start';
    return period ? `${view.intro.priceString} for ${period}` : view.intro.priceString;
  }
  if (view.pricePerMonthString && view.cycle !== '/month') return `${view.pricePerMonthString} a month`;
  return view.description || 'Cancel anytime';
}

/**
 * "SAVE 74%", worked out rather than written: the cheapest package's monthly
 * cost against the dearest one's, rounded the way the canvas rounds it.
 * Withheld unless there are two comparable prices and this row is the cheaper.
 */
function savingFor(view: PackageView, views: PackageView[]): string | undefined {
  const mine = view.pricePerMonth;
  if (typeof mine !== 'number') return undefined;
  const dearest = views.reduce<number | null>((a, v) => (typeof v.pricePerMonth === 'number' && (a === null || v.pricePerMonth > a) ? v.pricePerMonth : a), null);
  if (dearest === null || dearest <= mine) return undefined;
  const pct = Math.round((1 - mine / dearest) * 100);
  return pct > 0 ? `SAVE ${pct}%` : undefined;
}

export function OfferingPaywall({
  name,
  confirmLabel,
  embedded = false,
  placement,
  onDone,
}: {
  name?: string;
  confirmLabel?: string;
  /** Inside the onboarding shell: the ✕ skips the funnel rather than closing. */
  embedded?: boolean;
  /**
   * A RevenueCat placement identifier, when this paywall is shown at a named
   * point in the app. Falls back to the current offering where the placement
   * resolves to nothing — `/paywall` is opened by a deliberate tap, so showing
   * nothing at all would strand the customer.
   */
  placement?: string;
  onDone: (purchased: boolean) => void;
}) {
  const purchases = usePurchases();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();

  const [placed, setPlaced] = useState<PurchasesOffering | null>(null);
  const [chosen, setChosen] = useState<string | null>(null);
  const busy = useRef(false);

  const { offeringForPlacement } = purchases;
  useEffect(() => {
    if (!placement) return;
    let live = true;
    void offeringForPlacement(placement).then((offering) => {
      if (live) setPlaced(offering);
    });
    return () => {
      live = false;
    };
  }, [placement, offeringForPlacement]);

  const views = useMemo(() => (placed ? placed.availablePackages.map(describePackage) : purchases.packages), [placed, purchases.packages]);
  const copy = useMemo(() => (placed ? offeringCopy(placed) : purchases.copy), [placed, purchases.copy]);
  const best = useMemo(() => bestValueId(views), [views]);

  // The dashboard names the row to open on; failing that, the best value; and
  // failing that, whatever the offering lists first.
  const selectedId = chosen ?? (copy.defaultPackage && views.some((v) => v.id === copy.defaultPackage) ? copy.defaultPackage : (best ?? views[0]?.id ?? null));
  const selected = views.find((v) => v.id === selectedId) ?? views[0] ?? null;

  if (!purchases.ready) {
    return (
      <View style={{ flex: 1, backgroundColor: '#FAF8F3', alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color="#131313" />
      </View>
    );
  }
  // Nothing to sell here — the drawn paywall is a better answer than an empty board.
  if (!views.length || !selected) return <PaywallFlow name={name} confirmLabel={confirmLabel} embedded={embedded} onDone={onDone} />;

  async function buy() {
    if (busy.current || !selected) return;
    busy.current = true;
    const outcome = await purchases.purchasePackage(selected.pkg);
    busy.current = false;
    if (outcome.status === 'purchased' || (outcome.status === 'restored' && outcome.entitled)) return onDone(true);
    if (outcome.status === 'cancelled' || outcome.status === 'restored') return;
    Alert.alert('The store could not complete that', outcome.message);
  }

  async function restore() {
    if (busy.current) return;
    busy.current = true;
    const outcome = await purchases.restore();
    busy.current = false;
    if (outcome.status === 'restored') {
      if (outcome.entitled) return onDone(true);
      Alert.alert('Nothing to restore', 'This store account has no VICI Plus purchase on it.');
      return;
    }
    if (outcome.status === 'cancelled' || outcome.status === 'purchased') return;
    Alert.alert('Could not restore', outcome.message);
  }

  const bandH = insets.top + BAND;
  const cta = copy.cta ?? 'Continue';
  // The four discs are art, not strings, so the dashboard can rename them but
  // cannot add a fifth: a `benefits` list of exactly four relabels them in the
  // frame's own order and anything else leaves the drawn words standing.
  const labels = copy.benefits?.length === PW_PROMISES.length ? copy.benefits : null;

  return (
    <View style={{ flex: 1, backgroundColor: '#FAF8F3' }}>
      {/* the sunrise band `48 · Paywall` draws, dissolving into paper */}
      <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: bandH, overflow: 'hidden' }} pointerEvents="none">
        <PwBand w={width} h={bandH} />
      </View>

      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <View style={{ position: 'absolute', left: 20, top: 8, zIndex: 2 }}>
            <PwX onPress={() => onDone(false)} label={embedded ? 'Skip' : 'Close'} fill="rgba(255,255,255,0.7)" ring="rgba(0,0,0,0.06)" mark={PW_SMALL_X} />
          </View>
          <PressScale
            onPress={restore}
            accessibilityRole="button"
            hitSlop={{ top: 14, bottom: 14, left: 16, right: 16 }}
            style={{ position: 'absolute', right: 24, top: 16, minHeight: 0, zIndex: 2 }}>
            <AppText style={[sans('400'), { fontSize: 15, color: '#55534E' }]}>Restore</AppText>
          </PressScale>

          {/* the head is the frame's, at the frame's y: the mark straddles the
              band's last ten pixels so the wordmark carries paper behind it */}
          <View style={{ position: 'absolute', left: 0, right: 0, top: 226, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <AppText style={{ fontFamily: PW_SERIF, fontSize: 17, backgroundColor: '#FAF8F3', paddingHorizontal: 4, letterSpacing: 5, color: '#1D1C1A' }}>VICI</AppText>
            <LinearGradient colors={['#EBD3A2', '#DDBB7E']} style={{ height: 20, paddingHorizontal: 9, borderRadius: 10, alignItems: 'center', justifyContent: 'center' }}>
              <AppText style={[sans('700'), { fontSize: 9.5, letterSpacing: 1.4, color: '#4A3B1E' }]}>{copy.eyebrow ?? 'UNLIMITED'}</AppText>
            </LinearGradient>
          </View>
          <AppText center style={[sans('600'), { position: 'absolute', left: 24, right: 24, top: 262, fontSize: 26, lineHeight: 32, letterSpacing: -0.4, color: '#1D1C1A' }]}>
            {copy.headline ?? 'Take your life back.'}
          </AppText>
          <AppText center style={[sans('400'), { position: 'absolute', left: 40, right: 40, top: 302, fontSize: 13.5, lineHeight: 20, color: '#55534E' }]}>
            Break the cycle, rebuild your self-control, and become someone you can trust again.
          </AppText>

          {/* From the rows down the board is in flow, on the frame's own gaps:
              364 + 74 + 10 = 448, + 64 + 26 = 538, + 15 + 19 = 572, + 88 + 30 =
              690, + 54 + 14 = 758. Two packages land on 48's own numbers. */}
          {/* 342 + 22 is 364, and the 22 is headroom rather than spacing: a scroll
              view clips, and the chosen row's ornaments live outside its box —
              the 1.5pt gold ring spreads up to 416.5 and the drop shadow reaches
              about 18 above. Started at 364 the clip took both, as a hard 50/255
              edge across the whole width at 414. The sub's second line ends at
              342, which is the highest the view can start. */}
          <ScrollView style={{ flex: 1, marginTop: 342 }} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: 22, paddingBottom: 24 }}>
            <View style={{ marginHorizontal: 24, gap: 10 }} accessibilityRole="radiogroup">
              {views.map((view) => {
                const badge = copy.badges[view.id] ?? (view.id === best ? 'Best value' : undefined);
                const ribbon = view.id === best ? savingFor(view, views) : undefined;
                return (
                  <PwPlanRow
                    key={view.id}
                    active={view.id === selected.id}
                    onPress={() => setChosen(view.id)}
                    // the frame gives the badged row 74 and the plain one 64
                    height={badge || ribbon ? 74 : 64}
                    name={view.name}
                    badge={badge}
                    ribbon={ribbon}
                    sub={subtitleFor(view)}
                    price={view.priceString}
                    cycle={view.cycle}
                  />
                );
              })}
            </View>

            <View style={{ marginTop: 26, marginHorizontal: 24, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ flex: 1, height: 1, backgroundColor: 'rgba(0,0,0,0.08)' }} />
              <AppText style={[sans('500'), { fontSize: 12.5, color: '#55534E' }]}>{copy.benefitsTitle ?? 'What you get'}</AppText>
              <View style={{ flex: 1, height: 1, backgroundColor: 'rgba(0,0,0,0.08)' }} />
            </View>
            {/* 626 - 592 = 34 between two absolutes, and the rule's own line box
                is the 15 that sits inside it */}
            <View style={{ marginTop: 19, marginHorizontal: 20, flexDirection: 'row', gap: 6 }}>
              {PW_PROMISES.map(([k, label], i) => (
                <PwPromiseColumn key={k} k={k} label={labels?.[i] ?? label} />
              ))}
            </View>

            <View style={{ marginTop: 30, marginHorizontal: 24 }}>
              <PwCTA label={cta} onPress={() => void buy()} height={54} radius={27} size={16.5} tracking={0.2} arrow />
            </View>
            <AppText center style={[sans('400'), { marginTop: 14, fontSize: 11.5, color: '#8B8882' }]}>
              {copy.footnote ?? 'Terms · Restore'}
            </AppText>
          </ScrollView>
        </View>
      </SafeAreaView>
    </View>
  );
}
