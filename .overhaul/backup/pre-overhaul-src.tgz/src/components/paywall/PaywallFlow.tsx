import { LinearGradient } from 'expo-linear-gradient';
import { useId, useMemo, useRef, useState, type ReactNode } from 'react';
import { Alert, Platform, Pressable, View, useWindowDimensions } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, {
  Circle,
  Defs,
  FeGaussianBlur,
  Filter,
  G,
  LinearGradient as SvgLinearGradient,
  Path,
  RadialGradient,
  Rect,
  Stop,
} from 'react-native-svg';

import { AppText, Grain, PressScale } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { usePurchases } from '@/lib/purchases';
import { sans } from '@/lib/theme';

/**
 * VICI paywall — `48 · Paywall`, `50 · Paywall Rescue`, `51 · Paywall Confirmed`.
 *
 * 48 — a 290-tall sunrise ridge dissolving into paper, the VICI · UNLIMITED
 * mark, the promise, and the two plan rows where the chosen one floods ink
 * inside a gold ring ($39.99/yr · $12.99/mo). `Latest Vici FULL` withdrew the
 * old `Free Trial Paywall` and drew this in its place: a warmer paper
 * (#FAF8F3, not the app's #F4F3F0), no grain, four promise discs under a
 * "What you get" rule, and a flat "Continue" where the old board promised a
 * trial up front. 50 — pressing ✕ is rescued ONCE by the three-day offer;
 * declining that really closes. 51 — the paper confirmation, now over its own
 * ridge line.
 *
 * Laid out from the canvas's 393 × 852 frame: the status bar ends at 54, so
 * every canvas `top` below is written as `top − 54` under the safe area.
 *
 * Every price, cycle and trial length is read from the offering rather than
 * drawn in — the canvas's $39.99 / $12.99 / three days are what the offline
 * catalogue serves, so the frame still renders exactly, while a real store
 * shows the customer their own currency and their own introductory offer. The
 * drawn Apple Pay sheet is likewise only reached offline: with RevenueCat
 * configured the store presents its own sheet and this one never opens.
 */

const noiseDark = require('../../../assets/images/noise-dark.png');

type PlanKey = 'year' | 'month' | 'trial';

/** The catalogue plan a drawn row buys. The rescue offer sells the year too. */
const CATALOGUE = { year: 'yearly', trial: 'yearly', month: 'monthly' } as const;

/**
 * The prices this render draws, resolved from the offering with the canvas's
 * own numbers as the fallback.
 */
interface Money {
  yearPrice: string;
  yearCycle: string;
  yearPerMonth: string;
  /** The gold tab on the yearly row — "SAVE 74%", or nothing if it saves nothing. */
  yearSaving?: string;
  monthPrice: string;
  monthCycle: string;
  /** Length of the yearly plan's introductory offer, in days. */
  trialDays: number;
}

const DRAWN_MONEY: Money = { yearPrice: '$39.99', yearCycle: '/year', yearPerMonth: '$3.33', yearSaving: 'SAVE 74%', monthPrice: '$12.99', monthCycle: '/month', trialDays: 3 };

/**
 * `48 · Paywall` sets the wordmark in `'Times New Roman', Georgia, serif` —
 * one place, and not the `fonts.quote` Georgia the written boards use, so it is
 * named here rather than borrowed from a token whose first choice differs.
 */
export const PW_SERIF = Platform.select({ ios: 'Times New Roman', android: 'serif', default: "'Times New Roman', Georgia, serif" }) as string;

/**
 * "SAVE 74%" — the yearly price against twelve of the monthly one, rounded the
 * way the canvas rounds it. Null where either price is unknown or the year is
 * not actually the cheaper of the two, so the tab never claims a saving the
 * store is not offering.
 */
export function savingBadge(yearly: number | undefined, monthly: number | undefined): string | undefined {
  if (!yearly || !monthly) return undefined;
  const full = monthly * 12;
  const pct = Math.round((1 - yearly / full) * 100);
  return pct > 0 ? `SAVE ${pct}%` : undefined;
}

function fmtDate(d: Date) {
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}
/** The confirmed page names the charge day without a year — "until Jul 24". */
function fmtShort(d: Date) {
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
function checkoutFor(plan: PlanKey, m: Money) {
  const now = new Date();
  const afterTrial = new Date(now.getTime() + m.trialDays * 86400000);
  const in1y = new Date(now);
  in1y.setFullYear(in1y.getFullYear() + 1);
  const in1m = new Date(now);
  in1m.setMonth(in1m.getMonth() + 1);
  if (plan === 'trial')
    return {
      app: 'VICI Plus · Yearly',
      trial: `${m.trialDays} days free, then ${m.yearPrice}${m.yearCycle}`,
      due: '$0.00',
      note: `${m.yearPrice} on ${fmtDate(afterTrial)} · cancel anytime`,
    };
  if (plan === 'month') return { app: 'VICI Plus · Monthly', trial: null, due: m.monthPrice, note: `Renews ${fmtDate(in1m)} · cancel anytime` };
  return { app: 'VICI Plus · Yearly', trial: null, due: m.yearPrice, note: `Renews ${fmtDate(in1y)} · cancel anytime` };
}

// ── small shared pieces ──────────────────────────────────────────────
/**
 * The 34pt close disc. `minHeight: 0` keeps PressScale from inflating it to 44.
 *
 * The two frames that draw it disagree about the mark inside: `Paywall` sets a
 * 12px cross on a 12 box at stroke 1.8, `Paywall Rescue` a 15px cross on a 20
 * box at stroke 2.4 — the same 1.8pt line, over a 9pt span and a 10.5pt one.
 * The glyph is therefore passed in rather than assumed, and Rescue's is the
 * default because it is the older of the two.
 */
export function PwX({ onPress, label, fill, ring, mark }: { onPress: () => void; label: string; fill: string; ring: string; mark?: ReactNode }) {
  return (
    <PressScale
      onPress={onPress}
      hitSlop={{ top: 14, bottom: 14, left: 14, right: 14 }}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={{ width: 34, height: 34, minHeight: 0, borderRadius: 17, backgroundColor: fill, boxShadow: `0 0 0 1px ${ring}`, alignItems: 'center', justifyContent: 'center' }}>
      {mark ?? (
        <Svg width={15} height={15} viewBox="0 0 20 20">
          <Path d="M3 3l14 14M17 3L3 17" stroke="#1D1C1A" strokeWidth={2.4} strokeLinecap="round" />
        </Svg>
      )}
    </PressScale>
  );
}

/** `48 · Paywall`'s own ✕ — a 12px cross on a 12 box, at the same 1.8pt line. */
export const PW_SMALL_X = (
  <Svg width={12} height={12} viewBox="0 0 12 12">
    <Path d="M1.5 1.5l9 9M10.5 1.5l-9 9" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" />
  </Svg>
);

// 48's pill states 0.2 tracking and so do 50/51, but the earlier boards left it
// off, so tracking stays undefined unless a caller asks — AppText only keeps
// the variant's inherited tracking when it is given one.
export function PwCTA({
  label,
  onPress,
  height,
  radius,
  size,
  tracking,
  arrow,
}: {
  label: string;
  onPress: () => void;
  height: number;
  radius: number;
  size: number;
  tracking?: number;
  /** `48 · Paywall` sets a gold arrow 22 in from the pill's right edge. */
  arrow?: boolean;
}) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      style={{ height, borderRadius: radius, backgroundColor: '#131313', alignItems: 'center', justifyContent: 'center' }}>
      <AppText style={[sans('600'), { fontSize: size, letterSpacing: tracking, color: '#FFFFFF' }]}>{label}</AppText>
      {arrow ? (
        <Svg width={16} height={14} viewBox="0 0 16 14" style={{ position: 'absolute', right: 22, top: (height - 14) / 2 }}>
          <Path d="M1 7h13M9 2l5 5-5 5" fill="none" stroke="#E2BA78" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      ) : null}
    </PressScale>
  );
}

// ── the header band — the sunrise ridge `48 · Paywall` opens on ──────
/** The three ridge lines, back to front. Each is veiled by its own mist rect. */
const PW_RIDGE_1 = 'M-10 250 L-10.0 158.9 L96.0 108.0 L209.8 162.6 L311.0 114.0 L403.0 158.2 L403 250 Z';
const PW_RIDGE_2 =
  'M-10 250 L-10.0 179.6 L44.0 158.0 L84.5 174.2 L150.0 148.0 L208.5 171.4 L262.0 150.0 L313.5 170.6 L350.0 156.0 L403.0 177.2 L403 250 Z';
const PW_RIDGE_3 = 'M-10 250 L-10.0 207.0 L60.0 186.0 L114.7 202.4 L196.0 178.0 L269.7 200.1 L330.0 182.0 L403.0 203.9 L403 250 Z';

/** The two conifer combs along the front ridge — left edge and right shoulder. */
const PW_TREES = [
  'M-10 230 L-10 186 L-12.2 186.0 L-10.0 183.0 L-7.8 186.0 L-6.4 187.7 L-4.2 183.2 L-2.0 187.7 L-0.6 189.5 L1.6 184.5 L3.8 189.5 L5.3 191.2 L7.5 187.0 L9.7 191.2 L11.1 192.9 L13.3 189.5 L15.5 192.9 L16.9 194.6 L19.1 189.9 L21.3 194.6 L22.7 196.4 L24.9 191.5 L27.1 196.4 L28.5 198.1 L30.7 194.3 L32.9 198.1 L34.3 199.8 L36.5 195.9 L38.7 199.8 L40.2 201.5 L42.4 196.6 L44.6 201.5 L46.0 203.3 L48.2 198.6 L50.4 203.3 L51.8 205.0 L54.0 201.7 L56.2 205.0 L57.6 206.7 L59.8 202.5 L62.0 206.7 L63.4 208.5 L65.6 203.5 L67.8 208.5 L69.3 210.2 L71.5 205.8 L73.7 210.2 L75.1 211.9 L77.3 208.8 L79.5 211.9 L80.9 213.6 L83.1 209.1 L85.3 213.6 L86.7 215.4 L88.9 210.4 L91.1 215.4 L92.5 217.1 L94.7 213.0 L96.9 217.1 L98.3 218.8 L100.5 215.3 L102.7 218.8 L104.2 220.5 L106.4 215.7 L108.6 220.5 L110.0 222.3 L112.2 217.4 L114.4 222.3 L115.8 224.0 L118.0 220.3 L120.2 224.0 L118 224 L118 230 Z',
  'M300 230 L300 224 L297.8 224.0 L300.0 221.0 L302.2 224.0 L303.5 221.2 L305.7 216.7 L307.9 221.2 L309.2 218.4 L311.4 213.5 L313.6 218.4 L315.0 215.7 L317.2 211.5 L319.4 215.7 L320.7 212.9 L322.9 209.4 L325.1 212.9 L326.4 210.1 L328.6 205.4 L330.8 210.1 L332.1 207.3 L334.3 202.4 L336.5 207.3 L337.9 204.6 L340.1 200.8 L342.3 204.6 L343.6 201.8 L345.8 197.9 L348.0 201.8 L349.3 199.0 L351.5 194.1 L353.7 199.0 L355.0 196.2 L357.2 191.5 L359.4 196.2 L360.7 193.4 L362.9 190.1 L365.1 193.4 L366.5 190.7 L368.7 186.4 L370.9 190.7 L372.2 187.9 L374.4 182.9 L376.6 187.9 L377.9 185.1 L380.1 180.7 L382.3 185.1 L383.6 182.3 L385.8 179.2 L388.0 182.3 L389.4 179.6 L391.6 175.0 L393.8 179.6 L395.1 176.8 L397.3 171.8 L399.5 176.8 L400.8 174.0 L403.0 169.9 L405.2 174.0 L403 174 L403 230 Z',
];

/**
 * The band `48 · Paywall` opens on: sky, sun, two clouds, two far peaks, three
 * ridges each veiled by its own mist rect, a conifer comb at either end, and
 * the fog that dissolves the whole thing into paper.
 *
 * The canvas draws it 290 tall from the physical top of the phone — 54 of that
 * is the status bar this app never builds — so the height comes in from the
 * safe area and the viewBox is stretched to it rather than the art being
 * recomputed. Everything inside is the frame's own number, including the two
 * tiny Gaussian blurs (0.25 on the land, 0.8 on the clouds) that keep the
 * ridge edges off a hard vector line.
 */
export function PwBand({ w, h }: { w: number; h: number }) {
  const u = useId().replace(/:/g, '');
  const id = (k: string) => `${k}${u}`;
  const url = (k: string) => `url(#${id(k)})`;
  return (
    <Svg width={w} height={h} viewBox="0 0 393 290" preserveAspectRatio="none" style={{ position: 'absolute', left: 0, top: 0 }}>
      <Defs>
        <SvgLinearGradient id={id('sky')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#F6EBD8" />
          <Stop offset="0.6" stopColor="#F6EAD6" />
          <Stop offset="1" stopColor="#F7EEDF" />
        </SvgLinearGradient>
        <RadialGradient id={id('sun')} cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#FFF8E6" />
          <Stop offset="0.5" stopColor="#F9E2B4" />
          <Stop offset="1" stopColor="#EFC98A" />
        </RadialGradient>
        <RadialGradient id={id('glow')} cx="0.5" cy="0.5" r="0.5">
          <Stop offset="0" stopColor="#F4CC8C" stopOpacity={0.55} />
          <Stop offset="0.45" stopColor="#F4CC8C" stopOpacity={0.16} />
          <Stop offset="1" stopColor="#F4CC8C" stopOpacity={0} />
        </RadialGradient>
        <SvgLinearGradient id={id('l1')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#E4D8C2" />
          <Stop offset="1" stopColor="#EFE5D4" />
        </SvgLinearGradient>
        <SvgLinearGradient id={id('l2')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#DBCEB6" />
          <Stop offset="1" stopColor="#E9DECA" />
        </SvgLinearGradient>
        <SvgLinearGradient id={id('l3')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#D1C3A9" />
          <Stop offset="1" stopColor="#E2D6C2" />
        </SvgLinearGradient>
        <SvgLinearGradient id={id('l4')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#C3B296" />
          <Stop offset="1" stopColor="#D3C5AC" />
        </SvgLinearGradient>
        <SvgLinearGradient id={id('mist')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#F6EBD8" stopOpacity={0} />
          <Stop offset="1" stopColor="#F6EBD8" stopOpacity={0.9} />
        </SvgLinearGradient>
        <SvgLinearGradient id={id('fog')} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#FAF8F3" stopOpacity={0} />
          <Stop offset="0.7" stopColor="#FAF8F3" />
          <Stop offset="1" stopColor="#FAF8F3" />
        </SvgLinearGradient>
        <Filter id={id('soft')} x="-10%" y="-10%" width="120%" height="120%">
          <FeGaussianBlur stdDeviation="0.25" />
        </Filter>
        <Filter id={id('cloud')} x="-20%" y="-40%" width="140%" height="180%">
          <FeGaussianBlur stdDeviation="0.8" />
        </Filter>
      </Defs>
      <Rect width={393} height={290} fill={url('sky')} />
      <G transform="translate(0,52)">
        <Circle cx={196} cy={82} r={90} fill={url('glow')} />
        <Circle cx={196} cy={82} r={19} fill={url('sun')} />
        <G filter={url('cloud')} fill="#FFFFFF">
          <Path d="M40 86c6-10 20-12 30-5 6-7 20-6 24 2 8-2 14 1 16 4H36c-2-1-1-3 4-1Z" opacity={0.95} />
          <Path d="M300 90c5-8 16-9 24-4 4-5 14-5 18 0 6-1 12 2 14 4H296c-2-1-1-3 4 0Z" opacity={0.95} />
        </G>
        <G filter={url('soft')}>
          <Path d="M136 250 L136 146 L176 126 L216 146 L216 250 Z" fill="#EDE2CE" opacity={0.95} />
          <Path d="M178 250 L178 144 L222 122 L266 144 L266 250 Z" fill="#EDE2CE" opacity={0.95} />
        </G>
        <Path d={PW_RIDGE_1} fill={url('l1')} filter={url('soft')} />
        {/* the two snow caps sit on the first ridge's own summits, unblurred */}
        <Path d="M96 108 L85 113.3 L89 112.1 L92 113.9 L96 111.7 L100 113.9 L103 112.1 L107 113.3Z" fill="#FFFFFF" opacity={0.95} />
        <Path d="M311 114 L300 119.3 L304 118.1 L307 119.9 L311 117.7 L315 119.9 L318 118.1 L322 119.3Z" fill="#FFFFFF" opacity={0.95} />
        <Rect x={-10} y={120} width={413} height={130} fill={url('mist')} opacity={0.5} />
        <Path d={PW_RIDGE_2} fill={url('l2')} filter={url('soft')} />
        <Rect x={-10} y={150} width={413} height={100} fill={url('mist')} opacity={0.5} />
        <Path d={PW_RIDGE_3} fill={url('l3')} filter={url('soft')} />
        <Rect x={-10} y={176} width={413} height={74} fill={url('mist')} opacity={0.45} />
        {PW_TREES.map((d) => (
          <Path key={d.slice(0, 12)} d={d} fill={url('l4')} filter={url('soft')} />
        ))}
      </G>
      <Rect x={0} y={222} width={393} height={68} fill={url('fog')} />
    </Svg>
  );
}

/** The warm floor light on the rescue and confirmed pages: a 560 circle whose
 * centre hangs 300 below the frame. Each frame names both of its own stops —
 * 104 is 0.3 → 0.13, 105 is 0.44 → 0.2 — so the mid is passed in rather than
 * derived from the peak, which would put 105 at 0.1907. */
function PwFloorGlow({ peak, mid }: { peak: number; mid: number }) {
  const id = useId().replace(/:/g, '');
  return (
    <View style={{ position: 'absolute', left: '50%', bottom: -300, marginLeft: -280, width: 560, height: 560 }} pointerEvents="none">
      {/* positioned, not static: on web a bare <Svg> paints under every
          absolutely-positioned sibling regardless of document order */}
      <Svg width={560} height={560} style={{ position: 'absolute', top: 0, left: 0 }}>
        <Defs>
          <RadialGradient id={id} cx="50%" cy="50%" r="50%">
            <Stop offset="0" stopColor="#FFECC4" stopOpacity={peak} />
            <Stop offset="0.45" stopColor="#FFECC4" stopOpacity={mid} />
            <Stop offset="0.72" stopColor="#FFECC4" stopOpacity={0} />
            <Stop offset="1" stopColor="#FFECC4" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx={280} cy={280} r={280} fill={`url(#${id})`} />
      </Svg>
    </View>
  );
}

// ── 48 · Paywall — the two plan rows ─────────────────────────────────
/**
 * The frame draws Yearly on and Monthly off, so it names two palettes and not
 * four: ink under a gold ring with gold prices, and paper under a hairline with
 * soft-grey ones. The inverse — Monthly chosen — is the same two palettes the
 * other way round, which is the only reading the drawing supports.
 */
const PW_ON = { bg: '#131313', ring: '0 0 0 1.5px #D9B878, 0 10px 28px rgba(40,38,32,0.18)', name: '#FFFFFF', sub: 'rgba(255,255,255,0.6)', price: '#FFFFFF', cycle: '#E2BA78', badge: '#E2BA78', badgeRing: '#D9B878' };
/* The "Best value" pill is drawn only on the chosen row, so its gold was chosen
   against ink. On the unchosen row that same gold is 1.8:1 on white and barely
   readable, and the frame already states what an ornament does when its row
   goes to paper — the radio turns from a gold disc into an `rgba(0,0,0,0.18)`
   hairline. The pill follows the radio (D153). */
const PW_OFF = { bg: '#FFFFFF', ring: '0 0 0 1px rgba(0,0,0,0.08)', name: '#1D1C1A', sub: '#8B8882', price: '#1D1C1A', cycle: '#8B8882', badge: '#1D1C1A', badgeRing: 'rgba(0,0,0,0.18)' };

/** The 24pt mark at the head of a row: a gold disc when chosen, a ring when not. */
function PwRadio({ on }: { on: boolean }) {
  // The frame writes the unchosen ring as `inset 0 0 0 1.6px`, not as a border,
  // and the two are not quite the same paint: a border snaps to the device grid
  // and an inset shadow antialiases against the rounded inner edge, which left
  // 16 blocks at 7.4/255 on this disc as the last residue on the whole board.
  if (!on) return <View style={{ width: 24, height: 24, borderRadius: 12, boxShadow: 'inset 0 0 0 1.6px rgba(0,0,0,0.18)' }} />;
  return (
    <View style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: '#E2BA78', alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={14} height={11} viewBox="0 0 16 12">
        <Path d="M1.5 6l4.4 4.5L14.5 1.5" fill="none" stroke="#131313" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    </View>
  );
}

export function PwPlanRow({
  active,
  onPress,
  top,
  height,
  name,
  badge,
  ribbon,
  sub,
  price,
  cycle,
}: {
  active: boolean;
  onPress: () => void;
  /** The frame's own y. Omitted by a paywall whose row count is not the frame's,
      which stacks the same rows in flow instead. */
  top?: number;
  height: number;
  name: string;
  /** "Best value" — a gold-ringed pill beside the name, on the yearly row only. */
  badge?: string;
  /** "SAVE 74%" — the gold tab hung off the row's top-right corner. */
  ribbon?: string;
  sub: string;
  price: string;
  cycle: string;
}) {
  const t = active ? PW_ON : PW_OFF;
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ checked: active }}
      accessibilityLabel={`${name}, ${price}${cycle}`}
      style={{
        ...(top == null ? null : { position: 'absolute', left: 24, right: 24, top }),
        height,
        borderRadius: 18,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 14,
        paddingHorizontal: 20,
        backgroundColor: t.bg,
        boxShadow: t.ring,
      }}>
      {ribbon ? (
        // the frame's own `top: -1`: the tab laps a pixel over the row's 1.5pt
        // gold ring, so no hairline of ink shows between the two golds
        <LinearGradient
          colors={['#EBD3A2', '#DDBB7E']}
          style={{ position: 'absolute', right: 14, top: -1, height: 22, paddingHorizontal: 10, borderBottomLeftRadius: 10, borderBottomRightRadius: 10, alignItems: 'center', justifyContent: 'center' }}>
          <AppText style={[sans('700'), { fontSize: 10.5, letterSpacing: 0.6, color: '#3A2E15' }]}>{ribbon}</AppText>
        </LinearGradient>
      ) : null}
      <PwRadio on={active} />
      <View style={{ flex: 1 }}>
        {/* no strut: the frame measures this line at 20 on the row that has a
            badge and at the name's own 18 on the row that has none, which is
            what the badge's 20pt box already produces */}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <AppText style={[sans('600'), { fontSize: 16, color: t.name }]}>{name}</AppText>
          {badge ? (
            <View style={{ height: 20, paddingHorizontal: 9, borderRadius: 10, boxShadow: `0 0 0 1px ${t.badgeRing}`, alignItems: 'center', justifyContent: 'center' }}>
              <AppText style={[sans('600'), { fontSize: 11, color: t.badge }]}>{badge}</AppText>
            </View>
          ) : null}
        </View>
        <AppText style={[sans('400'), { marginTop: 3, fontSize: 12.5, color: t.sub }]}>{sub}</AppText>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        <AppText style={[sans('600'), { fontSize: 18, letterSpacing: -0.3, color: t.price }]}>{price}</AppText>
        <AppText style={[sans('400'), { fontSize: 12, color: t.cycle }]}>{cycle}</AppText>
      </View>
    </PressScale>
  );
}

// ── 48 · Paywall — the four promises under "What you get" ────────────
type PwPromise = 'plan' | 'sos' | 'insights' | 'progress';

/** The four discs, in the frame's order, each label broken where the frame breaks it. */
export const PW_PROMISES: [PwPromise, string][] = [
  ['plan', '12-week\nplan'],
  ['sos', 'SOS\nhelp'],
  ['insights', 'Weekly\ninsights'],
  ['progress', 'Progress\ntracking'],
];

const PW_LINE = { fill: 'none', stroke: '#1D1C1A', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const PW_GOLD = { ...PW_LINE, stroke: '#D9B878' } as const;

function PwPromiseIcon({ k }: { k: PwPromise }) {
  // 26 on 32, centred in the 50 disc. Positioned rather than static: on web a
  // bare <Svg> paints under the absolutely-positioned gradient behind it.
  const box = { position: 'absolute', left: 12, top: 12 } as const;
  if (k === 'plan')
    return (
      <Svg width={26} height={26} viewBox="0 0 32 32" style={box}>
        <Rect x={5} y={7.5} width={22} height={19} rx={4} fill="#FFFFFF" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M5 13h22" {...PW_LINE} />
        <Path d="M11 4.5v5M21 4.5v5" {...PW_LINE} />
        <Rect x={9} y={16.5} width={4} height={3.4} rx={1} fill="#D9B878" />
        <Rect x={14} y={16.5} width={4} height={3.4} rx={1} fill="#1D1C1A" opacity={0.18} />
        <Rect x={19} y={16.5} width={4} height={3.4} rx={1} fill="#1D1C1A" opacity={0.18} />
        <Rect x={9} y={21.5} width={4} height={3.4} rx={1} fill="#1D1C1A" opacity={0.18} />
        <Rect x={14} y={21.5} width={4} height={3.4} rx={1} fill="#1D1C1A" opacity={0.18} />
      </Svg>
    );
  if (k === 'sos')
    return (
      <Svg width={26} height={26} viewBox="0 0 32 32" style={box}>
        <Circle cx={16} cy={16} r={11} fill="#FFFFFF" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Circle cx={16} cy={16} r={4.5} fill="#FBF6EA" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M16 5v6.5M16 20.5V27M5 16h6.5M20.5 16H27" {...PW_LINE} />
        <Path d="M9.5 9.5l2.6 2.6M22.5 9.5l-2.6 2.6M9.5 22.5l2.6-2.6M22.5 22.5l-2.6-2.6" {...PW_GOLD} />
      </Svg>
    );
  if (k === 'insights')
    return (
      <Svg width={26} height={26} viewBox="0 0 32 32" style={box}>
        <Path d="M16 4.5v2M7 8l1.5 1.5M25 8l-1.5 1.5M4.5 16h2M25.5 16h2" {...PW_GOLD} />
        <Path d="M11.5 22.5c0-2-1.2-3-2.2-4.2A6.8 6.8 0 1 1 22.7 18.3c-1 1.2-2.2 2.2-2.2 4.2z" fill="#FFFFFF" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M12.5 25.5h7M13.5 28h5" {...PW_LINE} />
        <Path d="M14 22.5l1-5h2l1 5" {...PW_GOLD} />
      </Svg>
    );
  return (
    <Svg width={26} height={26} viewBox="0 0 32 32" style={box}>
      <Path d="M5 27h22" {...PW_LINE} />
      <Rect x={7} y={19} width={4} height={8} rx={1} fill="#FFFFFF" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      <Rect x={14} y={14.5} width={4} height={12.5} rx={1} fill="#FFFFFF" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      <Rect x={21} y={9.5} width={4} height={17.5} rx={1} fill="#FBF6EA" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      <Path d="M6 12.5l6-4.5 5 3 8-6" {...PW_GOLD} />
      <Path d="M22 5h3v3" {...PW_GOLD} />
    </Svg>
  );
}

export function PwPromiseColumn({ k, label }: { k: PwPromise; label: string }) {
  const id = useId().replace(/:/g, '');
  return (
    <View style={{ flex: 1, alignItems: 'center', gap: 10 }}>
      <View style={{ width: 50, height: 50, borderRadius: 25, boxShadow: '0 0 0 1px rgba(0,0,0,0.06), 0 8px 18px rgba(40,38,32,0.08)' }}>
        {/* radial-gradient(circle at 50% 35%, #FFFFFF, #F3EFE5). CSS's default
            extent is farthest-corner, and from (25, 17.5) in a 50 box that
            corner is 41.0 away — a View cannot hold a radial fill, so the disc
            is an <Svg> under the icon. */}
        <Svg width={50} height={50} style={{ position: 'absolute', left: 0, top: 0 }}>
          <Defs>
            <RadialGradient id={id} cx="25" cy="17.5" r="41" gradientUnits="userSpaceOnUse">
              <Stop offset="0" stopColor="#FFFFFF" />
              <Stop offset="1" stopColor="#F3EFE5" />
            </RadialGradient>
          </Defs>
          <Circle cx={25} cy={25} r={25} fill={`url(#${id})`} />
        </Svg>
        <PwPromiseIcon k={k} />
      </View>
      <AppText center style={[sans('500'), { fontSize: 11.5, lineHeight: 14, color: '#1D1C1A' }]}>
        {label}
      </AppText>
    </View>
  );
}

// ═════ 48 — THE PLANS ════════════════════════════════════════════════
function PwMain({
  plan,
  setPlan,
  onPay,
  onClose,
  onRestore,
  closeLabel,
  money,
}: {
  plan: PlanKey;
  setPlan: (p: PlanKey) => void;
  onPay: () => void;
  onClose: () => void;
  onRestore: () => void;
  closeLabel: string;
  money: Money;
}) {
  return (
    <View style={{ flex: 1 }}>
      <View style={{ position: 'absolute', left: 20, top: 8 }}>
        <PwX onPress={onClose} label={closeLabel} fill="rgba(255,255,255,0.7)" ring="rgba(0,0,0,0.06)" mark={PW_SMALL_X} />
      </View>
      {/* drawn as a plain label; the footer's "Restore" is the other half of it */}
      <PressScale
        onPress={onRestore}
        accessibilityRole="button"
        hitSlop={{ top: 14, bottom: 14, left: 16, right: 16 }}
        style={{ position: 'absolute', right: 24, top: 16, minHeight: 0 }}>
        <AppText style={[sans('400'), { fontSize: 15, color: '#55534E' }]}>Restore</AppText>
      </PressScale>

      {/* the mark straddles the band's last ten pixels, so the wordmark carries
          the paper colour behind it the way the frame does */}
      <View style={{ position: 'absolute', left: 0, right: 0, top: 226, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
        <AppText style={{ fontFamily: PW_SERIF, fontSize: 17, backgroundColor: '#FAF8F3', paddingHorizontal: 4, letterSpacing: 5, color: '#1D1C1A' }}>VICI</AppText>
        <LinearGradient colors={['#EBD3A2', '#DDBB7E']} style={{ height: 20, paddingHorizontal: 9, borderRadius: 10, alignItems: 'center', justifyContent: 'center' }}>
          <AppText style={[sans('700'), { fontSize: 9.5, letterSpacing: 1.4, color: '#4A3B1E' }]}>UNLIMITED</AppText>
        </LinearGradient>
      </View>
      <AppText center style={[sans('600'), { position: 'absolute', left: 24, right: 24, top: 262, fontSize: 26, lineHeight: 32, letterSpacing: -0.4, color: '#1D1C1A' }]}>
        Take your life back.
      </AppText>
      <AppText center style={[sans('400'), { position: 'absolute', left: 40, right: 40, top: 302, fontSize: 13.5, lineHeight: 20, color: '#55534E' }]}>
        Break the cycle, rebuild your self-control, and become someone you can trust again.
      </AppText>

      <PwPlanRow
        active={plan === 'year'}
        onPress={() => setPlan('year')}
        top={364}
        height={74}
        name="Yearly"
        badge="Best value"
        ribbon={money.yearSaving}
        sub={`${money.yearPerMonth} a month`}
        price={money.yearPrice}
        cycle={money.yearCycle}
      />
      <PwPlanRow
        active={plan === 'month'}
        onPress={() => setPlan('month')}
        top={448}
        height={64}
        name="Monthly"
        sub="Cancel anytime"
        price={money.monthPrice}
        cycle={money.monthCycle}
      />

      <View style={{ position: 'absolute', left: 24, right: 24, top: 538, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ flex: 1, height: 1, backgroundColor: 'rgba(0,0,0,0.08)' }} />
        <AppText style={[sans('500'), { fontSize: 12.5, color: '#55534E' }]}>What you get</AppText>
        <View style={{ flex: 1, height: 1, backgroundColor: 'rgba(0,0,0,0.08)' }} />
      </View>
      <View style={{ position: 'absolute', left: 20, right: 20, top: 572, flexDirection: 'row', gap: 6 }}>
        {PW_PROMISES.map(([k, label]) => (
          <PwPromiseColumn key={k} k={k} label={label} />
        ))}
      </View>

      <View style={{ position: 'absolute', left: 24, right: 24, top: 690 }}>
        <PwCTA label="Continue" onPress={onPay} height={54} radius={27} size={16.5} tracking={0.2} arrow />
      </View>
      <AppText center style={[sans('400'), { position: 'absolute', left: 0, right: 0, top: 758, fontSize: 11.5, color: '#8B8882' }]}>
        Terms · Restore
      </AppText>
    </View>
  );
}

// ═════ 104 — THE RESCUE: three days free, shown once when he walks ═══
function OfferIcon({ k, c }: { k: string; c: string }) {
  if (k === 'today')
    return (
      <Svg width={21} height={21} viewBox="0 0 24 24" fill="none">
        <Path d="M7.5 10.5V7a4.5 4.5 0 0 1 8.6-1.8" stroke={c} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Rect x={4.4} y={10} width={15.2} height={10.5} rx={2.6} stroke={c} strokeWidth={1.8} strokeLinejoin="round" />
        <Path d="M12 14v2.6" stroke={c} strokeWidth={1.8} strokeLinecap="round" />
      </Svg>
    );
  if (k === 'day2')
    return (
      <Svg width={21} height={21} viewBox="0 0 24 24" fill="none">
        <Path d="M12 3.4a5.8 5.8 0 0 1 5.8 5.8v3.6l1.7 2.4a1 1 0 0 1-.8 1.6H5.3a1 1 0 0 1-.8-1.6l1.7-2.4V9.2A5.8 5.8 0 0 1 12 3.4z" stroke={c} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M10 19.6a2.2 2.2 0 0 0 4 0" stroke={c} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    );
  return (
    <Svg width={21} height={21} viewBox="0 0 24 24" fill="none">
      <Rect x={3.5} y={5.5} width={17} height={13.5} rx={2.6} stroke={c} strokeWidth={1.8} strokeLinejoin="round" />
      <Path d="M3.5 9.5h17" stroke={c} strokeWidth={1.8} strokeLinecap="round" />
      <Path d="M7 15h4" stroke={c} strokeWidth={1.8} strokeLinecap="round" />
    </Svg>
  );
}

/** The three days, at canvas y 300 / 396 / 492 — a 96 pitch, not a stack. */
function pwOffer(m: Money): [string, string, number][] {
  return [
    ['today', 'Today — everything unlocks', 246],
    ['day2', `Day ${m.trialDays - 1} — a reminder, before any charge`, 342],
    ['day3', `Day ${m.trialDays} — ${m.yearPrice}${m.yearCycle} begins, unless you cancel`, 438],
  ];
}

function PwTrialOffer({ onStart, onNo, closeLabel, money }: { onStart: () => void; onNo: () => void; closeLabel: string; money: Money }) {
  return (
    <View style={{ flex: 1 }}>
      <View style={{ position: 'absolute', left: 20, top: 12 }}>
        <PwX onPress={onNo} label={closeLabel} fill="rgba(0,0,0,0.06)" ring="rgba(0,0,0,0.10)" />
      </View>
      {/* the frame sets `text-wrap: balance` and Chrome breaks after the em
          dash; Yoga has no balancing pass, so the break is written in */}
      <AppText style={[sans('500'), { position: 'absolute', left: 24, right: 60, top: 104, fontSize: 28, letterSpacing: -0.2, lineHeight: 36, color: '#1D1C1A' }]}>
        {money.trialDays === 3 ? 'Before you go —\nthree days on us.' : `Before you go —\n${money.trialDays} days on us.`}
      </AppText>

      {/* the thread runs from under the first disc to the foot of the last */}
      <View style={{ position: 'absolute', left: 45, top: 290, width: 2, height: 192, backgroundColor: 'rgba(0,0,0,0.12)' }} />
      {pwOffer(money).map(([k, t, top], i) => (
        <View key={k} style={{ position: 'absolute', left: 24, right: 24, top, flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: i === 0 ? '#131313' : '#FFFFFF',
              boxShadow: i === 0 ? undefined : '0 0 0 1px rgba(0,0,0,0.12)',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <OfferIcon k={k} c={i === 0 ? '#F4F3F0' : '#1D1C1A'} />
          </View>
          {/* `flexShrink: 1`, not `flex: 1` — the frame's span is a plain flex
              item that shrinks to the text and wraps only when it must */}
          <AppText style={[sans('500'), { flexShrink: 1, fontSize: 15, lineHeight: 21, color: '#1D1C1A' }]}>{t}</AppText>
        </View>
      ))}

      <View style={{ position: 'absolute', left: 24, right: 24, bottom: 96 }}>
        <PwCTA label={`Start my ${money.trialDays} free days`} onPress={onStart} height={58} radius={29} size={17} tracking={0.2} />
      </View>
      <PressScale onPress={onNo} accessibilityRole="button" style={{ position: 'absolute', left: 0, right: 0, bottom: 56, minHeight: 0, alignItems: 'center' }} hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}>
        <AppText style={[sans('500'), { fontSize: 13.5, color: '#8B8882' }]}>No thanks</AppText>
      </PressScale>
    </View>
  );
}

// ═════ THE PAYMENT — the Apple Pay sheet ═════════════════════════════
const PW_SYS = Platform.select({ ios: 'System', default: 'Helvetica Neue' }) as string;

function SheetRow({ label, value, chev, last }: { label: string; value: string; chev?: boolean; last?: boolean }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 11, borderBottomWidth: last ? 0 : 1, borderBottomColor: 'rgba(0,0,0,0.08)' }}>
      <AppText style={{ fontFamily: PW_SYS, width: 76, fontSize: 12.5, color: 'rgba(0,0,0,0.45)' }}>{label}</AppText>
      <AppText style={{ fontFamily: PW_SYS, flex: 1, fontSize: 13.5, color: '#111' }}>{value}</AppText>
      {chev ? (
        <Svg width={7} height={12} viewBox="0 0 8 14">
          <Path d="M1.5 1.5 6 7l-4.5 5.5" stroke="rgba(0,0,0,0.3)" strokeWidth={2} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      ) : null}
    </View>
  );
}

function PwPaySheet({ plan, email, money, onCancel, onPay }: { plan: PlanKey; email: string; money: Money; onCancel: () => void; onPay: () => void }) {
  const C = checkoutFor(plan, money);
  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9 }}>
      <Pressable onPress={onCancel} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.45)' }} />
      {/* the side button, armed */}
      <View style={{ position: 'absolute', right: -2, top: 168, width: 5, height: 76, borderRadius: 4, backgroundColor: '#2E63F6' }} />
      <View style={{ position: 'absolute', left: 5, right: 5, bottom: 5, backgroundColor: '#FCFCFE', borderRadius: 34, paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
            <Svg width={19} height={19} viewBox="0 0 24 24" fill="#111">
              <Path d="M17.05 12.5c0-2.1 1.7-3.1 1.8-3.16-1-1.45-2.5-1.65-3.05-1.67-1.3-.13-2.53.76-3.19.76-.65 0-1.67-.74-2.74-.72-1.41.02-2.71.82-3.43 2.08-1.46 2.54-.37 6.3 1.05 8.36.69 1.01 1.51 2.14 2.59 2.1 1.04-.04 1.43-.67 2.69-.67 1.25 0 1.61.67 2.71.65 1.12-.02 1.83-1.03 2.51-2.04.79-1.17 1.12-2.3 1.13-2.36-.02-.01-2.17-.83-2.19-3.29zM15.1 6.2c.57-.69.95-1.65.85-2.6-.82.03-1.81.54-2.4 1.23-.52.6-.98 1.58-.86 2.5.91.07 1.84-.46 2.41-1.13z" />
            </Svg>
            <AppText style={{ fontFamily: PW_SYS, fontSize: 21, fontWeight: '600', color: '#111', letterSpacing: -0.21 }}>Pay</AppText>
          </View>
          <PressScale onPress={onCancel} hitSlop={8} accessibilityLabel="Cancel" style={{ width: 44, minHeight: 44, borderRadius: 9999, backgroundColor: 'rgba(0,0,0,0.07)', alignItems: 'center', justifyContent: 'center' }}>
            <Svg width={11} height={11} viewBox="0 0 20 20">
              <Path d="M3 3l14 14M17 3L3 17" stroke="rgba(0,0,0,0.55)" strokeWidth={2.6} strokeLinecap="round" />
            </Svg>
          </PressScale>
        </View>
        <SheetRow label="App" value={C.app} />
        {C.trial ? <SheetRow label="Trial" value={C.trial} /> : null}
        <SheetRow label="Account" value={email} />
        <SheetRow label="Payment" value="Visa •••• 4271" chev />
        <SheetRow label="Billing" value="Apple ID" chev last />
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', borderTopWidth: 1.5, borderTopColor: 'rgba(0,0,0,0.12)', marginTop: 4, paddingTop: 12 }}>
          <AppText style={{ fontFamily: PW_SYS, fontSize: 13, color: 'rgba(0,0,0,0.45)' }}>Due today</AppText>
          <View style={{ alignItems: 'flex-end' }}>
            <AppText style={{ fontFamily: PW_SYS, fontSize: 17, fontWeight: '600', color: '#111' }}>{C.due}</AppText>
            <AppText style={{ fontFamily: PW_SYS, fontSize: 11.5, color: 'rgba(0,0,0,0.45)', marginTop: 2 }}>{C.note}</AppText>
          </View>
        </View>
        <PressScale onPress={onPay} style={{ width: '100%', minHeight: 44, marginTop: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 }}>
          <Svg width={22} height={30} viewBox="0 0 22 30" fill="none">
            <Rect x={8} y={2} width={6} height={26} rx={3} stroke="#2E63F6" strokeWidth={2} />
            <Path d="M18 9l2.5 2M18 15l2.5 2" stroke="#2E63F6" strokeWidth={2} strokeLinecap="round" />
          </Svg>
          <AppText style={{ fontFamily: PW_SYS, fontSize: 14, fontWeight: '500', color: '#2E63F6' }}>Confirm with Side Button</AppText>
        </PressScale>
      </View>
    </View>
  );
}

/**
 * The ridge `51 · Paywall Confirmed` gained in this drop: a 393 × 300 band at
 * canvas y 120, two soft ranges under a warm glow, with two hairline gold
 * circles struck through the middle of it at r 70 and r 98 — the medallion's
 * own rings, showing through the land the disc lands on.
 *
 * The band is stretched to the device rather than pinned at 393; every other
 * full-bleed band in the app does the same, and a bare strip down the right of
 * a wider phone would read worse than a percent of horizontal give.
 */
function PwConfirmedRidge({ w }: { w: number }) {
  const u = useId().replace(/:/g, '');
  const id = (k: string) => `${k}${u}`;
  const url = (k: string) => `url(#${id(k)})`;
  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: 66, height: 300, overflow: 'hidden' }} pointerEvents="none">
      <Svg width={w} height={300} viewBox="0 0 393 300" preserveAspectRatio="none" style={{ position: 'absolute', left: 0, top: 0 }}>
        <Defs>
          <RadialGradient id={id('glow')} cx="0.5" cy="0.5" r="0.5">
            <Stop offset="0" stopColor="#F2D08E" stopOpacity={0.55} />
            <Stop offset="0.5" stopColor="#F2D08E" stopOpacity={0.14} />
            <Stop offset="1" stopColor="#F2D08E" stopOpacity={0} />
          </RadialGradient>
          <SvgLinearGradient id={id('r1')} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#E4D8C2" />
            <Stop offset="1" stopColor="#EFE5D4" />
          </SvgLinearGradient>
          <SvgLinearGradient id={id('r2')} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#D9CCB4" />
            <Stop offset="1" stopColor="#E8DDC9" />
          </SvgLinearGradient>
          <SvgLinearGradient id={id('mist')} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#F4F3F0" stopOpacity={0} />
            <Stop offset="1" stopColor="#F4F3F0" />
          </SvgLinearGradient>
        </Defs>
        <Circle cx={196} cy={216} r={150} fill={url('glow')} />
        <Path d="M-10 300 L-10 232 L60 196 L120 226 L196 186 L272 226 L332 196 L403 232 L403 300 Z" fill={url('r1')} />
        <Path d="M-10 300 L-10 268 L50 246 L130 264 L196 242 L262 264 L342 246 L403 268 L403 300 Z" fill={url('r2')} />
        <Rect x={0} y={230} width={393} height={70} fill={url('mist')} />
      </Svg>
      {/* The land is stretched; the medallion's two rings are not. A ridge line
          reads the same at any width, but a circle scaled 430/393 is visibly an
          ellipse — so the rings are struck in an unstretched overlay, centred on
          the canvas's own 196 plus half the width the phone adds. At 393 that is
          196 exactly and the two <Svg>s coincide. */}
      <Svg width={w} height={300} viewBox={`0 0 ${w} 300`} style={{ position: 'absolute', left: 0, top: 0 }}>
        <G fill="none" stroke="#D9B878" strokeWidth={1} opacity={0.5}>
          <Circle cx={196 + (w - 393) / 2} cy={216} r={70} />
          <Circle cx={196 + (w - 393) / 2} cy={216} r={98} opacity={0.6} />
        </G>
      </Svg>
    </View>
  );
}

// ═════ 51 — CONFIRMED, the paper landing ═════════════════════════════
function PwConfirmed({ plan, name, email, money, confirmLabel, onDone }: { plan: PlanKey; name?: string; email: string; money: Money; confirmLabel: string; onDone: () => void }) {
  const { width } = useWindowDimensions();
  const [now] = useState(() => new Date());
  const in3 = fmtShort(new Date(now.getTime() + money.trialDays * 86400000));
  const nextYear = new Date(now);
  nextYear.setFullYear(nextYear.getFullYear() + 1);
  // 105 sets its apostrophes as plain U+0027, not the &rsquo; other frames use
  const line =
    plan === 'trial'
      ? `Let's take the first ground. Nothing is charged until ${in3} — cancelling is one tap in Settings.`
      : plan === 'month'
        ? `Let's take the first ground. The campaign is unlocked, month by month.`
        : `Let's take the first ground. The whole campaign is yours until ${nextYear.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.`;
  return (
    <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
      <Grain source={noiseDark} opacity={0.07} />
      <PwFloorGlow peak={0.44} mid={0.2} />
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <PwConfirmedRidge w={width} />
          <View style={{ position: 'absolute', left: 0, right: 0, top: 242, alignItems: 'center' }}>
            <View style={{ width: 84, height: 84, borderRadius: 42, backgroundColor: '#131313', alignItems: 'center', justifyContent: 'center', boxShadow: '0 14px 30px rgba(40,38,32,0.3)' }}>
              <Svg width={34} height={34} viewBox="0 0 24 24" fill="none">
                <Path d="M4.5 12.5l4.8 4.8L19.5 6.8" stroke="#F4F3F0" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
            </View>
          </View>
          <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, top: 360, fontSize: 28, letterSpacing: -0.2, color: '#1D1C1A' }]}>
            {name ? `We're in, ${name}.` : `We're in.`}
          </AppText>
          <AppText center style={[sans('400'), { position: 'absolute', left: 56, right: 56, top: 412, fontSize: 14.5, lineHeight: 22, color: '#55534E' }]}>
            {line}
          </AppText>
          <View style={{ position: 'absolute', left: 24, right: 24, bottom: 96 }}>
            <PwCTA label={confirmLabel} onPress={onDone} height={58} radius={29} size={17} tracking={0.2} />
          </View>
          <AppText center style={[sans('400'), { position: 'absolute', left: 0, right: 0, bottom: 60, fontSize: 12, color: '#8B8882' }]}>
            Receipt sent to {email}
          </AppText>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ═════ THE FLOW ══════════════════════════════════════════════════════
export function PaywallFlow({
  name,
  triggers = [],
  emotions = [],
  load,
  confirmLabel = 'Begin Day I',
  embedded = false,
  onDone,
}: {
  /** First name from the intake — personalizes the confirmed page. */
  name?: string;
  /** Their triggers — kept for call-site compatibility with the funnel. */
  triggers?: string[];
  /** The feeling underneath — kept for call-site compatibility. */
  emotions?: string[];
  /** Their chosen daily load — kept for call-site compatibility. */
  load?: string;
  confirmLabel?: string;
  /** Inside the onboarding shell: the ✕ skips the funnel rather than closing. */
  embedded?: boolean;
  /** Called when the funnel ends — purchased true/false. */
  onDone: (purchased: boolean) => void;
}) {
  const purchases = usePurchases();
  const { email } = useAuth();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const [plan, setPlan] = useState<PlanKey>('year');
  const [checkout, setCheckout] = useState<PlanKey | null>(null);
  const [offer, setOffer] = useState(false);
  const [sheet, setSheet] = useState(false);
  const [done, setDone] = useState(false);
  const [offered, setOffered] = useState(false);
  const closeLabel = embedded ? 'Skip' : 'Close';
  const receipt = email ?? 'your Apple ID';

  const year = purchases.planFor('yearly');
  const month = purchases.planFor('monthly');
  const money = useMemo<Money>(
    () => ({
      yearPrice: year?.priceString ?? DRAWN_MONEY.yearPrice,
      yearCycle: year?.cycle || DRAWN_MONEY.yearCycle,
      yearPerMonth: year?.pricePerMonthString ?? DRAWN_MONEY.yearPerMonth,
      // The canvas's "SAVE 74%" is $39.99 against twelve months at $12.99, so
      // it is arithmetic and not a slogan: against a real store it is worked
      // out from that store's own two prices, and withheld where the year is
      // not in fact cheaper.
      yearSaving: savingBadge(year?.pkg?.product.price, month?.pkg?.product.price) ?? DRAWN_MONEY.yearSaving,
      monthPrice: month?.priceString ?? DRAWN_MONEY.monthPrice,
      monthCycle: month?.cycle || DRAWN_MONEY.monthCycle,
      trialDays: year?.intro?.days ?? DRAWN_MONEY.trialDays,
    }),
    [year, month],
  );

  /**
   * The rescue page promises free days, so it only appears where free days
   * exist: offline, where the canvas supplies them, and against a store whose
   * yearly product carries an introductory offer. Without one, ✕ closes on the
   * first press — the same path the canvas gives a second press.
   */
  const hasTrial = purchases.mode === 'mock' || !!year?.intro?.isFree;

  // One store sheet at a time: a second press while the first is open would
  // queue a second purchase behind it.
  const busy = useRef(false);

  async function buy(which: PlanKey) {
    if (busy.current) return;
    busy.current = true;
    const outcome = await purchases.purchase(CATALOGUE[which]);
    busy.current = false;
    setSheet(false);
    if (outcome.status === 'purchased' || (outcome.status === 'restored' && outcome.entitled)) {
      setDone(true);
      return;
    }
    if (outcome.status === 'cancelled' || outcome.status === 'restored') return;
    Alert.alert('The store could not complete that', outcome.message);
  }

  /** 48's two rows and 50's pill all start here. */
  function start(which: PlanKey) {
    setCheckout(which);
    // Offline there is no store, so the drawn sheet stands in for one; with
    // RevenueCat configured the store presents its own and this never opens.
    if (purchases.mode === 'mock') {
      setSheet(true);
      return;
    }
    void buy(which);
  }

  async function restore() {
    if (busy.current) return;
    busy.current = true;
    const outcome = await purchases.restore();
    busy.current = false;
    if (outcome.status === 'restored') {
      if (outcome.entitled) {
        setCheckout(plan);
        setDone(true);
      } else {
        Alert.alert('Nothing to restore', 'This store account has no VICI Plus purchase on it.');
      }
      return;
    }
    if (outcome.status === 'cancelled' || outcome.status === 'purchased') return;
    Alert.alert('Could not restore', outcome.message);
  }

  // walking away gets one rescue: the free days, where there are any
  const decline = () => {
    if (!offered && hasTrial) {
      setOffered(true);
      setOffer(true);
      return;
    }
    onDone(false);
  };

  if (done) return <PwConfirmed plan={checkout || plan} name={name} email={receipt} money={money} confirmLabel={confirmLabel} onDone={() => onDone(true)} />;

  // the band is drawn from the physical top so it runs behind the status bar;
  // its canvas height of 290 ends 236 below the safe area, where the paper takes over
  const bandH = insets.top + 236;

  // 48 sits on a warmer paper than the rest of the app — #FAF8F3, the colour
  // its own fog gradient resolves to — while 50 and 51 keep the app's #F4F3F0.
  return (
    <View style={{ flex: 1, backgroundColor: offer ? '#F4F3F0' : '#FAF8F3' }}>
      {offer ? (
        <>
          <Grain source={noiseDark} opacity={0.07} />
          <PwFloorGlow peak={0.3} mid={0.13} />
        </>
      ) : (
        <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: bandH, overflow: 'hidden' }} pointerEvents="none">
          <PwBand w={width} h={bandH} />
        </View>
      )}
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        {offer ? (
          <PwTrialOffer closeLabel={closeLabel} money={money} onStart={() => start('trial')} onNo={() => onDone(false)} />
        ) : (
          <PwMain plan={plan} setPlan={setPlan} closeLabel={closeLabel} money={money} onPay={() => start(plan)} onClose={decline} onRestore={restore} />
        )}
      </SafeAreaView>
      {sheet ? <PwPaySheet plan={checkout || plan} email={receipt} money={money} onCancel={() => setSheet(false)} onPay={() => void buy(checkout || plan)} /> : null}
    </View>
  );
}
