import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import type { ReactNode } from 'react';
import { useId, useState } from 'react';
import { Platform, Pressable, ScrollView, View, type TextStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, Ellipse, LinearGradient as SvgLinearGradient, Path, RadialGradient, Stop } from 'react-native-svg';

import { useTabBarHeight } from '@/components/StoicTabBar';
import { AppText, EmptyState, Grain, Hill, PressScale } from '@/components/ui';
import { useCheckins, useCurrentUser, useEvents } from '@/lib/backend';
import { SCORE_BASE, SCORE_WEIGHTS } from '@/lib/score';
import { colors, sans } from '@/lib/theme';
import type { DailyCheckin, TidelineEvent } from '@/lib/types';
import { completedWeekStarts, severityWord } from '@/lib/weeklyReport';

// ── the Log tab: the log itself, in three registers (91 / 91-2 / 91-3). The
// chooser that feeds it (90) draws no tab bar, so it is a route of its own —
// `src/app/log-chooser.tsx`, outside this group (FINDINGS F17). ──

const noiseDark = require('../../../assets/images/noise-dark.png');

/** The one ink the marks are drawn in, straight off the canvas. */
const INK = '#131313';

/**
 * `AppText` sets `text-wrap: pretty` on web by default, and because CSS's
 * `white-space` is the shorthand of `white-space-collapse` + `text-wrap-mode`,
 * that quietly resets the `nowrap` React Native Web writes for `numberOfLines` —
 * so a long row title clamps correctly on device and wraps to two lines in the
 * browser (FINDINGS F8). Naming `nowrap` back puts the two on the same row.
 */
export const ONE_LINE = Platform.OS === 'web' ? ({ textWrap: 'nowrap' } as unknown as TextStyle) : null;

/**
 * A CSS `linear-gradient(150deg, …)` written as Yoga fractions. The axis runs
 * through the box centre along (sin150, −cos150) = (0.5, 0.866) and its ends sit
 * where the corners project onto a line `|w·sin a| + |h·cos a|` long — so both
 * ends fall outside the box, which is what the out-of-range fractions below say.
 * Every warm card in this file is cut from that one ramp at a different size.
 */
const COS30 = Math.cos(Math.PI / 6);
export function ramp150(w: number, h: number) {
  const half = (w * 0.5 + h * COS30) / 2;
  return {
    start: { x: 0.5 - (half * 0.5) / w, y: 0.5 - (half * COS30) / h },
    end: { x: 0.5 + (half * 0.5) / w, y: 0.5 + (half * COS30) / h },
  };
}

/**
 * The warm halo the canvas paints behind every sun:
 * `radial-gradient(closest-side, C α, C 0 s%)` on a square box. Closest-side on a
 * square is r = 50%, which is the one radius `react-native-svg` can actually put
 * on the web (F8) — so this transfers literally.
 */
export function Halo({ size, color, alpha, stop, style }: { size: number; color: string; alpha: number; stop: number; style: object }) {
  const id = useId().replace(/:/g, '');
  return (
    <Svg width={size} height={size} style={[{ position: 'absolute' }, style]}>
      <Defs>
        <RadialGradient id={`halo${id}`} cx="50%" cy="50%" rx="50%" ry="50%">
          <Stop offset="0" stopColor={color} stopOpacity={alpha} />
          <Stop offset={stop} stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Ellipse cx={size / 2} cy={size / 2} rx={size / 2} ry={size / 2} fill={`url(#halo${id})`} />
    </Svg>
  );
}

/** The sun itself: a 180° ramp under a ring of its own light. */
export function SunDisc({ size, ring, style }: { size: number; ring: number; style: object }) {
  return (
    <View style={[{ position: 'absolute', width: size, height: size, borderRadius: size / 2, boxShadow: `0 0 0 ${ring}px rgba(226,186,120,0.16)` }, style]}>
      <LinearGradient
        colors={['#E9C687', '#D9A95C']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={{ width: size, height: size, borderRadius: size / 2 }}
      />
    </View>
  );
}


/**
 * 91 / 91-2 / 91-3 · The log, in three registers.
 *
 * Urges, check-ins and the weekly reports each read differently — an urge is an
 * incident, a check-in is a reading, a report is a verdict — so they get their
 * own lists rather than one merged stream where the shape of a week is
 * impossible to see. Each register opens on a card that says what the week came
 * to, and every entry under it is the same 64pt white slip: a mark on the inset
 * disc, what it was, when, and how it went.
 */

const LOG_TABS = [
  { key: 'urges' as const, label: 'Urges' },
  { key: 'checkins' as const, label: 'Check-ins' },
  { key: 'reports' as const, label: 'Reports' },
];
type LogTab = (typeof LOG_TABS)[number]['key'];

const DAY = 86_400_000;
const WEEK = 7 * DAY;

/** Canvas row geometry: 64 tall on a 74pt pitch, `left:16 right:16`. */
const ROW_H = 64;
const ROW_GAP = 10;

/** The switch: a sunken track carrying one raised paper pill. */
function LogTabs({ value, onChange }: { value: LogTab; onChange: (key: LogTab) => void }) {
  return (
    <View
      style={{
        position: 'absolute',
        left: 16,
        right: 16,
        top: 114,
        height: 38,
        borderRadius: 19,
        backgroundColor: 'rgba(0,0,0,0.06)',
        flexDirection: 'row',
        padding: 3,
      }}>
      {LOG_TABS.map((t) => {
        const on = value === t.key;
        return (
          <Pressable
            key={t.key}
            onPress={() => onChange(t.key)}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
            style={{
              flex: 1,
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: on ? 16 : undefined,
              backgroundColor: on ? '#FFFFFF' : 'transparent',
              boxShadow: on ? '0 1px 4px rgba(40,38,32,0.14), 0 0 0 0.5px rgba(0,0,0,0.04)' : undefined,
            }}>
            <AppText style={[sans(on ? '600' : '500'), { fontSize: 14, color: on ? '#1D1C1A' : '#8B8882' }]}>{t.label}</AppText>
          </Pressable>
        );
      })}
    </View>
  );
}

type LogRowData = { key: string; mark: ReactNode; title: string; when: string; outcome?: string; onPress?: () => void };

/** The list disclosure, drawn small: 6 × 10 out of the 8 × 14 chevron. */
export function RowChevron() {
  return (
    <Svg width={6} height={10} viewBox="0 0 8 14">
      <Path d="M1.5 1.5L6.5 7l-5 5.5" fill="none" stroke="#B0AEA8" strokeWidth={2} strokeLinecap="round" />
    </Svg>
  );
}

/**
 * One entry — a white slip rather than a ruled row. The canvas asks for `padding:
 * 0 14px 0 12px` on a border-box card, so the disc sits 12 in and the chevron 14.
 * `Weekly Report — Urges` draws the same slip, which is why it is exported.
 */
export function LogRow({ mark, title, when, outcome, onPress, gap = 0 }: Omit<LogRowData, 'key'> & { gap?: number }) {
  return (
    <PressScale
      onPress={onPress}
      disabled={!onPress}
      accessibilityRole={onPress ? 'button' : undefined}
      style={{
        marginTop: gap,
        height: ROW_H,
        borderRadius: 16,
        backgroundColor: '#FFFFFF',
        boxShadow: '0 0 0 1px rgba(0,0,0,0.05)',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingLeft: 12,
        paddingRight: 14,
      }}>
      <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: '#F1EFE9', alignItems: 'center', justifyContent: 'center' }}>{mark}</View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <AppText numberOfLines={1} style={[sans('500'), { fontSize: 14, color: '#1D1C1A' }, ONE_LINE]}>
          {title}
        </AppText>
        <AppText numberOfLines={1} style={[sans('400'), { marginTop: 2, fontSize: 12, color: '#8B8882' }, ONE_LINE]}>
          {when}
        </AppText>
      </View>
      {outcome ? <AppText style={[sans('400'), { flexShrink: 0, fontSize: 12.5, color: '#8B8882' }]}>{outcome}</AppText> : null}
      <RowChevron />
    </PressScale>
  );
}

/**
 * A run of slips under one caption. The canvas drops the caption on the newest
 * run — the summary card above it already says which week that is — and only
 * names the ones behind it (`Last week`, `Earlier weeks`).
 */
function LogGroup({ label, rows, gapBefore }: { label?: string; rows: LogRowData[]; gapBefore: number }) {
  return (
    <View style={{ marginTop: gapBefore, paddingHorizontal: 16 }}>
      {/* the caption box is exactly the canvas's caption-top to first-row-top */}
      {label ? (
        <View style={{ height: 24, paddingLeft: 8 }}>
          <AppText style={[sans('600'), { alignSelf: 'flex-start', fontSize: 12.5, color: '#8B8882' }]}>{label}</AppText>
        </View>
      ) : null}
      {rows.map(({ key, ...row }, i) => (
        <LogRow key={key} {...row} gap={i === 0 ? 0 : ROW_GAP} />
      ))}
    </View>
  );
}

/** Empty states sit on the list's own gutter, since the screen is full-bleed. */
function LogEmpty({ title, body }: { title: string; body: string }) {
  return (
    <View style={{ paddingHorizontal: 16 }}>
      <EmptyState title={title} body={body} />
    </View>
  );
}

/* ------------------------------------------------------- the register's card */

const SUMMARY_W = 361;
const SUMMARY_H = 128;
const SUMMARY_RAMP = ramp150(SUMMARY_W, SUMMARY_H);

/**
 * The card each register opens on: 361 × 128, `left:16 right:16 top:222`. Urges
 * and check-ins get a sun over a lit hill in their own two tones; reports get the
 * night card with the score's own line drawn across it.
 */
function SummaryCard({ tone, title, note, children }: { tone: 'urge' | 'checkin' | 'report'; title: string; note: string; children?: ReactNode }) {
  const dark = tone === 'report';
  return (
    <View
      style={{
        marginTop: 16,
        marginHorizontal: 16,
        height: SUMMARY_H,
        borderRadius: 20,
        overflow: 'hidden',
        boxShadow: dark ? '0 10px 24px rgba(19,19,17,0.22)' : 'inset 0 0 0 1px rgba(0,0,0,0.05)',
      }}>
      <LinearGradient
        colors={dark ? ['#33322D', '#131311'] : tone === 'urge' ? ['#EDE6D8', '#D5CAB4'] : ['#E9E8E3', '#C9C8C1']}
        start={SUMMARY_RAMP.start}
        end={SUMMARY_RAMP.end}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />
      {dark ? (
        <Hill height={SUMMARY_H - 88} rise={28} color="rgba(244,243,240,0.10)" style={{ position: 'absolute', left: -24, right: -24, top: 88 }} />
      ) : (
        <Hill
          height={SUMMARY_H - 78}
          rise={30}
          color={tone === 'urge' ? 'rgba(255,255,255,0.34)' : 'rgba(255,255,255,0.38)'}
          style={{ position: 'absolute', left: -24, right: -24, top: 78 }}
        />
      )}
      {tone === 'urge' ? (
        <>
          <Halo size={62} color="#E2BA78" alpha={0.42} stop={0.72} style={{ right: 22, top: 10 }} />
          <SunDisc size={26} ring={5} style={{ right: 40, top: 26 }} />
        </>
      ) : null}
      {tone === 'checkin' ? (
        <>
          <Halo size={90} color="#E2BA78" alpha={0.45} stop={0.72} style={{ right: 14, top: 2 }} />
          <SunDisc size={38} ring={6} style={{ right: 40, top: 30 }} />
        </>
      ) : null}
      {children}
      <AppText style={[sans('500'), { position: 'absolute', left: 18, top: 22, fontSize: 22, letterSpacing: -0.2, color: dark ? '#F4F3F0' : '#1D1C1A' }]}>
        {title}
      </AppText>
      <AppText style={[sans('400'), { position: 'absolute', left: 18, bottom: 16, fontSize: 13, color: dark ? 'rgba(244,243,240,0.6)' : '#55534E' }]}>
        {note}
      </AppText>
    </View>
  );
}

/**
 * 91-3's sparkline: the score at the close of each reported week, drawn into the
 * canvas's own 130 × 70 box between x 4…124 and y 60…6, with the newest week
 * ringed. One week alone has no line to draw, so it rides flat at the top.
 */
function ReportSpark({ values }: { values: number[] }) {
  const id = useId().replace(/:/g, '');
  const lo = Math.min(...values);
  const hi = Math.max(...values);
  const span = hi - lo || 1;
  const pts = values.map((v, i) => ({
    x: values.length === 1 ? 124 : 4 + (i * 120) / (values.length - 1),
    y: 60 - ((v - lo) / span) * 54,
  }));
  const line = smoothPath(pts);
  const last = pts[pts.length - 1];
  return (
    <Svg width={130} height={70} viewBox="0 0 130 70" style={{ position: 'absolute', right: 16, top: 24 }}>
      <Defs>
        <SvgLinearGradient id={`spark${id}`} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#E9C687" stopOpacity={0.35} />
          <Stop offset="1" stopColor="#E9C687" stopOpacity={0} />
        </SvgLinearGradient>
      </Defs>
      <Path d={`${line} L${last.x},70 L${pts[0].x},70 Z`} fill={`url(#spark${id})`} />
      <Path d={line} fill="none" stroke="#E9C687" strokeWidth={2.4} strokeLinecap="round" />
      <Circle cx={last.x} cy={last.y} r={5} fill="#131311" stroke="#E9C687" strokeWidth={2} />
    </Svg>
  );
}

/** Catmull-Rom tangents, the same curve the weekly report's line is drawn with. */
function smoothPath(pts: { x: number; y: number }[]): string {
  const r = (n: number) => Math.round(n * 10) / 10;
  if (pts.length === 1) return `M4,${r(pts[0].y)} L${r(pts[0].x)},${r(pts[0].y)}`;
  let d = `M${r(pts[0].x)},${r(pts[0].y)}`;
  for (let i = 0; i < pts.length - 1; i += 1) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    d += ` C${r(p1.x + (p2.x - p0.x) / 6)},${r(p1.y + (p2.y - p0.y) / 6)} ${r(p2.x - (p3.x - p1.x) / 6)},${r(p2.y - (p3.y - p1.y) / 6)} ${r(p2.x)},${r(p2.y)}`;
  }
  return d;
}

export default function Log() {
  const router = useRouter();
  const events = useEvents();
  const checkins = useCheckins();
  // The tab bar floats over this screen, so the list has to be able to scroll
  // its last row clear of it rather than ending underneath.
  const tabBar = useTabBarHeight();
  const [tab, setTab] = useState<LogTab>('urges');
  // The clock is read once on mount: re-reading it every render would let the
  // week boundary shift underneath the list while it is on screen.
  const [now] = useState(() => Date.now());

  const urges = (events ?? []).filter((e) => e.type.startsWith('urge') || e.type === 'lapse').sort((a, b) => b.createdAt - a.createdAt);
  const reads = [...(checkins ?? [])].sort((a, b) => (a.date < b.date ? 1 : -1));
  // A check-in carries no clock of its own, so the `check_in` event logged the
  // same day supplies the time the canvas draws beside it.
  const checkinTimes = new Map<string, number>();
  for (const e of events ?? []) if (e.type === 'check_in') checkinTimes.set(dateKey(e.createdAt), e.createdAt);

  // The canvas's row title is always two parts — `Late night · Intense`. The
  // trigger field is a multi-select stored as one ' · ' joined string, so a
  // session tagged twice would make it three in a 64pt row with a fixed outcome
  // column. Only the first is named here, which is the reading `weekly-report`'s
  // own `UrgeRow` already takes; the whole set is still read out where the
  // canvas draws it, on the overview's `Common triggers` bars (D128).
  const urgeRow = (event: TidelineEvent): LogRowData => {
    const trigger = event.trigger?.split(' · ')[0];
    return {
      key: event._id,
      mark: <TriggerGlyph trigger={trigger} />,
      title: [trigger || 'Urge', event.severity != null ? severityWord(event.severity) : null].filter(Boolean).join(' · '),
      when: whenLabel(event.createdAt, now),
      outcome: outcomeWord(event),
    };
  };

  const readRow = (checkin: DailyCheckin): LogRowData => {
    const at = checkinTimes.get(checkin.date);
    const day = dayWord(dateKeyToMs(checkin.date), now);
    return {
      key: checkin.date,
      mark: <View style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: (checkin.mood ?? 0) >= 4 ? INK : '#B0AEA8' }} />,
      title: [
        checkin.mood != null ? `Mood ${checkin.mood}/5` : 'Check-in',
        checkin.sleepHours != null ? `${checkin.sleepHours}h sleep` : null,
      ]
        .filter(Boolean)
        .join(' · '),
      when: at != null ? `${day} · ${clock(at)}` : day,
      outcome: readingWord(checkin),
    };
  };

  const weekAgo = now - WEEK;
  const weekUrges = urges.filter((e) => e.createdAt >= weekAgo && e.type.startsWith('urge'));
  const weekRode = weekUrges.filter((e) => e.type === 'urge_rode_out').length;
  const weekReads = reads.filter((c) => dateKeyToMs(c.date) >= weekAgo).length;

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Grain source={noiseDark} opacity={0.07} />
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <ScrollView
          contentInsetAdjustmentBehavior="never"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: tabBar }}>
          {/* The chevron, the title and the switch are hand-placed at 10 / 60 /
              114 under the status bar, so the card below starts at exactly 168
              whatever the type metrics do. */}
          <View style={{ height: 152 }}>
            <PressScale
              onPress={() => router.navigate('/log-chooser')}
              accessibilityRole="button"
              accessibilityLabel="Back"
              hitSlop={{ top: 16, bottom: 16, left: 16, right: 24 }}
              style={{ position: 'absolute', left: 16, top: 10, minHeight: 0, flexDirection: 'row', alignItems: 'center', gap: 9 }}>
              <Svg width={11} height={19} viewBox="0 0 11 19">
                <Path d="M9.5 1.5L2 9.5l7.5 8" fill="none" stroke="#55534E" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
              <AppText style={[sans('400'), { fontSize: 17, color: '#55534E' }]}>Back</AppText>
            </PressScale>
            <AppText style={[sans('600'), { position: 'absolute', left: 16, top: 60, fontSize: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>
              Your log
            </AppText>
            <LogTabs value={tab} onChange={setTab} />
          </View>

          {tab === 'urges' ? (
            urges.length ? (
              <>
                <SummaryCard
                  tone="urge"
                  title={`${weekUrges.length} ${weekUrges.length === 1 ? 'urge' : 'urges'}`}
                  note={
                    weekUrges.length === 0
                      ? 'None this week'
                      : weekRode === weekUrges.length
                        ? 'All ridden out'
                        : `${weekRode} of ${weekUrges.length} ridden out`
                  }
                />
                <Grouped items={urges} now={now} at={(e) => e.createdAt} row={urgeRow} />
              </>
            ) : (
              <LogEmpty title="No urges logged yet" body="When a wave hits, logging it is what turns it into data." />
            )
          ) : null}

          {tab === 'checkins' ? (
            reads.length ? (
              <>
                <SummaryCard
                  tone="checkin"
                  title={`${weekReads} ${weekReads === 1 ? 'check-in' : 'check-ins'}`}
                  note={streakNote(reads, now)}
                />
                <Grouped items={reads} now={now} at={(c) => dateKeyToMs(c.date)} row={readRow} />
              </>
            ) : (
              <LogEmpty title="No check-ins yet" body="Twenty seconds in the morning starts one." />
            )
          ) : null}

          {tab === 'reports' ? <Reports now={now} onOpen={(week) => router.push(`/weekly-report?week=${week}`)} /> : null}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

/**
 * This week / Last week / Earlier. The canvas leaves the newest run uncaptioned —
 * the card above it has just named the week — and captions every run behind it.
 */
function Grouped<T>({ items, now, at, row }: { items: T[]; now: number; at: (item: T) => number; row: (item: T) => LogRowData }) {
  // The clock is frozen at mount, so anything logged while the list is open
  // reads as negative age — it belongs at the top, not nowhere.
  const bucket = (from: number, to: number) =>
    items
      .filter((item) => {
        const age = now - at(item);
        return age >= from && age < to;
      })
      .map(row);
  const groups: { label?: string; rows: LogRowData[] }[] = [
    { rows: bucket(Number.NEGATIVE_INFINITY, WEEK) },
    { label: 'Last week', rows: bucket(WEEK, 2 * WEEK) },
    { label: 'Earlier', rows: bucket(2 * WEEK, Number.POSITIVE_INFINITY) },
  ];
  const shown = groups.filter((g) => g.rows.length);
  return (
    <>
      {shown.map((g, i) => (
        <LogGroup key={g.label ?? 'this-week'} label={g.label} rows={g.rows} gapBefore={i === 0 ? 16 : 20} />
      ))}
    </>
  );
}

/** The four marks the canvas draws for a logged urge; the rest get the ring. */
export function TriggerGlyph({ trigger }: { trigger?: string }) {
  const name = (trigger ?? '').toLowerCase();
  if (name.includes('night')) {
    return (
      <Svg width={17} height={17} viewBox="0 0 30 30">
        <Path d="M17 3 A11 11 0 1 0 25.5 20 A8.6 8.6 0 1 1 17 3 Z" fill={INK} />
      </Svg>
    );
  }
  if (name.includes('stress') || name.includes('argument')) {
    return (
      <Svg width={15} height={12} viewBox="0 0 14 11">
        <Path d="M1 9.5L5 5l3 3 5-6.5" fill="none" stroke={INK} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
    );
  }
  if (name.includes('home') || name.includes('alone')) {
    return (
      <Svg width={17} height={17} viewBox="0 0 24 24">
        <Path d="M4 11l8-7 8 7" fill="none" stroke={INK} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M6 10v10h12V10" fill="none" stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
      </Svg>
    );
  }
  return <View style={{ width: 13, height: 13, borderRadius: 6.5, boxShadow: 'inset 0 0 0 3.5px #131313' }} />;
}

/** How it went, in the log's lowercase voice — the outcome the flow recorded. */
export const OUTCOME_WORD: Record<string, string> = {
  'Rode it out': 'rode it out',
  'Surfed with the timer': 'surfed the timer',
  'Distracted myself': 'distracted myself',
  'Reached out': 'reached out',
};

function outcomeWord(event: TidelineEvent): string {
  if (event.type === 'lapse') return 'slipped';
  if (event.whatHelped) return OUTCOME_WORD[event.whatHelped] ?? event.whatHelped.toLowerCase();
  return event.type === 'urge_rode_out' ? 'rode it out' : 'acted on it';
}

/**
 * How a morning read. 91-2 draws five words — `steady`, `flat`, `good`,
 * `rested`, `rough` — against five readings, and the same mood 4 takes three of
 * them, so the word is not mood alone: it is mood first, then the night's sleep
 * (4/7h steady, 4/7.5h good, 4/8h rested). That is the reading those five
 * samples support; the mood-only vocabulary lives on the check-in flow itself.
 */
function readingWord(checkin: DailyCheckin): string | undefined {
  const mood = checkin.mood;
  if (mood == null) return undefined;
  if (mood <= 2) return 'rough';
  if (mood === 3) return 'flat';
  const slept = checkin.sleepHours ?? 0;
  if (slept >= 8) return 'rested';
  if (slept >= 7.5) return 'good';
  return 'steady';
}

/** "12 mornings in a row" — consecutive days back from the newest check-in. */
function streakNote(reads: DailyCheckin[], now: number): string {
  const days = new Set(reads.map((c) => c.date));
  let run = 0;
  const midnight = new Date(now).setHours(0, 0, 0, 0);
  // A morning that has not been logged yet must not break yesterday's run, so
  // the count starts at today and steps back only while a day is present.
  let cursor = days.has(dateKey(midnight)) ? midnight : midnight - DAY;
  while (days.has(dateKey(cursor))) {
    run += 1;
    cursor -= DAY;
  }
  return run ? `${run} ${run === 1 ? 'morning' : 'mornings'} in a row` : 'The run starts tomorrow';
}

function dateKey(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function dateKeyToMs(date: string): number {
  return new Date(`${date}T00:00:00`).getTime();
}

/** "Today", "Yesterday", the weekday for a fortnight, then the date. */
function dayWord(ms: number, now: number): string {
  const midnight = new Date(now).setHours(0, 0, 0, 0);
  const days = Math.round((midnight - new Date(ms).setHours(0, 0, 0, 0)) / DAY);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 14) return new Date(ms).toLocaleDateString('en-US', { weekday: 'long' });
  return new Date(ms).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

/** "11:40 pm" — the canvas writes the meridiem lowercase in the log. */
function clock(ms: number): string {
  return new Date(ms).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }).toLowerCase();
}

/** "Tuesday · 11:40 pm". */
function whenLabel(ms: number, now: number): string {
  return `${dayWord(ms, now)} · ${clock(ms)}`;
}

/** 91-3 · The weekly reports, newest first — the latest one on the night card. */
function Reports({ onOpen, now }: { onOpen: (week: string) => void; now: number }) {
  const user = useCurrentUser();
  const checkins = useCheckins();
  const events = useEvents();
  if (!user || checkins === undefined || events === undefined) return null;

  const weeks = reportWeeks(user.createdAt, checkins, events, now);
  if (!weeks.length) {
    return <LogEmpty title="No reports yet" body="The first one arrives once a full week has closed." />;
  }

  const [latest, ...earlier] = weeks;
  return (
    <>
      <SummaryCard
        tone="report"
        title={latest.label}
        note={`${latest.score.toLocaleString('en-US')} · ${signed(latest.delta)} this week`}>
        {/* oldest first, so the line reads left to right the way the weeks ran */}
        <ReportSpark values={[...weeks].reverse().map((w) => w.score)} />
      </SummaryCard>
      {earlier.length ? (
        <LogGroup
          label="Earlier weeks"
          gapBefore={12}
          rows={earlier.map((week) => ({
            key: week.key,
            mark: <TrendGlyph up={week.delta >= 0} />,
            title: week.label,
            when: `Score ${week.score.toLocaleString('en-US')} · ${week.urges} ${week.urges === 1 ? 'urge' : 'urges'} · ${week.relapses} ${week.relapses === 1 ? 'relapse' : 'relapses'}`,
            outcome: signed(week.delta),
            onPress: () => onOpen(week.key),
          }))}
        />
      ) : null}
    </>
  );
}

/** The canvas writes a rise with a plus and a fall with a true minus sign. */
function signed(delta: number): string {
  return delta >= 0 ? `+${delta}` : `−${Math.abs(delta)}`;
}

/** 91-3's row mark: the week's own direction, drawn as a four-point line. */
function TrendGlyph({ up }: { up: boolean }) {
  return (
    <Svg width={18} height={12} viewBox="0 0 18 12">
      <Path
        d={up ? 'M1 10 L6 7 L10 8 L17 2' : 'M1 3 L6 6 L10 5 L17 10'}
        fill="none"
        stroke={INK}
        strokeWidth={2.2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  );
}

type ReportWeek = { key: string; label: string; score: number; urges: number; relapses: number; delta: number };

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "Jul 14–20", and "Jun 30–Jul 6" when the week straddles a month. */
function weekLabel(startMs: number): string {
  const start = new Date(startMs);
  const end = new Date(startMs + 6 * DAY);
  const head = `${MONTHS[start.getMonth()]} ${start.getDate()}`;
  const tail = start.getMonth() === end.getMonth() ? `${end.getDate()}` : `${MONTHS[end.getMonth()]} ${end.getDate()}`;
  return `${head}–${tail}`;
}

/**
 * Every closed week, newest first, carrying the score as it stood when that
 * week ended. The weights are the score's own, so the ± beside a week is
 * literally what that week moved the number by. Lessons are left out of the
 * weekly figure — completion is timestamped, but a lesson finished late still
 * belongs to the week it was assigned, and guessing that would make the deltas
 * lie about which week earned what.
 */
function reportWeeks(createdAt: number, checkins: DailyCheckin[], events: TidelineEvent[], now: number): ReportWeek[] {
  const oldestFirst = [...completedWeekStarts(createdAt, now)].reverse();
  let running = SCORE_BASE;
  const out: ReportWeek[] = [];
  for (const key of oldestFirst) {
    const start = dateKeyToMs(key);
    const end = start + WEEK;
    const inWeek = events.filter((e) => e.createdAt >= start && e.createdAt < end);
    const urges = inWeek.filter((e) => e.type.startsWith('urge')).length;
    const ridden = inWeek.filter((e) => e.type === 'urge_rode_out').length;
    const relapses = inWeek.filter((e) => e.type === 'lapse').length;
    const reads = checkins.filter((c) => dateKeyToMs(c.date) >= start && dateKeyToMs(c.date) < end).length;
    const delta =
      Math.max(0, 7 - relapses) * SCORE_WEIGHTS.cleanDay +
      reads * SCORE_WEIGHTS.checkin +
      ridden * SCORE_WEIGHTS.urgeRidden +
      relapses * SCORE_WEIGHTS.slip;
    running += delta;
    out.push({ key, label: weekLabel(start), score: running, urges, relapses, delta });
  }
  return out.reverse();
}
