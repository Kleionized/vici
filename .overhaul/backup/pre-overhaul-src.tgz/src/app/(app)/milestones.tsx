import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useRef, useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';

import { KKMedallion, KK_ALBUM, kkMetal, kkRoman, kkRung, kkStanding, kkSun, type KKFace, type KeepsakeSceneKey } from '@/components/keepsakes/Medallion';
import { AppText, Grain, LoadingView, PressScale } from '@/components/ui';
import { useCheckins, useCurrentLesson, useCurrentUser, useEvents, useJournalEntries, useLessonProgressMap } from '@/lib/backend';
import { sans } from '@/lib/theme';

/**
 * 088–088C · Medallions.
 *
 * One screen, two segments: the faces that have been struck, and the ones still
 * ahead. Every face is the same 68pt paper disc — the album's own stock — and
 * the only difference between the two segments is the low sun behind an earned
 * device. Tapping a face opens its detail (089), and the pill there opens the
 * ladder (088I–088Q).
 *
 * The counts are live: days with something recorded, urges outlasted, check-ins
 * kept, lessons finished. The canvas's "10 of 12 earned" is its own mock, so
 * the rule is carried and the number is not — but the twelve is real, and the
 * rail is the earned fraction on both segments.
 *
 * Canvas y − 54 throughout (the frame's status bar is the safe-area top inset).
 */

const noiseDark = require('../../../assets/images/noise-dark.png');

type Segment = 'earned' | 'ahead';

/** What a face knows about itself once the log has been counted. */
type Struck = {
  face: KKFace;
  count: number;
  earned: boolean;
  /** How many rungs are behind it — 1 for a one-time face that has minted. */
  standing: number;
  /** The stamped date a one-time face carries instead of a tier. */
  date?: string;
};

const shortDate = (ms: number) => new Date(ms).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

/** `YYYY-MM-DD` as local midnight — `new Date(iso)` reads it as UTC and slips a day west of Greenwich. */
const dayStart = (iso: string) => {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1).getTime();
};

/** A timestamp as its own local calendar day, so two records on one evening count once. */
const dayKey = (ms: number) => {
  const d = new Date(ms);
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
};

const DAY = 86400000;

export default function Milestones() {
  const router = useRouter();
  const events = useEvents();
  const checkins = useCheckins();
  const user = useCurrentUser();
  const journal = useJournalEntries();
  const progress = useLessonProgressMap();
  const current = useCurrentLesson();
  const [segment, setSegment] = useState<Segment>('earned');
  const grid = useRef<ScrollView>(null);
  // The two segments are different lengths; a carried-over offset would open
  // the shorter one mid-grid, with its first row already under the count line.
  const show = (next: Segment) => {
    setSegment(next);
    grid.current?.scrollTo({ y: 0, animated: false });
  };

  if (events === undefined || checkins === undefined || user === undefined || journal === undefined || progress === undefined || current === undefined) {
    return (
      <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
        <SafeAreaView style={{ flex: 1 }} edges={['top']}>
          <LoadingView />
        </SafeAreaView>
      </View>
    );
  }

  const rode = events.filter((e) => e.type === 'urge_rode_out');
  const actedOn = events.filter((e) => e.type === 'urge_acted_on');
  const storms = rode.filter((e) => (e.severity ?? 0) >= 9);
  const lapses = events.filter((e) => e.type === 'lapse');
  const lessonsDone = Object.values(progress).filter((p) => p?.status === 'completed').length;

  // Vidi counts days the app was opened and something was written down — not
  // days since sign-up — so every kind of record folds into one set of dates.
  const recorded = new Set<number>();
  for (const c of checkins) recorded.add(dayKey(dayStart(c.date)));
  for (const e of events) recorded.add(dayKey(e.createdAt));
  for (const j of journal) recorded.add(dayKey(j.createdAt));

  // Rebound is the morning after: a check-in on the day following a slip.
  const checkinDays = new Set(checkins.map((c) => dayKey(dayStart(c.date))));
  const rebounds = new Set<number>();
  for (const l of lapses) {
    const next = dayKey(l.createdAt + DAY);
    if (checkinDays.has(next)) rebounds.add(next);
  }

  // Return is a check-in that lands after a week of silence — the gap is
  // measured against the previous check-in, so the first one can never earn it.
  const checkinStamps = checkins.map((c) => dayStart(c.date)).sort((a, b) => a - b);
  const returned = checkinStamps.find((ms, i) => i > 0 && ms - checkinStamps[i - 1] >= 7 * DAY);

  const firstCheckin = checkinStamps.length ? checkinStamps[0] : null;
  const firstSlipLogged = actedOn.length ? Math.min(...actedOn.map((e) => e.createdAt)) : null;

  // What each face counts, and — for the four that mint once — whether it has.
  const COUNT: Record<KeepsakeSceneKey, number> = {
    veni: user?.onboardingComplete ? 1 : 0,
    firstlight: checkins.length ? 1 : 0,
    vidi: recorded.size,
    vici: rode.length,
    breakwater: storms.length,
    rebound: rebounds.size,
    logbook: rode.length + actedOn.length,
    pulse: checkins.length,
    blackbox: firstSlipLogged != null ? 1 : 0,
    lessons: lessonsDone,
    archive: journal.length,
    return: returned != null ? 1 : 0,
  };

  const DATE: Partial<Record<KeepsakeSceneKey, string>> = {
    veni: user ? `Day 0 · ${shortDate(user.createdAt)}` : 'Day 0',
    firstlight: firstCheckin != null ? shortDate(firstCheckin) : undefined,
    blackbox: firstSlipLogged != null ? shortDate(firstSlipLogged) : undefined,
    return: returned != null ? shortDate(returned) : undefined,
  };

  const struck: Struck[] = KK_ALBUM.map((face) => {
    const count = COUNT[face.key];
    const standing = kkStanding(face, count);
    return { face, count, earned: standing > 0, standing, date: face.steps.length ? undefined : DATE[face.key] };
  });

  const shown = struck.filter((s) => (segment === 'earned' ? s.earned : !s.earned));
  const rows: Struck[][] = [];
  for (let i = 0; i < shown.length; i += 2) rows.push(shown.slice(i, i + 2));
  const nEarned = struck.filter((s) => s.earned).length;

  const back = () => (router.canGoBack() ? router.back() : router.navigate('/(app)/today'));

  return (
    <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
      <StatusBar style="dark" />
      <Grain source={noiseDark} opacity={0.07} />

      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        {/* Yoga measures an absolute child's inset from the parent's border box
            and never consults padding, which is how safe-area-context expresses
            the inset — so everything absolute hangs off this plain view. */}
        <View style={{ flex: 1 }}>
          {/* the header, anchored on the canvas; the grid below it scrolls */}
          <View style={{ height: 236 }}>
            {/* canvas y 64 */}
            <PressScale
              onPress={back}
              accessibilityRole="button"
              accessibilityLabel="Back"
              hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}
              style={{ position: 'absolute', left: 16, top: 10, minHeight: 0 }}>
              <Svg width={11} height={19} viewBox="0 0 11 19" fill="none">
                <Path d="M9.5 1.5L2 9.5l7.5 8" fill="none" stroke="#55534E" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
            </PressScale>

            {/* canvas y 72 — the album's page marks, carried through as chrome */}
            <View pointerEvents="none" style={{ position: 'absolute', right: 20, top: 18, flexDirection: 'row', gap: 4.5 }}>
              {[0, 1, 2].map((i) => (
                <View key={i} style={{ width: 4.5, height: 4.5, borderRadius: 2.25, backgroundColor: '#55534E' }} />
              ))}
            </View>

            {/* canvas y 114 */}
            <AppText style={[sans('600'), { position: 'absolute', left: 16, top: 60, fontSize: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>Medallions</AppText>

            {/* canvas y 168 */}
            <View
              style={{
                position: 'absolute',
                left: 16,
                right: 16,
                top: 114,
                height: 38,
                borderRadius: 19,
                backgroundColor: 'rgba(0,0,0,0.06)',
                flexDirection: 'row',
                padding: 3,
              }}>
              {([['earned', 'Earned'], ['ahead', 'Still to earn']] as const).map(([key, label]) => {
                const on = segment === key;
                return (
                  <PressScale
                    key={key}
                    onPress={() => show(key)}
                    accessibilityRole="tab"
                    accessibilityState={{ selected: on }}
                    style={{
                      flex: 1,
                      minHeight: 0,
                      // only the selected half is a pill; the other is bare track
                      borderRadius: on ? 16 : 0,
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: on ? '#FFFFFF' : 'transparent',
                      boxShadow: on ? '0 1px 4px rgba(40,38,32,0.14), 0 0 0 0.5px rgba(0,0,0,0.04)' : undefined,
                    }}>
                    <AppText style={[sans(on ? '600' : '500'), { fontSize: 14, color: on ? '#1D1C1A' : '#8B8882' }]}>{label}</AppText>
                  </PressScale>
                );
              })}
            </View>

            {/* canvas y 230 */}
            <AppText style={[sans('600'), { position: 'absolute', left: 16, top: 176, fontSize: 13, color: '#55534E' }]}>
              {segment === 'earned' ? `${nEarned} of ${struck.length} earned` : `${struck.length - nEarned} still to earn`}
            </AppText>

            {/* canvas y 256 — the rail reads the earned fraction on both segments */}
            <View style={{ position: 'absolute', left: 16, right: 16, top: 202, height: 5, borderRadius: 3, backgroundColor: 'rgba(0,0,0,0.12)', overflow: 'hidden' }}>
              {/* the canvas states the fill as a whole percent — 10 of 12 is `83%`, not 83.33% */}
              <View style={{ width: `${Math.round((nEarned / struck.length) * 100)}%`, height: '100%', borderRadius: 3, backgroundColor: '#131313' }} />
            </View>
          </View>

          {/* canvas y 290 — rows of two, on a 185 stride.
              The bottom padding is the canvas's own: `Album Earned II` draws the
              grid's second and last page with row 4 back at the grid origin 290
              and the last card's bottom edge at 643, i.e. 126 clear of the tab
              bar at 769. The scroller stops at the bar rather than running under
              it, so this is a flat 126 — `tabBar + 24` counted the bar's height
              a second time and left the bottomed-out grid 19pt low (D102). */}
          <ScrollView ref={grid} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 126, gap: 17 }}>
            {rows.map((row, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 17 }}>
                {row.map((s) => (
                  // A row that ends on one face is held to half the width, which
                  // the canvas states as `flex: 0 0 calc(50% - 5px)`. It cannot
                  // be `flex: 1` against a `flex: 1` spacer: a flex item's base
                  // size is floored at its own padding, so the card's 24 of
                  // horizontal padding makes it grow 12 wider than the empty box
                  // beside it. Yoga does this too — it is not a web quirk.
                  <FaceCard
                    key={s.face.key}
                    struck={s}
                    half={row.length === 1}
                    onPress={() => router.push(`/medallions/${s.face.key}?tier=${s.earned ? kkMetal(s.face, s.standing) : 'none'}`)}
                  />
                ))}
              </View>
            ))}
          </ScrollView>
        </View>
      </SafeAreaView>
    </View>
  );
}

/**
 * The state line under a face. Earned and tiered, it reads the rung it stands
 * on; earned and one-time, the day it was struck. Unearned, it reads how far
 * along the first rung is — "9 of 10 entries" — or, for a face that mints
 * once, the thing that would mint it.
 */
function stateLine(s: Struck): string {
  const { face } = s;
  if (s.earned) {
    if (face.steps.length) return `Tier ${kkRoman(s.standing)} · ${kkRung(face, face.steps[s.standing - 1])}`;
    return s.date ?? 'Minted';
  }
  if (face.steps.length) return `${s.count} of ${face.steps[0]}${face.noun ? ` ${face.noun}` : ''}`;
  return face.ahead ?? face.blurb;
}

/** One face in the grid: the coin in its triple rim, its name, and where it stands. */
function FaceCard({ struck, half, onPress }: { struck: Struck; half?: boolean; onPress: () => void }) {
  const line = stateLine(struck);
  // the canvas's `flex: 0 0 calc(50% - 8.5px)` — half the 353pt row less half
  // the 17pt gap. Stated as a width because neither flex basis nor a percentage
  // can subtract the gap, and `flex: 1` against an empty spacer cannot produce
  // it: a flex item's base size is floored at its own padding, so the card's 24
  // of horizontal padding would make it grow 12 wider than the box beside it.
  const halfW = (useWindowDimensions().width - 40 - 17) / 2;
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${struck.face.name}. ${line}`}
      style={{
        ...(half ? { width: halfW } : { flex: 1 }),
        // `UI Final` pinned the height and centred the contents in one edit;
        // either without the other reopens the ~26pt gap the diff closed.
        height: 168,
        minHeight: 168,
        borderRadius: 16,
        borderCurve: 'continuous',
        backgroundColor: '#FFFFFF',
        padding: 12,
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
      }}>
      {/* the triple rim the canvas mounts every face in */}
      <View style={{ borderRadius: 9999, boxShadow: '0 0 0 1.5px rgba(0,0,0,0.2), 0 0 0 5px #FFFFFF, 0 0 0 6.5px rgba(0,0,0,0.16)' }}>
        <KKMedallion scene={struck.face.key} size={68} metal="paper" sun={kkSun(struck.face.key, struck.earned)} />
      </View>
      {/* the canvas's `text-align:center` block is a shrink-to-fit column child,
          so it is exactly as wide as its longer line, not as wide as the card */}
      <View>
        <AppText center style={[sans('500'), { fontSize: 14.5, lineHeight: 18.85, color: '#1D1C1A' }]}>
          {struck.face.name}
        </AppText>
        <AppText center style={[sans('600'), { marginTop: 4, fontSize: 12.5, color: '#8B8882' }]}>
          {line}
        </AppText>
      </View>
    </PressScale>
  );
}
