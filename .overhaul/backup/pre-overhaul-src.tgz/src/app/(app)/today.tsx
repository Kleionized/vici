import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useId, useRef, useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Defs, FeGaussianBlur, Filter, LinearGradient as SvgLinearGradient, Path, RadialGradient, Rect, Stop } from 'react-native-svg';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTabBarHeight } from '@/components/StoicTabBar';
import { AppText, Grain, Hill, LoadingView, PressScale } from '@/components/ui';
import { BedArt, type DayStep, DoorwayArt, LessonDome, LessonNightArt, NoteArt, PhoneDownArt, ReadingsStrip, TaskCard, WaterArt } from '@/components/today/kit';
import { useCheckins, useCurrentUser, useEvents, useJournalEntries, useLessonProgressMap, useUpsertCheckin } from '@/lib/backend';
import { lessonForDay, weekFor, type Curriculum84Lesson, type Curriculum84Week } from '@/content/curriculum84';
import { buildScore } from '@/lib/score';
import { colors, fonts, sans } from '@/lib/theme';

/**
 * 21 · Today — three pages, scrolled down.
 *
 * Page one answers "where am I": the day count, the score drawn as the night
 * you are climbing out of, this morning's two readings, and the last thirty
 * days as thirty marks. Page two is the work in front of you — the lesson and
 * the day's one step. Page three is the line you signed. The mark, the profile
 * door and the urge bar hold across all three, because those are the three
 * things that must stay reachable without reading anything.
 *
 * `UI Final` re-dealt these blocks: the readings moved up to page one, the
 * lesson card moved down to page two beside the task, the pledge took a page of
 * its own, the pager dots were deleted, and the thirty-day strip is new.
 *
 * Laid out from the canvas's 393 × 852 frame: the status bar ends at 54, the
 * urge bar starts at 705 and the tab bar at 769.
 */

const laurelMark = require('../../../assets/images/laurel-mark.webp');
const noiseDark = require('../../../assets/images/noise-dark.png');

/**
 * An SVG filter interpolates in `linearRGB` by default; CSS's `filter: blur()`
 * works in `sRGB`, so a Gaussian transcribed from the canvas without this comes
 * back off by a couple of levels per channel (FINDINGS F43). Not in the
 * typings, hence the cast.
 */
const SRGB = { colorInterpolationFilters: 'sRGB' } as unknown as Record<string, never>;

const MOOD_WORD = ['Heavy', 'Low', 'Fine', 'Good', 'Clear'];
const ENERGY_WORD = ['Empty', 'Low', 'Steady', 'Good', 'Full'];

/**
 * The steps the card falls back on when nobody has named the day's action yet.
 * The first is the one the canvas draws; the rest follow its shape — when it
 * belongs, one plain sentence, and the thing itself drawn into the card's night.
 */
const DAY_STEPS: DayStep[] = [
  { when: 'Tonight', caption: 'Put your phone somewhere difficult to access before you sleep.', art: PhoneDownArt },
  { when: 'Today', caption: 'Drink a full glass of water before anything else.', art: WaterArt },
  { when: 'Today', caption: 'Get outside for ten minutes, even if it is only around the block.', art: DoorwayArt },
  { when: 'Today', caption: 'Write down what set it off, in the words you would say out loud.', art: NoteArt },
  { when: 'Before bed', caption: 'Make the bed now, so tonight you walk into a room that is ready.', art: BedArt },
];

export default function Today() {
  const router = useRouter();
  const user = useCurrentUser();
  const progress = useLessonProgressMap();
  const checkins = useCheckins();
  const events = useEvents();
  const journal = useJournalEntries();
  const upsertCheckin = useUpsertCheckin();
  const pager = useRef<ScrollView>(null);
  // Both pages are exactly one viewport tall, so the scroll snaps between them.
  // Computed rather than measured: onLayout on web settles a frame late and the
  // first page would render at its natural height.
  const insets = useSafeAreaInsets();
  const pageH = useWindowDimensions().height - insets.top - 37 - 64 - useTabBarHeight();
  // Read once on mount: the day count and today's key must not shift under a
  // re-render while the screen is open.
  const [now] = useState(() => Date.now());

  if (progress === undefined || checkins === undefined || events === undefined) {
    return <LoadingView />;
  }

  const day = user?.createdAt ? Math.max(1, Math.floor((now - user.createdAt) / 86_400_000) + 1) : 1;
  const lessonsDone = Object.values(progress).filter((p) => p?.status === 'completed').length;
  const score = buildScore(checkins, events, lessonsDone, user?.createdAt);

  const n = new Date(now);
  const todayKeyLocal = `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`;
  const todayCheckin = checkins.find((c) => c.date === todayKeyLocal);
  const moodIdx = todayCheckin?.mood != null ? Math.max(0, Math.min(4, todayCheckin.mood - 1)) : null;
  const energyIdx = todayCheckin?.energy != null ? Math.max(0, Math.min(4, todayCheckin.energy - 1)) : moodIdx;
  const pledge = (journal ?? []).find((entry) => entry.tag === 'Pledge');

  // The last thirty days, oldest first. A day is held unless a lapse landed on
  // it; the canvas draws thirty slots and exactly two marks, so a day before the
  // account existed takes the ring rather than a third tone it has no support
  // for. The counter is derived, never stated.
  const lapsedDays = new Set(
    (events ?? [])
      .filter((event) => event.type === 'lapse')
      .map((event) => {
        const at = new Date(event.createdAt);
        return `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, '0')}-${String(at.getDate()).padStart(2, '0')}`;
      }),
  );
  const held = Array.from({ length: 30 }, (_, index) => {
    const at = new Date(now - (29 - index) * 86_400_000);
    const key = `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, '0')}-${String(at.getDate()).padStart(2, '0')}`;
    if (user?.createdAt && at.getTime() < user.createdAt) return false;
    return !lapsedDays.has(key);
  });

  // The day's one action. The night check-in names it and files it under the
  // day it is *for*, so by the time it reaches this card it is simply today's.
  // Until someone names one, the card carries the day's own step instead.
  // A task the curriculum set for the day is the card's lesson-sourced state:
  // it takes the lesson's own name and glyph and is set a step smaller. One
  // named by hand in the night check-in stays the generic state.
  const dayLesson = lessonForDay(day);
  const dayWeek = dayLesson ? weekFor(dayLesson.week) : undefined;
  const step: DayStep = todayCheckin?.dailyAction
    ? { when: 'Today', caption: todayCheckin.dailyAction, art: NoteArt }
    : dayLesson
      ? { when: 'Today', caption: dayLesson.task.cardSummary, art: LessonNightArt, lesson: dayLesson.task.cardTitle }
      : DAY_STEPS[(day - 1) % DAY_STEPS.length];
  const stepDone = todayCheckin?.dailyActionDone ?? false;

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Grain source={noiseDark} opacity={0.07} />

      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        {/* the mark and the settings door — design y 64, 27 tall. The glyph opens
          `92 · Settings`, not Edit profile: the canvas draws `Settings` with an
          `Edit profile` row under Account and `Edit Profile` with a Back row, so
          Settings is the parent. It is also the only door the bundle leaves to
          it — `Edit Profile`'s `App` section, which used to carry the Settings
          row, is drawn on none of the 267 frames (F33). */}
        <View style={{ height: 37, paddingTop: 10, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <Image source={laurelMark} contentFit="contain" style={{ width: 27, height: 27 }} />
          <PressScale onPress={() => router.push('/(app)/settings')} accessibilityRole="button" accessibilityLabel="Open settings" hitSlop={16}>
            <Svg width={26} height={26} viewBox="0 0 26 26" fill="none">
              <Circle cx={13} cy={9.5} r={4} stroke={colors.textMuted} strokeWidth={2} />
              <Path d="M4.5 22.5c1-4.5 4.2-6.8 8.5-6.8s7.5 2.3 8.5 6.8" stroke={colors.textMuted} strokeWidth={2} strokeLinecap="round" />
            </Svg>
          </PressScale>
        </View>

        <View style={{ flex: 1 }}>
          <ScrollView
            ref={pager}
            pagingEnabled
            snapToInterval={pageH}
            decelerationRate="fast"
            showsVerticalScrollIndicator={false}
            scrollEventThrottle={16}
            style={{ flex: 1 }}>
            <View style={{ height: pageH }}>
              <PageOne
                day={day}
                score={score}
                mood={moodIdx}
                energy={energyIdx}
                held={held}
                onScore={() => router.push('/score')}
                onMorning={() => router.push('/day/morning')}
              />
            </View>
            <View style={{ height: pageH }}>
              <PageTwo
                lesson={dayLesson}
                week={dayWeek}
                step={step}
                stepDone={stepDone}
                onStep={() => (dayLesson ? router.push(`/task/${dayLesson.day}`) : void upsertCheckin({ date: todayKeyLocal, dailyActionDone: !stepDone }))}
                onLesson={() => (dayLesson ? router.push(`/lesson-card/${dayLesson.day}`) : router.push('/lessons-browser'))}
                onLibrary={() => router.push('/(app)/library')}
              />
            </View>
            <View style={{ height: pageH }}>
              <PageThree pledge={pledge} name={user?.displayName} onPledges={() => router.push('/(app)/journal')} />
            </View>
          </ScrollView>
        </View>
      </SafeAreaView>

      {/* The one door that stays open on every page. It opens `85A · Urge Hub —
          Right now`, not the interrupt's intro: the hub is the board the canvas
          heads "URGE HUB — RIDE IT OUT", it carries the live surf clock and the
          first command, and its own "Breathe" pill is what hands over to the
          coping stages. The interrupt keeps its route and is still reached from
          `/(app)/all`. */}
      <PressScale
        onPress={() => router.push('/urge-hub')}
        accessibilityRole="button"
        accessibilityLabel="Urge surfing and SOS"
        style={{
          height: 64,
          borderTopLeftRadius: 18,
          borderTopRightRadius: 18,
          backgroundColor: colors.ink,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 13,
          paddingHorizontal: 16,
        }}>
        <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(244,243,240,0.12)', alignItems: 'center', justifyContent: 'center' }}>
          <Svg width={20} height={13} viewBox="0 0 26 16" fill="none">
            <Path d="M2 12c4-7 8 3 12-3s8 2 10-2" stroke="#F4F3F0" strokeWidth={2.4} strokeLinecap="round" />
          </Svg>
        </View>
        {/* the bar carried two lines in the previous bundle; this one names it once */}
        <AppText style={[sans('600'), { flex: 1, fontSize: 15, color: '#F7F6F2' }]}>Urge surfing</AppText>
        <Svg width={7} height={12} viewBox="0 0 8 14" fill="none">
          <Path d="M1.5 1.5L6.5 7l-5 5.5" stroke="rgba(244,243,240,0.5)" strokeWidth={2} strokeLinecap="round" />
        </Svg>
      </PressScale>
    </View>
  );
}

/* ------------------------------------------------------------------- page one */

function PageOne({
  day,
  score,
  mood,
  energy,
  held,
  onScore,
  onMorning,
}: {
  day: number;
  score: ReturnType<typeof buildScore>;
  mood: number | null;
  energy: number | null;
  held: boolean[];
  onScore: () => void;
  onMorning: () => void;
}) {
  return (
    <View style={{ flex: 1 }}>
      {/* design 114, i.e. 23 below the mark row */}
      {/* the canvas's box is as wide as the words, not as wide as the row */}
      <AppText style={[sans('600'), { alignSelf: 'flex-start', marginLeft: 16, marginTop: 23, fontSize: 27, lineHeight: 27, letterSpacing: -0.2, color: colors.text }]}>
        Day {day}
      </AppText>

      <View style={{ marginTop: 23 }}>
        <ScoreCard score={score} onPress={onScore} />
      </View>

      {/* design 402 — 16 under the score card */}
      <SectionRow label="This morning" onPress={onMorning} marginTop={16} />

      {/* design 428 — the label's own box is 15 tall from 402, so the gap the
          canvas leaves under a section row is 11, not the 11.5 this carried */}
      <View style={{ marginTop: 11 }}>
        <ReadingsStrip
          mood={mood}
          energy={energy}
          moodWord={mood != null ? MOOD_WORD[mood] : '—'}
          energyWord={energy != null ? ENERGY_WORD[energy] : '—'}
        />
      </View>

      {/* design 492 — 16 under the readings */}
      <View style={{ marginTop: 16 }}>
        <HeldStrip held={held} />
      </View>
    </View>
  );
}

/**
 * The score, drawn as the thing it measures: a night sky with a low moon and a
 * ridge you are climbing. The number sits on the dark because that is where the
 * work happens.
 */
function ScoreCard({ score, onPress }: { score: ReturnType<typeof buildScore>; onPress: () => void }) {
  const id = useId().replace(/:/g, '');
  // The card runs full width inside a 12pt gutter; the sky art is positioned
  // from its right edge, as the canvas does.
  const W = useWindowDimensions().width - 24;
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Recovery score ${score.total}`}
      style={{
        marginHorizontal: 12,
        height: 222,
        borderRadius: 22,
        borderCurve: 'continuous',
        overflow: 'hidden',
        backgroundColor: '#0C0D10',
        boxShadow: '0 0 0 1px rgba(0,0,0,0.25), 0 14px 30px rgba(30,28,24,0.28)',
      }}>
      {/* sky */}
      <Svg width="100%" height={222} style={{ position: 'absolute' }}>
        <Defs>
          <SvgLinearGradient id={`sky${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#0B0A09" />
            <Stop offset="0.55" stopColor="#14130F" />
            <Stop offset="1" stopColor="#1E1C17" />
          </SvgLinearGradient>
          {/* `radial-gradient(circle at 36% 30%, …)` names no size, so CSS uses
              farthest-corner: from (36%, 30%) of a 30px box the far corner is
              √((0.64·30)² + (0.70·30)²) = 28.45px, which is 94.8% of the box.
              `rx`/`ry` are what the native build reads and `r` is the attribute
              a browser reads — the web build forwards the props verbatim and
              `<radialGradient>` has no `rx`, so without `r` it silently falls
              back to 50% and the disc renders a third darker at its rim. */}
          <RadialGradient id={`moon${id}`} cx="36%" cy="30%" r="94.8%" rx="94.8%" ry="94.8%">
            <Stop offset="0" stopColor="#FBEFD6" />
            <Stop offset="0.46" stopColor="#EBD0A0" />
            <Stop offset="1" stopColor="#C9A469" />
          </RadialGradient>
          {/* `closest-side` on the halo's own square box is exactly half of it,
              which is the one radius `react-native-svg`'s web build can carry:
              it forwards `rx`/`ry`, which are not `<radialGradient>`
              attributes, so every other radius falls back to 50% there. */}
          <RadialGradient id={`halo${id}`} cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.3} />
            <Stop offset="0.72" stopColor="#E2BA78" stopOpacity={0} />
          </RadialGradient>
          {/* The canvas blurs the halo by 5px, and gives the moon a
              `0 0 26px rgba(226,186,120,0.4)` shadow — a CSS shadow's blur
              radius is two standard deviations, so that bloom is the disc's own
              silhouette at σ 13. Both were fitted ramps until this drop;
              `react-native-svg` carries a real Gaussian, so both are now drawn
              as the canvas states them. A filter region has to be stated: the
              default is 10% of the bounding box, which would cut a 13pt blur
              off inside its own bloom. */}
          <Filter id={`soft5${id}`} x="-100%" y="-100%" width="300%" height="300%" {...SRGB}>
            <FeGaussianBlur stdDeviation="5" />
          </Filter>
          <Filter id={`bloom${id}`} x="-200%" y="-200%" width="500%" height="500%" {...SRGB}>
            <FeGaussianBlur stdDeviation="13" />
          </Filter>
        </Defs>
        <Rect x={0} y={0} width="100%" height={222} fill={`url(#sky${id})`} />
        {/* the canvas's `left`/`top` place a star box's corner, not its centre,
            so each centre is the stated offset plus half the box */}
        <Circle cx={117} cy={35} r={1} fill="#F4F3F0" fillOpacity={0.45} />
        <Circle cx={W - 151.25} cy={57.25} r={1.25} fill="#F4F3F0" fillOpacity={0.35} />
        <Circle cx={53} cy={97} r={1} fill="#F4F3F0" fillOpacity={0.3} />
        <Circle cx={W - 66} cy={76} r={42} fill={`url(#halo${id})`} filter={`url(#soft5${id})`} />
        <Circle cx={W - 63} cy={71} r={15} fill="#E2BA78" fillOpacity={0.4} filter={`url(#bloom${id})`} />
        <Circle cx={W - 63} cy={71} r={15} fill={`url(#moon${id})`} />
      </Svg>

      {/* the two ridges, drawn in the canvas's own 369 × 76 frame */}
      <Svg width="100%" height={64} viewBox="0 0 369 76" preserveAspectRatio="none" style={{ position: 'absolute', left: 0, right: 0, top: 102 }}>
        <Defs>
          <SvgLinearGradient id={`h1${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#2B2A26" />
            <Stop offset="1" stopColor="#0C0B0A" />
          </SvgLinearGradient>
          <SvgLinearGradient id={`h2${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#37342D" />
            <Stop offset="1" stopColor="#0F0E0C" />
          </SvgLinearGradient>
        </Defs>
        <Path d="M-4,76 L-4,50 Q56,22 124,48 Q160,61 188,68 L188,76 Z" fill={`url(#h1${id})`} />
        <Path d="M168,76 L168,66 Q226,57 270,36 Q316,17 373,25 L373,76 Z" fill={`url(#h2${id})`} />
      </Svg>

      {/* The waterline glow, then the flat dark below it, then the moon's
          reflection on the water — the canvas's own 38 × 44 shaft at right 50,
          top 168.

          The canvas blurs the glow band 3px and the shaft 5px, and an <Svg>
          clips to its own viewport, so this box starts 10 above the band to
          give those blurs their headroom. The sea is drawn after the glow, as
          the canvas draws it, so it covers the band's bleed downwards. */}
      <Svg width="100%" height={78} style={{ position: 'absolute', left: 0, right: 0, top: 144 }}>
        <Defs>
          <SvgLinearGradient id={`glow${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#E9C78A" stopOpacity={0} />
            <Stop offset="1" stopColor="#E9C78A" stopOpacity={0.28} />
          </SvgLinearGradient>
          <SvgLinearGradient id={`sea${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#1C1A16" />
            <Stop offset="1" stopColor="#0C0B0A" />
          </SvgLinearGradient>
          <SvgLinearGradient id={`shaft${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.28} />
            <Stop offset="1" stopColor="#E2BA78" stopOpacity={0} />
          </SvgLinearGradient>
          <Filter id={`soft3${id}`} x="-100%" y="-100%" width="300%" height="300%" {...SRGB}>
            <FeGaussianBlur stdDeviation="3" />
          </Filter>
          <Filter id={`soft5w${id}`} x="-100%" y="-100%" width="300%" height="300%" {...SRGB}>
            <FeGaussianBlur stdDeviation="5" />
          </Filter>
        </Defs>
        <Rect x={0} y={10} width="100%" height={12} fill={`url(#glow${id})`} filter={`url(#soft3${id})`} />
        <Rect x={0} y={22} width="100%" height={56} fill={`url(#sea${id})`} />
        <Rect x={W - 88} y={24} width={38} height={44} fill={`url(#shaft${id})`} filter={`url(#soft5w${id})`} />
      </Svg>

      <AppText style={[sans('500'), { position: 'absolute', left: 20, top: 22, fontSize: 13, color: '#F7F6F2' }]}>Recovery score</AppText>

      <View
        style={{
          position: 'absolute',
          right: 16,
          top: 16,
          // the canvas states no box-sizing and carries no reset, so its 30 is
          // content: 30 + two 1px borders = 32 outer
          height: 32,
          // the canvas states 15 on a pill its own borders make 32 tall
          borderRadius: 15,
          borderWidth: 1,
          borderColor: 'rgba(244,243,240,0.28)',
          backgroundColor: 'rgba(20,19,16,0.25)',
          paddingHorizontal: 12,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 6,
        }}>
        <Svg width={14} height={10} viewBox="0 0 14 10" fill="none">
          <Path d="M1 8.5L5 4.5l2.5 2L12.5 1.5" stroke="#F4F3F0" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
          <Path d="M9.2 1.5h3.3V4.8" stroke="#F4F3F0" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
        <AppText style={[sans('600'), { fontSize: 12, color: '#F4F3F0' }]}>Trend</AppText>
      </View>

      <View style={{ position: 'absolute', left: 20, top: 48, flexDirection: 'row', alignItems: 'baseline', gap: 9 }}>
        <AppText style={[sans('500'), { fontSize: 43, letterSpacing: 1.5, color: '#F7F6F2' }]}>
          {score.total.toLocaleString()}
        </AppText>
        {score.delta !== 0 ? (
          <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 3 }}>
            <Svg width={9} height={8} viewBox="0 0 10 9">
              <Path d={score.delta > 0 ? 'M5 0.5L9.5 8.5H0.5z' : 'M5 8.5L0.5 0.5h9z'} fill="rgba(244,243,240,0.8)" />
            </Svg>
            <AppText style={[sans('500'), { fontSize: 13, color: 'rgba(244,243,240,0.8)' }]}>{Math.abs(score.delta)}</AppText>
          </View>
        ) : null}
      </View>

      <View style={{ position: 'absolute', left: 20, right: 20, bottom: 50, height: 6, borderRadius: 3, backgroundColor: 'rgba(244,243,240,0.14)', overflow: 'hidden' }}>
        <View style={{ width: `${score.progress * 100}%`, height: 6, borderRadius: 3, backgroundColor: '#E2BA78' }} />
      </View>
      <View style={{ position: 'absolute', left: 20, right: 20, bottom: 22, flexDirection: 'row', justifyContent: 'space-between' }}>
        <AppText style={[sans('500'), { fontSize: 11, color: 'rgba(244,243,240,0.55)' }]}>
          {score.rank.name} · {score.rank.at.toLocaleString()}
        </AppText>
        {score.next ? (
          <AppText style={[sans('500'), { fontSize: 11, color: 'rgba(244,243,240,0.55)' }]}>
            {score.next.name} · {score.next.at.toLocaleString()}
          </AppText>
        ) : null}
      </View>

      <Grain source={noiseDark} opacity={0.06} />
    </PressScale>
  );
}

/**
 * The lesson in front of you, under a dome carrying its own plate.
 *
 * The canvas draws the rail as six segments; a week is seven lessons, so a
 * six-slot rail can never fill. It is one per lesson in the week instead, which
 * is what the lesson card's own dot rail already does (DECISIONS D133 — the
 * `D-112` this used to cite belongs to a previous run's log and resolves to
 * nothing in this one).
 *
 * The title and the meta line the two frames draw are a mock the canvas reused
 * across both of them, not this card's own state (D132).
 */
function LessonCard({ title, meta, day, done, count, onPress }: { title: string; meta: string; day?: number; done: number; count: number; onPress: () => void }) {
  const id = useId().replace(/:/g, '');
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${title}. ${meta}`}
      style={{
        marginHorizontal: 12,
        height: 152,
        borderRadius: 20,
        borderCurve: 'continuous',
        overflow: 'hidden',
        backgroundColor: colors.surface,
        boxShadow: '0 0 0 1px rgba(0,0,0,0.05), 0 10px 24px rgba(40,38,32,0.07)',
      }}>
      {/* the canvas gives the title no right bound and no clamp — it may run
          under the dome, which does not start until x 217 */}
      <AppText style={[sans('600'), { position: 'absolute', left: 20, top: 26, fontSize: 19, letterSpacing: -0.2, color: colors.text }]}>
        {title}
      </AppText>
      <AppText style={[sans('400'), { position: 'absolute', left: 20, top: 56, fontSize: 12.5, color: colors.textSoft }]}>{meta}</AppText>

      <LessonDome id={id} day={day} />

      <Svg width={8} height={14} viewBox="0 0 8 14" fill="none" style={{ position: 'absolute', right: 16, top: 22 }}>
        <Path d="M1.5 1.5L6.5 7l-5 5.5" stroke={colors.textSoft} strokeWidth={2} strokeLinecap="round" />
      </Svg>

      <View style={{ position: 'absolute', left: 20, right: 20, bottom: 20, flexDirection: 'row', gap: 7 }}>
        {Array.from({ length: count }, (_, i) => (
          <View key={i} style={{ flex: 1, height: 4.5, borderRadius: 2.5, backgroundColor: i < done ? colors.ink : 'rgba(19,19,19,0.15)' }} />
        ))}
      </View>
    </PressScale>
  );
}

/* ------------------------------------------------------------------- page two */

function PageTwo({
  lesson,
  week,
  step,
  stepDone,
  onStep,
  onLesson,
  onLibrary,
}: {
  lesson: Curriculum84Lesson | undefined;
  week: Curriculum84Week | undefined;
  step: DayStep;
  stepDone: boolean;
  onStep: () => void;
  onLesson: () => void;
  onLibrary: () => void;
}) {
  // Where this lesson sits in its own week, and how much of the week is behind
  // it. The canvas prints "Lesson 5 · Week II" — a within-week index and a
  // roman week, which a global lesson number can never produce.
  const indexInWeek = week && lesson ? week.lessons.findIndex((l) => l.day === lesson.day) : -1;
  return (
    <View style={{ flex: 1 }}>
      {/* design 138 — 47 below the mark row */}
      <SectionRow label="This week" action="Library" actionOffset={-2} onPress={onLibrary} marginTop={47} />

      {/* design 164 — the same 11 under the row as page one */}
      <View style={{ marginTop: 11 }}>
        <LessonCard
          title={lesson?.title ?? 'Start the first lesson'}
          meta={lesson && week ? `Lesson ${indexInWeek + 1} · Week ${week.roman}` : 'Week I'}
          day={lesson?.day}
          done={indexInWeek < 0 ? 0 : indexInWeek}
          count={week?.lessons.length ?? 7}
          onPress={onLesson}
        />
      </View>

      {/* design 340 — 24 under the lesson card */}
      <View style={{ marginTop: 24 }}>
        <TaskCard step={step} done={stepDone} onPress={onStep} />
      </View>
    </View>
  );
}

function PageThree({ pledge, name, onPledges }: { pledge?: { body: string; createdAt: number }; name?: string; onPledges: () => void }) {
  return (
    <View style={{ flex: 1 }}>
      {/* the canvas leaves nothing on the right of this row now — no label and
          no chevron — so the row is a label with a hit target behind it */}
      <SectionRow label="Your pledge" chevron={false} onPress={onPledges} marginTop={47} />

      {/* design 164 */}
      <View style={{ marginTop: 11 }}>
        <PledgeCard pledge={pledge} name={name} onPress={onPledges} />
      </View>
    </View>
  );
}

/**
 * The last thirty days as thirty marks. Ten to a row, and the columns are pinned
 * with a derived gap rather than left to a wrapping flex row, which would
 * silently drop to nine columns on a 375pt phone and push the block past the
 * card's content line.
 *
 * `UI Final 1` re-cuts the grid: the marks grow 20 → 24, the inset comes in
 * 35 → 20, and the gap falls to 9.88 — `10 × 24 + 9 × 9.88 = 329`, exact at the
 * canvas's 393. An unheld day is now a white disc with a 1pt ring rather than
 * an empty one with a 1.5pt ring, and today carries a 2pt gold one.
 */
const HELD_DOT = 24;
const HELD_INSET = 20;
function HeldStrip({ held }: { held: boolean[] }) {
  const width = useWindowDimensions().width;
  const inner = width - 24 - HELD_INSET * 2;
  const gap = Math.max(0, (inner - 10 * HELD_DOT) / 9);
  return (
    <View
      style={{
        marginHorizontal: 12,
        height: 184,
        borderRadius: 20,
        borderCurve: 'continuous',
        overflow: 'hidden',
        backgroundColor: colors.surface,
        boxShadow: '0 0 0 1px rgba(0,0,0,0.05), 0 10px 24px rgba(40,38,32,0.07)',
      }}>
      <AppText style={[sans('500'), { position: 'absolute', left: 20, top: 20, fontSize: 13, color: colors.text }]}>Last 30 days</AppText>
      <View style={{ position: 'absolute', left: HELD_INSET, top: 58, right: HELD_INSET, flexDirection: 'row', flexWrap: 'wrap', gap }}>
        {held.map((on, index) => {
          const today = index === held.length - 1;
          return (
            <View
              key={index}
              style={{
                width: HELD_DOT,
                height: HELD_DOT,
                borderRadius: HELD_DOT / 2,
                backgroundColor: on ? colors.ink : '#FFFFFF',
                boxShadow: today ? 'inset 0 0 0 2px #D9A441' : on ? undefined : 'inset 0 0 0 1px rgba(0,0,0,0.14)',
              }}
            />
          );
        })}
      </View>
    </View>
  );
}

/**
 * A quiet section label with its way through on the right. The row is only as
 * tall as its label — the canvas measures from the label's own box — so the
 * touch target comes from hitSlop rather than from padding it out.
 */
function SectionRow({
  label,
  action,
  actionOffset = 0,
  chevron = true,
  onPress,
  marginTop,
}: {
  label: string;
  action?: string;
  actionOffset?: number;
  /**
   * `21 · Today` draws a bare chevron on "This morning", a label *and* a
   * chevron on "This week", and nothing at all on "Your pledge" — so the
   * right-hand side is stated per row rather than implied by the label.
   */
  chevron?: boolean;
  onPress: () => void;
  marginTop: number;
}) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={action ?? label}
      hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}
      style={{ minHeight: 0, marginTop, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
      <AppText style={[sans('600'), { fontSize: 12.5, color: colors.textSoft }]}>{label}</AppText>
      {action || chevron ? (
        <View style={{ marginTop: actionOffset, flexDirection: 'row', alignItems: 'center', gap: 5 }}>
          {action ? <AppText style={[sans('600'), { fontSize: 11, letterSpacing: 0.5, color: colors.textSoft }]}>{action}</AppText> : null}
          {chevron ? (
            <Svg width={7} height={12} viewBox="0 0 8 14" fill="none">
              <Path d="M1.5 1.5L6.5 7l-5 5.5" stroke="#B0AEA8" strokeWidth={2} strokeLinecap="round" />
            </Svg>
          ) : null}
        </View>
      ) : null}
    </PressScale>
  );
}

/**
 * The line you signed this morning, on the paper you signed it on.
 *
 * `UI Final 1` rebuilds this card: the pledge is one plain sentence — the
 * "I am abstaining today because" stem and the underline under the reason are
 * both gone — the serif is dropped for the frame's own sans, the timestamp is
 * deleted, and a warm scene comes in behind the words: a glow off the top-right
 * corner with a sun disc in it, and two hills breaking the bottom edge.
 */
function PledgeCard({ pledge, name, onPress }: { pledge?: { body: string; createdAt: number }; name?: string; onPress: () => void }) {
  const body = pledge?.body ?? '';

  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={body || 'Your pledge'}
      style={{
        marginHorizontal: 12,
        height: 140,
        borderRadius: 14,
        borderCurve: 'continuous',
        overflow: 'hidden',
        backgroundColor: colors.surface,
        boxShadow: '0 0 0 1px rgba(0,0,0,0.06)',
      }}>
      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
        <Svg width={150} height={150} style={{ position: 'absolute', right: -34, top: -44 }}>
          <Defs>
            <RadialGradient id="pledgeSun" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#E9D2A4" stopOpacity={0.34} />
              <Stop offset="0.74" stopColor="#E9D2A4" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Circle cx={75} cy={75} r={75} fill="url(#pledgeSun)" />
        </Svg>
        <View style={{ position: 'absolute', right: 24, top: 22, width: 26, height: 26, borderRadius: 13, backgroundColor: '#F0DDB4' }} />
        {/* two hills, each a box whose top edge is an elliptical arc: the
            canvas gives them a 50% horizontal radius and a 46 / 40pt vertical
            one, which no single `borderRadius` can express */}
        <Hill height={100} rise={46} color="#EFEEE9" style={{ position: 'absolute', left: -30, right: -30, bottom: -58 }} />
        <Hill height={100} rise={40} color="#E9E8E2" style={{ position: 'absolute', left: -60, right: -10, bottom: -70 }} />
      </View>

      {/* `Latest Vici FULL` replaces the typeset opening quote with a drawn
          pair of commas — a 16 × 12 mark in a 44 × 32 frame — and sets the
          pledge itself a step smaller against it.

          The canvas states `top: 20` on the *box* the mark is inline in, and
          that box is a CSS line box: a 12pt inline sits on the baseline, which
          in the frame's 16px strut is 14.6 down, so the mark itself is drawn at
          23 and the box measures 18 tall. Yoga has no strut, so the 3 is
          written out (D020). */}
      <Svg width={16} height={12} viewBox="0 0 44 32" style={{ position: 'absolute', left: 16, top: 23 }}>
        <Path
          d="M9.8 0C4.2 3.4 0 9.6 0 16.9 0 26 5.4 32 12.4 32c5.4 0 9.3-3.8 9.3-9 0-5-3.6-8.6-8.4-8.6-.9 0-2 .2-2.6.4C11 10.1 14.1 5.4 18.3 2.9L9.8 0z"
          fill="#C9C0AC"
        />
        <Path
          d="M31.9 0c-5.6 3.4-9.8 9.6-9.8 16.9 0 9.1 5.4 15.1 12.4 15.1 5.4 0 9.3-3.8 9.3-9 0-5-3.6-8.6-8.4-8.6-.9 0-2 .2-2.6.4.3-4.7 3.4-9.4 7.6-11.9L31.9 0z"
          fill="#C9C0AC"
        />
      </Svg>
      <AppText style={[sans('500'), { position: 'absolute', left: 36, right: 60, top: 26, fontSize: 15, lineHeight: 22, letterSpacing: -0.1, color: '#3A3934' }]}>
        {body}
      </AppText>

      {/* the canvas leaves an empty span where the timestamp was, purely as the
          flex spacer that keeps the signature on the right */}
      <View style={{ position: 'absolute', left: 16, right: 16, bottom: 11, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'flex-end' }}>
        {pledge ? (
          <View style={{ alignItems: 'flex-end' }}>
            {/* The canvas's signature is a BLOCK the width of the rule under it,
                with the name set right inside it — not a shrink-wrapped run.
                CSS rotates about the box's own centre, so the two differ: the
                frame pivots the name about x 319 and a shrink-wrapped run pivots
                it about x 340, which drops the glyphs 1.3pt and tilts them about
                a different point. Stated at the canvas's 92 so the pivot is the
                frame's. */}
            <AppText style={{ width: 92, textAlign: 'right', fontFamily: fonts.script, fontSize: 24, lineHeight: 24, color: colors.text, transform: [{ rotate: '-3.5deg' }] }}>
              {name?.split(' ')[0] ?? 'You'}
            </AppText>
            <View style={{ marginTop: 4, width: 92, height: 1, backgroundColor: 'rgba(0,0,0,0.2)' }} />
          </View>
        ) : (
          <View style={{ width: 92, height: 1, backgroundColor: 'rgba(0,0,0,0.2)' }} />
        )}
      </View>
    </PressScale>
  );
}
