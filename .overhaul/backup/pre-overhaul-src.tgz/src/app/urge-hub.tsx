import { UrgeHub } from '@/components/urge';

/**
 * `85A–85E · URGE HUB — RIDE IT OUT` — the five panes the canvas gives their
 * own section, between the slip flow and the Rough Days library.
 *
 * It is not a step of the interrupt: `FLOW.txt` heads it as a section of its
 * own, and every pane carries the same close ✕, pager, Breathe pill and
 * "I slipped" link rather than a Continue.
 */
export default function UrgeHubRoute() {
  return <UrgeHub />;
}
