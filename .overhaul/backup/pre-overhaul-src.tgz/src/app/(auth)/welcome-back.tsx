import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Platform, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';

import { AuthBack, AuthButton, AuthDoor, AuthField, AuthMark, AuthMessage, AuthNightField, AuthSurface } from '@/components/auth/kit';
import { AppText, PressScale } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { sans } from '@/lib/theme';

/**
 * 03 · Welcome Back — new in `Latest Vici FULL`, and the returning-user door.
 *
 * The frame is `02 · Login` with four strings changed: "Welcome back.", "Sign
 * in to pick up where you left off.", "Sign in with email", and a footer that
 * sends new arrivals back to the login board. It is drawn by the same
 * `AuthDoor`, which is why only those four strings live here.
 *
 * Everything past the door is this route's too: the address step, the password
 * step and the verification code. None of the three has a frame — the bundle
 * withdrew `Login Typing` and `Create Account` a drop ago and did not replace
 * them — so they keep their existing composition and take the night dress the
 * funnel states (see `src/components/auth/kit.tsx`).
 */

type Mode = 'door' | 'password' | 'verify';

export default function WelcomeBack() {
  const router = useRouter();
  const { signInWithPassword, signInWithSSO, verifySignInCode, resendSignInCode } = useAuth();
  const [mode, setMode] = useState<Mode>('door');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  /**
   * The address step, opened from the door's email row.
   *
   * It cannot ride on the field's focus alone: blurring an empty field would
   * drop the board back to the door mid-flow, which is not what the control did
   * when the board carried the field itself.
   */
  const [emailStep, setEmailStep] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const reset = () => {
    setError(null);
    setNotice(null);
  };
  const back = () => {
    reset();
    if (mode === 'verify') return setMode('password');
    setMode('door');
  };
  /** Out of the address step and back to the door this route opened on. */
  const leave = () => {
    reset();
    setEmail('');
    setEmailStep(false);
  };

  const continueWithEmail = () => {
    if (!email.trim()) return setError('Enter your email address to carry on.');
    reset();
    setMode('password');
  };

  async function submitPassword() {
    setLoading(true);
    reset();
    const res = await signInWithPassword(email, password);
    setLoading(false);
    if (res.ok) return router.replace('/');
    if (res.needsVerification) return setMode('verify');
    setError(res.error ?? 'Could not sign in.');
  }

  async function submitCode() {
    setLoading(true);
    reset();
    const res = await verifySignInCode(code);
    setLoading(false);
    if (!res.ok) return setError(res.error ?? 'Could not verify code.');
    router.replace('/');
  }

  async function sso(strategy: 'oauth_apple' | 'oauth_google') {
    setLoading(true);
    reset();
    const res = await signInWithSSO(strategy);
    setLoading(false);
    if (res.ok) return router.replace('/');
    setError(res.error ?? 'Could not complete sign in.');
  }

  if (mode === 'door' && !emailStep) {
    return (
      <>
        <StatusBar style="light" />
        <AuthDoor
          variant="returning"
          loading={loading}
          message={<AuthMessage error={error} notice={notice} />}
          onApple={() => void sso('oauth_apple')}
          onGoogle={() => void sso('oauth_google')}
          onEmail={() => {
            reset();
            setEmailStep(true);
          }}
          // "New here? Create an account" is the way back to `02 · Login`,
          // which is where this board was opened from.
          onFooter={() => (router.canGoBack() ? router.back() : router.replace('/(auth)/sign-in'))}
        />
      </>
    );
  }

  if (mode === 'door') {
    // The address step. No frame draws it; the geometry is the board it
    // replaced — the mark rides up 10 when the keyboard is coming, design
    // y 170 → 160.
    return (
      <View style={{ flex: 1, backgroundColor: '#131313' }}>
        <StatusBar style="light" />
        <AuthNightField />
        <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
          <View style={{ flex: 1 }}>
            <View style={{ position: 'absolute', left: 0, top: 40, zIndex: 5 }}>
              <AuthBack onPress={leave} />
            </View>

            <View style={{ position: 'absolute', left: 0, right: 0, top: 106, alignItems: 'center' }}>
              <AuthMark />
            </View>

            <AppText style={[sans('400'), { position: 'absolute', left: 24, top: 316, fontSize: 15, color: '#F4F3F0' }]}>
              Sign in to keep building toward the life you want
            </AppText>

            <View
              style={{
                position: 'absolute',
                left: 24,
                right: 24,
                top: 347,
                height: 60,
                borderRadius: 16,
                backgroundColor: 'rgba(255,255,255,0.07)',
                boxShadow: '0 0 0 1px rgba(255,255,255,0.22)',
                flexDirection: 'row',
                alignItems: 'center',
                paddingLeft: 22,
                paddingRight: 18,
              }}>
              <TextInput
                value={email}
                onChangeText={setEmail}
                onSubmitEditing={continueWithEmail}
                autoFocus
                placeholder="yourname@email.com"
                placeholderTextColor="rgba(244,243,240,0.45)"
                selectionColor="#F4F3F0"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                textContentType="emailAddress"
                returnKeyType="done"
                style={[
                  sans('400'),
                  { flex: 1, fontSize: 17, color: '#F4F3F0', paddingVertical: 0 },
                  Platform.OS === 'web' ? ({ outlineStyle: 'none' } as object) : null,
                ]}
              />
              {email.length ? (
                <PressScale
                  onPress={() => {
                    setEmail('');
                    reset();
                  }}
                  accessibilityRole="button"
                  accessibilityLabel="Clear email"
                  hitSlop={{ top: 16, bottom: 16, left: 16, right: 16 }}
                  style={{ width: 24, height: 24, minHeight: 0 }}>
                  <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
                    <Path d="M5 5l14 14M19 5L5 19" stroke="rgba(244,243,240,0.6)" strokeWidth={2.2} strokeLinecap="round" />
                  </Svg>
                </PressScale>
              ) : null}
            </View>

            <View style={{ position: 'absolute', left: 24, right: 24, top: 411 }}>
              <AuthMessage error={error} notice={notice} />
            </View>

            <View style={{ position: 'absolute', left: 24, right: 24, top: 431 }}>
              <AuthButton label="Let's Go" onPress={continueWithEmail} />
            </View>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <>
      <StatusBar style="light" />
      <AuthSurface onBack={back}>
        {mode === 'password' ? (
          <View style={{ flex: 1, justifyContent: 'center', gap: 14 }}>
            <AppText center style={[sans('500'), { fontSize: 22, lineHeight: 29.04, letterSpacing: 0.1, color: '#F4F3F0', marginBottom: 18 }]}>Welcome back.</AppText>
            <AuthField label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
            <AuthField
              label="Password"
              value={password}
              onChangeText={setPassword}
              placeholder="Your password"
              secureTextEntry
              autoCapitalize="none"
              autoComplete="current-password"
              returnKeyType="go"
              onSubmitEditing={() => password && void submitPassword()}
            />
            <AuthMessage error={error} notice={notice} />
            <View style={{ marginTop: 10 }}>
              <AuthButton label={loading ? 'Signing in…' : 'Sign in'} disabled={loading} onPress={() => (password ? void submitPassword() : setError('Enter your password.'))} />
            </View>
          </View>
        ) : (
          <View style={{ flex: 1, justifyContent: 'center', gap: 14 }}>
            <AppText center style={[sans('500'), { fontSize: 22, lineHeight: 29.04, letterSpacing: 0.1, color: '#F4F3F0' }]}>Check your email.</AppText>
            <AppText center style={[sans('400'), { fontSize: 14.5, lineHeight: 21, color: 'rgba(244,243,240,0.6)', marginBottom: 12 }]}>A code is on its way to {email.trim()}.</AppText>
            <AuthField label="Verification code" value={code} onChangeText={setCode} keyboardType="number-pad" autoCapitalize="none" autoComplete="one-time-code" returnKeyType="go" onSubmitEditing={() => code && void submitCode()} />
            <AuthMessage error={error} notice={notice} />
            <AuthButton label={loading ? 'Checking…' : 'Verify & continue'} disabled={loading} onPress={() => (code.trim() ? void submitCode() : setError('Enter the code we sent.'))} />
            <PressScale
              onPress={async () => {
                reset();
                const result = await resendSignInCode();
                if (!result.ok) setError(result.error ?? 'Could not resend code.');
                else setNotice('Code re-sent.');
              }}
              style={{ minHeight: 44, alignItems: 'center', justifyContent: 'center' }}>
              <AppText style={[sans('500'), { fontSize: 14.5, color: 'rgba(244,243,240,0.6)' }]}>Resend code</AppText>
            </PressScale>
          </View>
        )}
      </AuthSurface>
    </>
  );
}
