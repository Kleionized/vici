import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Alert, Platform, View, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, Ellipse, FeGaussianBlur, Filter, LinearGradient as SvgLinearGradient, Path, RadialGradient, Rect, Stop } from 'react-native-svg';

import { ContactShadow, MailArrival } from '@/app/letter';
import { AppText, PressScale } from '@/components/ui';
import { useUpdateSettings } from '@/lib/backend';
import { DROP_OFFERING_ID, usePurchases } from '@/lib/purchases';
import { setJSON } from '@/lib/storage';
import { sans } from '@/lib/theme';

/**
 * The yearly drop — canvas 39C → 39D.
 *
 * The enclosure that comes with the medallion post: the whole year for one
 * payment. This drop rebuilt the offer completely. It used to be a sheet over
 * the day — grabber, twelve month blocks paying out from the laurel, a 46pt
 * price and a "Billed once" chip. It is now a board of its own on `#FAF8F3`:
 * a lamp hanging in a dotted arc, one selected price card, three things the
 * year buys, and a pill that says what the money does.
 *
 * Once it is claimed the year itself arrives as an object on the lit field —
 * the same arrival every other piece of post gets, and the one half of this
 * screen the drop did not touch.
 *
 * Canvas tops are the 852 frame's, less the 54pt status bar (D009).
 *
 * Claiming buys the year from the `drop` offering — the same yearly product at
 * the enclosure's price. A dashboard with no such offering falls back to the
 * current one, so the drop still sells the year rather than failing shut.
 */

const laurelMark = require('../../assets/images/laurel-mark.webp');

const DROP_SEEN_KEY = 'tideline.post.yearlydrop.seen';

const FULL_PRICE = '$39.99';
const DROP_PRICE = '$26.99';

/** Canvas y → the app's own y, measured from the safe-area top. */
const Y = (top: number) => top - 54;

type Phase = 'offer' | 'claimed';

export default function Drop() {
  const router = useRouter();
  const updateSettings = useUpdateSettings();
  const { purchase, restore } = usePurchases();
  const [phase, setPhase] = useState<Phase>('offer');

  const close = () => (router.canGoBack() ? router.back() : router.replace('/(app)/today'));

  const later = () => {
    void setJSON(DROP_SEEN_KEY, Date.now());
    close();
  };

  const claim = () => {
    void (async () => {
      await setJSON(DROP_SEEN_KEY, Date.now());
      const outcome = await purchase('yearly', DROP_OFFERING_ID);
      if (outcome.status === 'cancelled') return;
      if (outcome.status === 'error' || outcome.status === 'unavailable') {
        Alert.alert('The store could not complete that', outcome.message);
        return;
      }
      // Kept for the record: which price the year was taken at.
      await updateSettings({ yearlyDrop: true }).catch(() => {});
      setPhase('claimed');
    })();
  };

  /** The board's own control, top right — the enclosure is a store screen now. */
  const restorePurchases = () => {
    void (async () => {
      const outcome = await restore();
      if (outcome.status === 'restored') {
        if (outcome.entitled) {
          await setJSON(DROP_SEEN_KEY, Date.now());
          setPhase('claimed');
          return;
        }
        Alert.alert('Nothing to restore', 'This store account has no VICI purchase on it.');
        return;
      }
      if (outcome.status === 'error' || outcome.status === 'unavailable') Alert.alert('Could not restore', outcome.message);
    })();
  };

  if (phase === 'claimed') {
    return (
      <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
        <StatusBar style="dark" />
        <MailArrival
          art={<YearTile />}
          title="You received a drop."
          sub="One drop covers the year — twelve months of VICI, billed once."
          primary="Begin the year"
          secondary="See the receipt"
          onPrimary={close}
          onSecondary={() => router.replace('/subscription')}
          onClose={close}
        />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#FAF8F3' }}>
      <StatusBar style="dark" />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        {/* Yoga lays an absolute child out from its parent's border box and never
            consults padding, and the safe-area inset IS padding — so everything
            absolute hangs off this plain flex child instead. */}
        <View style={{ flex: 1 }}>
          <Offer onClaim={claim} onClose={later} onRestore={restorePurchases} />
        </View>
      </SafeAreaView>
    </View>
  );
}

/* ------------------------------------------------------ 39C · the yearly offer */

function Offer({ onClaim, onClose, onRestore }: { onClaim: () => void; onClose: () => void; onRestore: () => void }) {
  return (
    <>
      <PressScale
        onPress={onClose}
        accessibilityRole="button"
        accessibilityLabel="Close"
        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
        style={{
          position: 'absolute',
          left: 20,
          top: Y(62),
          width: 34,
          height: 34,
          minHeight: 0,
          borderRadius: 17,
          backgroundColor: '#FFFFFF',
          boxShadow: '0 0 0 1px rgba(0,0,0,0.06), 0 4px 10px rgba(40,38,32,0.08)',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Svg width={12} height={12} viewBox="0 0 12 12">
          <Path d="M1.5 1.5l9 9M10.5 1.5l-9 9" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" />
        </Svg>
      </PressScale>

      <PressScale
        onPress={onRestore}
        accessibilityRole="button"
        hitSlop={{ top: 14, bottom: 14, left: 20, right: 20 }}
        style={{ position: 'absolute', right: 24, top: Y(70), minHeight: 0 }}>
        <AppText style={[sans('400'), { fontSize: 15, color: '#55534E' }]}>Restore</AppText>
      </PressScale>

      {/* the canvas breaks this title itself; no wrapping rule is stated on it */}
      <AppText
        center
        style={[sans('600'), { position: 'absolute', left: 24, right: 24, top: Y(126), fontSize: 26, lineHeight: 32, letterSpacing: -0.4, color: '#1D1C1A' }]}>
        {'One decision.\nA year of change.'}
      </AppText>
      <AppText center style={[sans('400'), { position: 'absolute', left: 40, right: 40, top: Y(200), fontSize: 13.5, lineHeight: 20, color: '#55534E' }]}>
        Unlock everything VICI has to offer for an entire year.
      </AppText>

      <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: Y(232), height: 230 }}>
        <Lamp />
      </View>

      <PriceCard />

      <Perks />

      <PressScale
        onPress={onClaim}
        accessibilityRole="button"
        style={{
          position: 'absolute',
          left: 20,
          right: 20,
          top: Y(748),
          height: 56,
          minHeight: 0,
          borderRadius: 28,
          backgroundColor: '#131313',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <AppText style={[sans('600'), { fontSize: 16.5, letterSpacing: 0.2, color: '#FFFFFF' }]}>Unlock my year</AppText>
        <Svg width={18} height={14} viewBox="0 0 18 14" style={{ position: 'absolute', right: 24 }}>
          <Path d="M1 7h15M10 1.5L16.5 7 10 12.5" fill="none" stroke="#FFFFFF" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      </PressScale>

      {/* The frame marks the close, the Restore line and the pill with
          `cursor: pointer` and marks this line with none — the same evidence
          D013 read on the login board's "Terms · Privacy". It is a caption. */}
      <AppText center style={[sans('400'), { position: 'absolute', left: 0, right: 0, top: Y(816), fontSize: 11.5, color: '#8B8882' }]}>
        Terms · Restore
      </AppText>
    </>
  );
}

/**
 * The lamp: a dark disc hung on a beam over a lit floor, inside a 44-dot arc.
 *
 * The canvas draws the whole thing in one 393 × 230 SVG and then shrinks it
 * with `transform: scale(0.82)` about its own centre, so the drawing keeps the
 * coordinates it was authored at and the board gets the smaller picture. RN
 * scales about a view's centre by default, which is the same 50% 50%.
 */
function Lamp() {
  return (
    <Svg width={393} height={230} viewBox="0 0 393 230" style={{ position: 'absolute', left: 0, top: 0, transform: [{ scale: 0.82 }] }}>
      <Defs>
        <RadialGradient id="ydGlow" cx="50%" cy="50%" r="50%" rx="50%" ry="50%">
          <Stop offset="0" stopColor="#F2D08E" stopOpacity={0.5} />
          <Stop offset="0.55" stopColor="#F2D08E" stopOpacity={0.12} />
          <Stop offset="1" stopColor="#F2D08E" stopOpacity={0} />
        </RadialGradient>
        <SvgLinearGradient id="ydBeam" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor="#F2D08E" stopOpacity={0} />
          <Stop offset="1" stopColor="#F2D08E" stopOpacity={0.9} />
        </SvgLinearGradient>
        <RadialGradient id="ydFloor" cx="50%" cy="50%" r="50%" rx="50%" ry="50%">
          <Stop offset="0" stopColor="#FFF4D6" stopOpacity={0.95} />
          <Stop offset="0.6" stopColor="#F2D08E" stopOpacity={0.25} />
          <Stop offset="1" stopColor="#F2D08E" stopOpacity={0} />
        </RadialGradient>
        <RadialGradient id="ydDisc" cx="42%" cy="36%" r="70%" rx="70%" ry="70%">
          <Stop offset="0" stopColor="#3A3833" />
          <Stop offset="1" stopColor="#151412" />
        </RadialGradient>
        {/* `filter: blur(4px)` on the contact shadow — a CSS blur radius IS the
            standard deviation, unlike a box-shadow's, which is two of them */}
        <Filter id="ydSoft4" x="-100%" y="-100%" width="300%" height="300%">
          <FeGaussianBlur stdDeviation="4" />
        </Filter>
        {/* the disc's own `drop-shadow(0 10px 18px rgba(40,38,32,0.28))`: an
            opaque circle's drop shadow is that circle again, offset and blurred,
            and 18 of CSS blur is σ 9 */}
        <Filter id="ydSoft9" x="-100%" y="-100%" width="300%" height="300%">
          <FeGaussianBlur stdDeviation="9" />
        </Filter>
      </Defs>

      {ARC.map(([cx, cy, opacity], i) => (
        <Circle key={i} cx={cx} cy={cy} r={1.1} fill="#D9B878" opacity={opacity} />
      ))}

      <Circle cx={196} cy={128} r={110} fill="url(#ydGlow)" />
      <Rect x={195} y={4} width={2} height={90} fill="url(#ydBeam)" />
      <Ellipse cx={196} cy={198} rx={150} ry={18} fill="url(#ydFloor)" />
      <Ellipse cx={196} cy={198} rx={132} ry={14} fill="none" stroke="rgba(217,184,120,0.35)" strokeWidth={1} />
      <Ellipse cx={196} cy={198} rx={96} ry={10} fill="none" stroke="rgba(217,184,120,0.45)" strokeWidth={1} />
      <Ellipse cx={196} cy={198} rx={58} ry={6} fill="none" stroke="rgba(217,184,120,0.55)" strokeWidth={1} />
      <Ellipse cx={196} cy={184} rx={44} ry={6} fill="rgba(0,0,0,0.14)" filter="url(#ydSoft4)" />
      <Circle cx={196} cy={138} r={46} fill="rgba(40,38,32,0.28)" filter="url(#ydSoft9)" />
      <Circle cx={196} cy={128} r={46} fill="url(#ydDisc)" />
      <Circle cx={196} cy={128} r={46} fill="none" stroke="rgba(226,186,120,0.35)" strokeWidth={1} />
      <Path
        d="M196 128 C190 120 182 118 178 122 C172 128 178 136 184 134 C190 132 194 128 196 128 C198 128 202 132 208 134 C214 136 220 128 214 122 C210 118 202 120 196 128 Z"
        fill="none"
        stroke="#E2BA78"
        strokeWidth={2.6}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  );
}

/**
 * The 44 dots of the arc, as the canvas states them.
 *
 * They are a half circle of radius 118 about (196, 150) swept from the left in
 * 43 equal steps, with the opacity riding the same angle — `0.30 + 0.45 sin a`,
 * dimmest at the two ends. Generated rather than listed because the formula
 * reproduces all 132 of the frame's own numbers at its own rounding, checked
 * against the frame; a hand-copied table of 44 rows would not stay checkable.
 */
const ARC: [number, number, number][] = Array.from({ length: 44 }, (_, i) => {
  const a = Math.PI * (1 - i / 43);
  return [
    Number((196 + 118 * Math.cos(a)).toFixed(1)),
    Number((150 - 118 * Math.sin(a)).toFixed(1)),
    Number((0.3 + 0.45 * Math.sin(a)).toFixed(2)),
  ];
});

/** 39C's one plan row: white, ringed in gold, already chosen. */
function PriceCard() {
  return (
    <View
      style={{
        position: 'absolute',
        left: 20,
        right: 20,
        top: Y(472),
        height: 104,
        borderRadius: 22,
        backgroundColor: '#FFFFFF',
        boxShadow: '0 0 0 1.4px #D9B878, 0 10px 28px rgba(40,38,32,0.08)',
      }}>
      <View
        style={{
          position: 'absolute',
          right: 18,
          top: 16,
          height: 22,
          paddingHorizontal: 10,
          borderRadius: 11,
          backgroundColor: '#EBD8AE',
          justifyContent: 'center',
        }}>
        <AppText style={[sans('700'), { fontSize: 10.5, letterSpacing: 0.5, color: '#3A2E15' }]}>SAVE 74%</AppText>
      </View>

      <View
        style={{
          position: 'absolute',
          left: 22,
          top: 32,
          width: 26,
          height: 26,
          borderRadius: 13,
          backgroundColor: '#131313',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Svg width={13} height={10} viewBox="0 0 16 12">
          <Path d="M1.5 6l4.4 4.5L14.5 1.5" fill="none" stroke="#FFFFFF" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      </View>

      <AppText style={[sans('600'), { position: 'absolute', left: 66, top: 34, fontSize: 16, color: '#1D1C1A' }]}>Yearly Access</AppText>

      <View style={{ position: 'absolute', right: 22, top: 40, alignItems: 'flex-end' }}>
        <AppText style={[sans('500'), { fontSize: 12, color: '#A5A29B', textDecorationLine: 'line-through' }]}>{FULL_PRICE}</AppText>
        <AppText style={[sans('600'), { fontSize: 18, letterSpacing: -0.3, color: '#1D1C1A' }]}>{DROP_PRICE}</AppText>
        <AppText style={[sans('400'), { fontSize: 12, color: '#8B8882' }]}>/year</AppText>
      </View>

      <AppText style={[sans('400'), { position: 'absolute', left: 66, bottom: 18, fontSize: 12.5, color: '#8B8882' }]}>That&rsquo;s $2.25 a month.</AppText>
    </View>
  );
}

/** Three things the year buys, on two hairlines. */
function Perks() {
  return (
    <View style={{ position: 'absolute', left: 20, right: 20, top: Y(622), flexDirection: 'row', gap: 8 }}>
      <Perk lines={['Full 12-week', 'programme']}>
        <Rect x={7} y={12} width={14} height={11} rx={2.5} fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M10 12V9a4 4 0 0 1 8 0v3" fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Circle cx={14} cy={17.5} r={1.2} fill="#1D1C1A" />
      </Perk>
      <Rule />
      <Perk lines={['SOS support', 'anytime']}>
        <Circle cx={14} cy={14} r={9.5} fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Circle cx={14} cy={14} r={3.5} fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M14 4.5v6M14 17.5v6M4.5 14h6M17.5 14h6" fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      </Perk>
      <Rule />
      <Perk lines={['Track your', 'progress']}>
        <Path d="M5 23h18" fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M8 20v-5M13 20v-8M18 20v-11" fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M7 11l5-4 4 2 6-6" fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
        <Path d="M19 3h3v3" fill="none" stroke="#1D1C1A" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      </Perk>
    </View>
  );
}

function Perk({ lines, children }: { lines: [string, string]; children: React.ReactNode }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', gap: 10 }}>
      <Svg width={28} height={28} viewBox="0 0 28 28">{children}</Svg>
      <AppText center style={[sans('500'), { fontSize: 12, lineHeight: 15, color: '#1D1C1A' }]}>
        {lines[0]}
        {'\n'}
        {lines[1]}
      </AppText>
    </View>
  );
}

function Rule() {
  return <View style={{ width: 1, height: 64, backgroundColor: 'rgba(0,0,0,0.08)', alignSelf: 'center' }} />;
}

/* --------------------------------------------------------- 39D · the year, in */

/**
 * The year as an object: an ink tile, tilted, with the mark inverted on it.
 * Same 260 × 260 frame, same light and contact shadow as the medallion.
 */
function YearTile() {
  return (
    <>
      {/* the light is a `closest-side` radial and needs no filter (D010); the
          shadow is a flat ellipse and takes the canvas's own 6px blur */}
      <Svg width={200} height={200} style={{ position: 'absolute', left: 30, top: 20 }}>
        <Defs>
          <RadialGradient id="year-glow" cx="50%" cy="50%" r="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.55} />
            <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={100} cy={100} rx={100} ry={100} fill="url(#year-glow)" />
      </Svg>
      <ContactShadow left={52} top={230} width={156} height={16} fill="rgba(0,0,0,0.11)" />

      <View
        style={{
          position: 'absolute',
          left: 62,
          top: 52,
          width: 136,
          height: 136,
          borderRadius: 32,
          backgroundColor: '#131313',
          boxShadow: 'inset 0 0 0 1.5px rgba(244,243,240,0.14), 0 14px 30px rgba(30,28,24,0.35)',
          transform: [{ rotate: '-3deg' }],
          alignItems: 'center',
          justifyContent: 'center',
          gap: 10,
        }}>
        {/* `invert(1) brightness(1.6)` is not a tint: the invert turns the dark
            mark light and the 1.6 then clips its mid-tones to white, which
            thickens the stroke where a tint would only recolour the ramp. RN
            0.85 *parses* a CSS filter string on all three platforms, so the
            canvas's own filter is stated rather than approximated (D137). RN
            declares `filter` on `ViewStyle` and not on `ImageStyle`, so it is
            stated on a wrapper of the image's own size.
            iOS does not *render* it. `RCTViewComponentView`'s filter block has
            no `FilterType::Invert` branch at all — the enum carries Invert and
            Sepia, the view implements neither — and every other function except
            `brightness`/`opacity` is behind `enableSwiftUIBasedFilters`, which
            defaults to false. So on device `invert(1)` is dropped and
            `brightness(1.6)` lands as a multiply layer of clamped white, i.e.
            nothing: the dark mark stays dark on the #131313 tile and the laurel
            disappears. Web keeps the canvas's own filter — that is what the
            capture measures — and device gets the nearest thing the platform
            draws, the white template tint the other four laurels already use. */}
        <View style={[{ width: 58, height: 58 }, Platform.OS === 'web' ? ({ filter: 'invert(1) brightness(1.6)' } as ViewStyle) : null]}>
          <Image
            source={laurelMark}
            contentFit="contain"
            tintColor={Platform.OS === 'web' ? undefined : '#FFFFFF'}
            style={{ width: 58, height: 58 }}
          />
        </View>
        <AppText style={[sans('600'), { fontSize: 12, letterSpacing: 2.5, color: 'rgba(244,243,240,0.65)', marginRight: -2.5 }]}>THE YEAR</AppText>
      </View>
    </>
  );
}
