import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useId, useState } from 'react';
import { Platform, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';

import { AppText, BackGlyph, Grain, PressScale } from '@/components/ui';
import { useCurrentUser, useJournalEntries } from '@/lib/backend';
import { fonts, sans } from '@/lib/theme';

/**
 * 92C · Your vow — the line you signed on night zero, kept where you can find
 * it again, with the signature under it and how long it has held.
 *
 * Canvas tops include the 54pt status bar the app never builds, so every number
 * below is the canvas value less 54; the ones anchored to the card's own bottom
 * are card-local and carry over unchanged.
 */

const noiseDark = require('../../assets/images/noise-dark.png');

/* The vow line is the one run on this page the canvas gives a `text-wrap`, and it
   asks for `balance`; AppText's web default is `pretty`, which lets the first line
   run 27pt wider than the frame's. */
const BALANCE = Platform.OS === 'web' ? ({ textWrap: 'balance' } as object) : null;

/** The line the canvas draws when nothing has been signed yet. */
const PLACEHOLDER = 'I’m done letting the wave decide. One evening at a time, I take the watch back.';

export default function Vow() {
  const router = useRouter();
  const user = useCurrentUser();
  const journal = useJournalEntries();
  const id = useId().replace(/:/g, '');
  // Read once on mount so the day count cannot move while the page is open.
  const [now] = useState(() => Date.now());

  const vow = (journal ?? []).find((entry) => entry.tag === 'Vow') ?? (journal ?? []).find((entry) => entry.tag === 'Pledge');
  const signedAt = vow?.createdAt ?? user?.createdAt;
  const held = signedAt ? Math.max(0, Math.floor((now - signedAt) / 86_400_000)) : 0;
  const name = user?.displayName?.split(' ')[0] ?? 'You';
  // `The Vow` dates the same block `Jun 9 · Day 0` — month and day, no year —
  // and this page is that block kept, so it carries the signing date in the same
  // hand. `Your Vow Page` draws the slot empty, which is the sample being blank,
  // not the slot being unused: `The-Vow.html` fills the identical div (D119).
  //
  // The day is the account's own age on the day the vow was signed, not a
  // literal 0. Signed during onboarding it is 0, which is what `The Vow` draws;
  // re-signed after a relapse — the line at the foot of this page says that
  // happens — it is the day it was re-signed on, so the stamp can no longer read
  // `Day 0` directly above `Held for 35 days.`
  const signedOnDay = signedAt && user ? Math.max(0, Math.floor((signedAt - user.createdAt) / 86_400_000)) : 0;
  const stamp = signedAt
    ? `${new Date(signedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} · Day ${signedOnDay}`
    : 'Not signed yet';

  return (
    <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
      <StatusBar style="dark" />
      <Grain source={noiseDark} opacity={0.07} />

      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        {/* Yoga positions an absolute child against its parent's border box and
          ignores the padding SafeAreaView spends the inset with, so absolute
          children of the SafeAreaView itself sit at the top of the screen
          rather than below the notch. One plain View deeper restores it. */}
        <View style={{ flex: 1 }}>
          {/* canvas 64 — the way back reads "Settings", not "Back" */}
          <PressScale
            onPress={() => (router.canGoBack() ? router.back() : router.replace('/(app)/settings'))}
            accessibilityRole="button"
            accessibilityLabel="Settings"
            hitSlop={{ top: 16, bottom: 16, left: 16, right: 24 }}
            style={{ position: 'absolute', left: 16, top: 10, minHeight: 0, flexDirection: 'row', alignItems: 'center', gap: 9, zIndex: 5 }}>
            <BackGlyph color="#55534E" />
            <AppText style={[sans('400'), { fontSize: 17, color: '#55534E' }]}>Settings</AppText>
          </PressScale>

          {/* canvas 114 */}
          <AppText numberOfLines={1} style={[sans('600'), { position: 'absolute', left: 16, right: 16, top: 60, fontSize: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>
            Your vow
          </AppText>

          {/* canvas 168 / 196 — a 170pt halo with the 46pt sun sitting inside it */}
          <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 114, alignItems: 'center' }}>
            <Svg width={170} height={170}>
              <Defs>
                {/* `r`, not `rx`/`ry`: on web `prepare()` forwards props straight to the
                    DOM, and `rx`/`ry` are not `<radialGradient>` attributes, so the
                    browser falls back to r = 50% and the fill comes out flat. Native
                    maps `rx = rx || r`, so one `r` is right on both. */}
                <RadialGradient id={`halo${id}`} cx="85" cy="85" r="85" gradientUnits="userSpaceOnUse">
                  <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.38} />
                  <Stop offset="0.72" stopColor="#E2BA78" stopOpacity={0} />
                </RadialGradient>
                {/* `radial-gradient(circle at 50% 38%, …)` names no size, so CSS
                    uses farthest-corner: from (50%, 38%) of a 46px box that is
                    √(23² + 28.52²) = 36.66, which is 159.4% of the box's half.
                    In user space the box runs y 28 → 74, so 38% of it is 45.48 —
                    the focus is above the disc's centre, not below it. */}
                <RadialGradient id={`sun${id}`} cx="85" cy="45.48" r="36.66" gradientUnits="userSpaceOnUse">
                  <Stop offset="0" stopColor="#F8E9CB" />
                  <Stop offset="0.7" stopColor="#EFD3A2" />
                  <Stop offset="1" stopColor="#E3BE85" />
                </RadialGradient>
              </Defs>
              <Circle cx={85} cy={85} r={85} fill={`url(#halo${id})`} />
              <Circle cx={85} cy={51} r={23} fill={`url(#sun${id})`} />
            </Svg>
            {/* the disc's own `box-shadow: 0 6px 18px rgba(226,186,120,0.45)`, which
                cannot ride on a circle inside the Svg. It is absolute, so the
                container's `alignItems: center` does not reach it — the canvas's
                own `left:50%; margin-left:-23` has to be written out, or the glow
                lands 111pt to the left of the sun it belongs to. */}
            <View
              pointerEvents="none"
              style={{ position: 'absolute', left: '50%', marginLeft: -23, top: 28, width: 46, height: 46, borderRadius: 23, boxShadow: '0 6px 18px rgba(226,186,120,0.45)' }}
            />
          </View>

          {/* canvas 296 — the vow itself, set in the serif the pledge uses */}
          <AppText
            center
            style={[{ position: 'absolute', left: 40, right: 40, top: 242, fontFamily: fonts.quote, fontSize: 20, lineHeight: 32, color: '#1D1C1A' }, BALANCE]}>
            {vow?.body ?? PLACEHOLDER}
          </AppText>

          {/* canvas 466 — the signature block. This drop deleted the white card
              that used to hold it (the 18-radius panel, the SIGNATURE eyebrow, the
              drawn squiggle and the two corner captions) and replaced it with the
              name typeset in a signing hand straight on the page. The same block
              is what `The Vow` signs on, so the two now agree line for line. */}
          <View style={{ position: 'absolute', left: 36, right: 36, top: 412, height: 142 }}>
            <View style={{ position: 'absolute', left: 0, right: 0, top: 34, alignItems: 'center' }}>
              <AppText style={{ fontFamily: fonts.script, fontSize: 44, lineHeight: 44, color: '#1D1C1A', transform: [{ rotate: '-3deg' }] }}>{name}</AppText>
            </View>
            <AppText style={[sans('400'), { position: 'absolute', left: 14, bottom: 44, fontSize: 14, color: '#B0AEA8' }]}>×</AppText>
            <View style={{ position: 'absolute', left: 12, right: 12, bottom: 40, height: 1.5, backgroundColor: 'rgba(0,0,0,0.24)' }} />
            <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, bottom: 14, fontSize: 12, color: '#B0AEA8' }]}>{stamp}</AppText>
          </View>

          {/* canvas 648 and 692 */}
          <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, top: 594, fontSize: 13, color: '#8B8882' }]}>
            {`Held for ${held} ${held === 1 ? 'day' : 'days'}.`}
          </AppText>
          <AppText center style={[sans('400'), { position: 'absolute', left: 36, right: 36, top: 638, fontSize: 13, lineHeight: 19, color: '#8B8882' }]}>
            After a relapse you can re-sign the vow. It resets the promise, never the progress.
          </AppText>
        </View>
      </SafeAreaView>
    </View>
  );
}
