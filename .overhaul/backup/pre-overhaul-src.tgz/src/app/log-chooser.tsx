import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import type { ReactNode } from 'react';
import { useState } from 'react';
import { View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Ellipse, Path } from 'react-native-svg';

import { Halo, ramp150, SunDisc } from '@/app/(app)/log';
import { AppText, Grain, Hill, PressScale } from '@/components/ui';
import { colors, sans } from '@/lib/theme';

/**
 * 90 · Log — Chooser. Three illustrated cards ask WHAT you are capturing and one
 * pill sends you there; the close X uncovers the log itself (91 / 91-2 / 91-3).
 *
 * It lives OUTSIDE `(app)` on purpose. Frame 90 draws no tab bar and puts its
 * pill at 744 — 50 off the frame's own bottom edge — while 91 and its two
 * siblings draw the bar from 769 with `Log` active. Both cannot be the Log tab's
 * root: inside the group the bar claims 83pt and the pill lands at 711, which is
 * the 33pt miss FINDINGS F17 was raised for. So the chooser is a route of its
 * own and `/(app)/log` is the register list the bar belongs to (D124).
 */

const noiseDark = require('../../assets/images/noise-dark.png');

/** The one ink the marks are drawn in, straight off the canvas. */
const INK = '#131313';

/** The chooser's three cards: 281 × 150 on the canvas, `left:56 right:56`. */
const CARD_W = 281;
const CARD_H = 150;
const CARD_TOP = [146, 320, 494];

/** 90's morning: a hill, a haloed sun rising over it. */
function CheckinScene() {
  return (
    <>
      <Hill height={CARD_H - 76} rise={30} color="rgba(255,255,255,0.38)" style={{ position: 'absolute', left: -24, right: -24, top: 76 }} />
      <Halo size={74} color="#E2BA78" alpha={0.42} stop={0.72} style={{ left: '50%', top: 14, marginLeft: -37 }} />
      <SunDisc size={30} ring={5} style={{ left: '50%', top: 36, marginLeft: -15 }} />
    </>
  );
}

/** 90's urge: a young plant in a pot, one leaf still gold. */
function UrgeScene() {
  return (
    <>
      <Hill height={CARD_H - 76} rise={30} color="rgba(255,255,255,0.34)" style={{ position: 'absolute', left: -24, right: -24, top: 76 }} />
      <Svg width={60} height={52} viewBox="0 0 60 52" style={{ position: 'absolute', left: '50%', top: 18, marginLeft: -30 }}>
        <Path d="M30 50 C30 40 30 30 30 20" fill="none" stroke="#3A3934" strokeWidth={2.2} strokeLinecap="round" />
        <Path d="M30 34 C24 32 19 27 18 20 C25 21 29 25 30 31" fill="#3A3934" />
        <Path d="M30 28 C36 26 41 21 42 14 C35 15 31 19 30 25" fill="#3A3934" />
        <Path d="M30 20 C29 12 32 6 38 4 C38 11 35 17 30 20" fill="#D9A95C" />
      </Svg>
      <View style={{ position: 'absolute', left: '50%', top: 66, width: 40, height: 8, marginLeft: -20, borderRadius: 3, backgroundColor: '#FFFFFF', boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.05)' }} />
      <LinearGradient
        colors={['#FFFFFF', '#F0EDE6']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={{
          position: 'absolute',
          left: '50%',
          top: 74,
          width: 32,
          height: 20,
          marginLeft: -16,
          borderTopLeftRadius: 2,
          borderTopRightRadius: 2,
          borderBottomLeftRadius: 9,
          borderBottomRightRadius: 9,
          boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.05)',
        }}
      />
      <GroundEllipse w={42} h={6} color="rgba(58,57,52,0.11)" style={{ left: '50%', top: 95, marginLeft: -21 }} />
    </>
  );
}

/**
 * A `border-radius: 50%` box that is wider than it is tall is a true ellipse, and
 * Yoga's single-number radius can only make a stadium out of it — so the canvas's
 * ground shadows are drawn as ellipses instead of clipped boxes.
 */
function GroundEllipse({ w, h, color, style }: { w: number; h: number; color: string; style: object }) {
  return (
    <Svg width={w} height={h} style={[{ position: 'absolute' }, style]}>
      <Ellipse cx={w / 2} cy={h / 2} rx={w / 2} ry={h / 2} fill={color} />
    </Svg>
  );
}

/** 90's lapse: a night sky, three stars, a crescent over a lit horizon. */
function LapseScene() {
  return (
    <>
      <Hill height={CARD_H - 80} rise={28} color="rgba(244,243,240,0.10)" style={{ position: 'absolute', left: -24, right: -24, top: 80 }} />
      <View style={{ position: 'absolute', left: 74, top: 26, width: 2, height: 2, borderRadius: 1, backgroundColor: 'rgba(244,243,240,0.55)' }} />
      <View style={{ position: 'absolute', left: 196, top: 20, width: 1.6, height: 1.6, borderRadius: 0.8, backgroundColor: 'rgba(244,243,240,0.4)' }} />
      <View style={{ position: 'absolute', left: 110, top: 52, width: 1.6, height: 1.6, borderRadius: 0.8, backgroundColor: 'rgba(244,243,240,0.35)' }} />
      <Halo size={64} color="#E9C687" alpha={0.2} stop={0.74} style={{ left: '50%', top: 16, marginLeft: -32 }} />
      <Svg width={30} height={30} viewBox="0 0 24 24" style={{ position: 'absolute', left: '50%', top: 32, marginLeft: -15 }}>
        <Path d="M14.5 3.6 A8.8 8.8 0 1 0 20.9 12.8 A7 7 0 0 1 14.5 3.6Z" fill="#E9C687" />
      </Svg>
      {/* the canvas rotates this cloud about its own centre, which is what a bare
          `transform: rotate` does in Yoga too */}
      <View style={{ position: 'absolute', left: '50%', top: 88, width: 26, height: 8, marginLeft: -30, borderRadius: 3, backgroundColor: 'rgba(244,243,240,0.5)', transform: [{ rotate: '-14deg' }] }} />
      <GroundEllipse w={44} h={6} color="rgba(0,0,0,0.35)" style={{ left: '50%', top: 96, marginLeft: -26 }} />
    </>
  );
}

type ChooserOption = { key: string; scene: ReactNode; title: string; dark?: boolean; route: string };

const OPTIONS: ChooserOption[] = [
  { key: 'checkin', scene: <CheckinScene />, title: 'Daily check-in', route: '/checkin' },
  { key: 'urge', scene: <UrgeScene />, title: 'An urge', route: '/urge-log' },
  { key: 'lapse', scene: <LapseScene />, title: 'A lapse', dark: true, route: '/lapse' },
];

const CHOOSER_RAMP = ramp150(CARD_W, CARD_H);

/**
 * One card. The chosen one wears a 26pt ink pip ringed in paper; the rest carry
 * an empty 24pt ring drawn in whichever ink reads against their own ground.
 */
function ChooserCard({ option, top, selected, onPress }: { option: ChooserOption; top: number; selected: boolean; onPress: () => void }) {
  const dark = option.dark === true;
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityLabel={option.title}
      accessibilityState={{ checked: selected }}
      style={{
        position: 'absolute',
        left: 56,
        right: 56,
        top,
        height: CARD_H,
        borderRadius: 20,
        overflow: 'hidden',
        boxShadow: dark ? '0 10px 24px rgba(19,19,17,0.25)' : 'inset 0 0 0 1px rgba(0,0,0,0.05)',
      }}>
      <LinearGradient
        colors={dark ? ['#33322D', '#131311'] : option.key === 'urge' ? ['#EDE6D8', '#D5CAB4'] : ['#E9E8E3', '#C9C8C1']}
        start={CHOOSER_RAMP.start}
        end={CHOOSER_RAMP.end}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />
      {option.scene}
      <AppText style={[sans('500'), { position: 'absolute', left: 18, bottom: 16, fontSize: 16.5, color: dark ? '#F4F3F0' : '#1D1C1A' }]}>
        {option.title}
      </AppText>
      {selected ? (
        <View
          style={{
            position: 'absolute',
            right: 16,
            bottom: 13,
            width: 26,
            height: 26,
            borderRadius: 13,
            backgroundColor: INK,
            boxShadow: '0 0 0 2px rgba(244,243,240,0.9)',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Svg width={12} height={10} viewBox="0 0 14 12">
            <Path d="M2 6.5L5.5 10L12 2.5" fill="none" stroke="#F4F3F0" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        </View>
      ) : (
        <View
          style={{
            position: 'absolute',
            right: 16,
            bottom: 14,
            width: 24,
            height: 24,
            borderRadius: 12,
            boxShadow: dark ? 'inset 0 0 0 2px rgba(244,243,240,0.35)' : 'inset 0 0 0 2px rgba(0,0,0,0.20)',
          }}
        />
      )}
    </PressScale>
  );
}

export default function LogChooser() {
  const router = useRouter();
  const [picked, setPicked] = useState(0);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Grain source={noiseDark} opacity={0.07} />
      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <PressScale
            onPress={() => router.navigate('/(app)/log')}
            accessibilityRole="button"
            accessibilityLabel="Open log history"
            hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}
            style={{ position: 'absolute', right: 20, top: 12, minHeight: 0 }}>
            <Svg width={18} height={18} viewBox="0 0 18 18">
              <Path d="M3 3l12 12M15 3L3 15" fill="none" stroke="#1D1C1A" strokeWidth={2.2} strokeLinecap="round" />
            </Svg>
          </PressScale>

          <AppText center style={[sans('500'), { position: 'absolute', left: 30, right: 30, top: 64, fontSize: 22, lineHeight: 29, color: '#2A2924' }]}>
            What are you logging?
          </AppText>

          {OPTIONS.map((option, index) => (
            <ChooserCard key={option.key} option={option} top={CARD_TOP[index]} selected={picked === index} onPress={() => setPicked(index)} />
          ))}

          <PressScale
            onPress={() => router.push(OPTIONS[picked].route as never)}
            accessibilityRole="button"
            style={{
              position: 'absolute',
              left: 24,
              right: 24,
              bottom: 50,
              height: 58,
              minHeight: 0,
              borderRadius: 29,
              backgroundColor: INK,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: '#FFFFFF' }]}>Continue</AppText>
          </PressScale>
        </View>
      </SafeAreaView>
    </View>
  );
}
