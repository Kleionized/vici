import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { type ReactNode, useId, useMemo, useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Defs, Line, LinearGradient as SvgLinearGradient, Path, Rect, Stop } from 'react-native-svg';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

import { AppText, Grain, Hill, LoadingView, PressScale } from '@/components/ui';
import { Halo, LogRow, OUTCOME_WORD, ramp150, SunDisc, TriggerGlyph } from '@/app/(app)/log';
import { useCheckins, useCurrentUser, useEvents, useLessonProgressMap } from '@/lib/backend';
import { SCORE_BASE, SCORE_WEIGHTS } from '@/lib/score';
import { colors, sans } from '@/lib/theme';
import type { DailyCheckin, TidelineEvent } from '@/lib/types';
import { buildWeeklyReport, hasReportContent, latestCompletedWeek, severityWord } from '@/lib/weeklyReport';

/**
 * 031–033 · Weekly report — three pages behind one standing header.
 *
 * The header never changes as you swipe: the week, the counts, the lamp on the
 * desk. What changes underneath is which question the week is answering — where
 * the score went, which days held, and what the urges were. Every page closes on
 * the same white card, so the week always ends on a sentence.
 *
 * Laid out from the canvas's 393 × 852 frame: the status bar ends at 54, so
 * every `top` below is the canvas y minus 54.
 */

const noiseDark = require('../../assets/images/noise-dark.png');

const DAY_MS = 86_400_000;
const DOW = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const DAY_NAME = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const COUNT_WORD = ['No', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven'];

/**
 * The four tones the canvas draws a week in, weakest to strongest. Mood runs on
 * five steps, so Fine and Good share the mid tone rather than inventing a fifth
 * colour the design never states.
 */
const DAY_TONES = ['#CDC9BD', '#A9A597', '#767267', '#131313'];
const MOOD_TONE = [0, 1, 2, 2, 3];

/** Round values the score axis is allowed to step by — the canvas's own is 20. */
const NICE_STEPS = [10, 20, 25, 50, 100, 200, 250, 500, 1000];

export default function WeeklyReport() {
  const router = useRouter();
  // `Settings Weekly Report` (93D) is this same board reached from Settings —
  // the only difference the canvas draws is that the back row reads "Settings".
  const { week, from } = useLocalSearchParams<{ week?: string; from?: string }>();
  const backLabel = from === 'settings' ? 'Settings' : 'Back';
  const user = useCurrentUser();
  const checkins = useCheckins();
  const events = useEvents();
  const progress = useLessonProgressMap();
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [page, setPage] = useState(0);

  const weekStart = week || (user ? latestCompletedWeek(user.createdAt) : null);
  const report = useMemo(
    () => (weekStart && checkins && events ? buildWeeklyReport(weekStart, checkins, events) : null),
    [weekStart, checkins, events],
  );
  const back = () => (router.canGoBack() ? router.back() : router.replace('/(app)/dashboard'));

  if (checkins === undefined || events === undefined || user === undefined || progress === undefined) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        <StatusBar style="dark" />
        <LoadingView />
      </View>
    );
  }

  if (!hasReportContent(report)) {
    // Two different empty states: no week has closed yet, or one closed with
    // nothing logged in it. Only the second is reachable from the Mail list.
    const closed = report != null;
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        <StatusBar style="dark" />
        <Grain source={noiseDark} opacity={0.07} />
        <SafeAreaView edges={['top']} style={{ flex: 1 }}>
          {/* Yoga lays an absolute child out from the SafeAreaView's border box, so the inset — expressed as padding — is ignored. This plain flow child carries it. */}
          <View style={{ flex: 1 }}>
            <BackRow label={backLabel} onPress={back} />
            <AppText style={[sans('600'), { position: 'absolute', left: 24, top: 60, fontSize: 27, lineHeight: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>
              Weekly report
            </AppText>
            <AppText style={[sans('400'), { position: 'absolute', left: 24, right: 24, top: 130, fontSize: 20, lineHeight: 28, color: colors.textMuted }]}>
              {closed
                ? 'Nothing was logged that week, so the report has nothing to draw on.'
                : 'Your first week is still being written. Keep checking in; the report appears once a full week closes.'}
            </AppText>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  const startMs = new Date(`${report.weekStart}T00:00:00`).getTime();
  const createdAt = user?.createdAt ?? startMs;
  const lessonTimes = Object.values(progress)
    .filter((p) => p.status === 'completed')
    .map((p) => p.completedAt ?? 0);

  // The line is the running score, sampled at the end of each of the seven
  // days, with the Sunday before the week as the baseline the gain is read off.
  const base = scoreAt(startMs - 1, createdAt, checkins, events, lessonTimes);
  const values = Array.from({ length: 7 }, (_, i) => scoreAt(startMs + (i + 1) * DAY_MS - 1, createdAt, checkins, events, lessonTimes));
  const gain = Math.round(values[6] - base);

  const urges = events
    .filter((e) => (e.type === 'urge_rode_out' || e.type === 'urge_acted_on') && e.createdAt >= startMs && e.createdAt < startMs + 7 * DAY_MS)
    .sort((a, b) => a.createdAt - b.createdAt);
  const ridden = urges.filter((e) => e.type === 'urge_rode_out').length;

  const pageH = height - insets.top;

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <StatusBar style="dark" />
      <Grain source={noiseDark} opacity={0.07} />

      <SafeAreaView edges={['top']} style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            scrollEventThrottle={16}
            // D065: `react-native-web` never emits `onMomentumScrollEnd` — it forwards
            // `onScroll` plus a debounced repeat of the same handler — so the three
            // page dots stayed on the first however far the pager was swiped.
            onScroll={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / Math.max(1, width)))}
            style={{ flex: 1 }}>
            <View style={{ width, height: pageH }}>
              <ScorePage values={values} gain={gain} width={width} />
            </View>
            <View style={{ width, height: pageH }}>
              <DaysPage thisMoods={report.thisMoods} lastMoods={report.lastMoods} thisAvg={report.thisAvg} lastAvg={report.lastAvg} prev={rangeLabel(startMs - 7 * DAY_MS)} />
            </View>
            <View style={{ width, height: pageH }}>
              <UrgesPage urges={urges} ridden={ridden} relapses={report.relapses} onOpen={() => router.push(`/urge-overview?week=${report.weekStart}`)} />
            </View>
          </ScrollView>

          {/* the standing header — identical on all three pages */}
          <BackRow label={backLabel} onPress={back} />
          <AppText style={[sans('500'), { position: 'absolute', right: 20, top: 14, fontSize: 14, color: '#8B8882' }]}>{report.label}</AppText>
          <AppText style={[sans('600'), { position: 'absolute', left: 24, top: 60, fontSize: 27, lineHeight: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>
            Weekly report
          </AppText>
          <WeekStats checkins={report.checkins} urges={report.urges} relapses={report.relapses} />

          <View style={{ position: 'absolute', left: 0, right: 0, top: 630, flexDirection: 'row', justifyContent: 'center', gap: 8 }}>
            {[0, 1, 2].map((i) => (
              <View key={i} style={{ width: 7, height: 7, borderRadius: 3.5, backgroundColor: i === page ? '#131313' : 'rgba(19,19,19,0.16)' }} />
            ))}
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
}

/* ------------------------------------------------------------------- chrome */

/** Canvas y 64 — the row is only as tall as its chevron, so the target is hitSlop. */
function BackRow({ label = 'Back', onPress }: { label?: string; onPress: () => void }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={{ top: 16, bottom: 16, left: 20, right: 24 }}
      style={{ position: 'absolute', left: 16, top: 10, minHeight: 0, flexDirection: 'row', alignItems: 'center', gap: 9 }}>
      <Svg width={11} height={19} viewBox="0 0 11 19" fill="none">
        <Path d="M9.5 1.5L2 9.5l7.5 8" fill="none" stroke="#55534E" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
      </Svg>
      <AppText style={[sans('400'), { fontSize: 17, color: '#55534E' }]}>{label}</AppText>
    </PressScale>
  );
}

/**
 * The header's own card: 361 × 106 at canvas 164, three figures under a sun.
 * It replaces the desk lamp, the strapline and the three white chips the
 * previous drop drew — the counts now carry the whole top of the board.
 */
const STATS_RAMP = ramp150(361, 106);

function WeekStats({ checkins, urges, relapses }: { checkins: number; urges: number; relapses: number }) {
  const cells: [number, string][] = [
    [checkins, checkins === 1 ? 'check-in' : 'check-ins'],
    [urges, urges === 1 ? 'urge' : 'urges'],
    [relapses, relapses === 1 ? 'relapse' : 'relapses'],
  ];
  return (
    <View style={{ position: 'absolute', left: 16, right: 16, top: 110, height: 106, borderRadius: 20, overflow: 'hidden', boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.05)' }}>
      <LinearGradient
        colors={['#F1E8D6', '#D9CBAA']}
        start={STATS_RAMP.start}
        end={STATS_RAMP.end}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />
      <Hill height={40} rise={30} color="rgba(255,255,255,0.36)" style={{ position: 'absolute', left: -24, right: -24, top: 66 }} />
      <Halo size={80} color="#E2BA78" alpha={0.45} stop={0.72} style={{ right: 8, top: -18 }} />
      <SunDisc size={30} ring={5} style={{ right: 30, top: 8 }} />
      <View style={{ position: 'absolute', left: 18, right: 96, top: 0, bottom: 0, flexDirection: 'row', alignItems: 'center', gap: 16 }}>
        {cells.map(([n, label], i) => (
          <View
            key={label}
            style={{
              flex: 1,
              borderLeftWidth: i === 0 ? 0 : 1,
              borderLeftColor: 'rgba(0,0,0,0.09)',
              paddingLeft: i === 0 ? 0 : 16,
            }}>
            <AppText style={[sans('500'), { fontSize: 22, lineHeight: 22, letterSpacing: -0.2, color: '#1D1C1A' }]}>{n}</AppText>
            <AppText style={[sans('400'), { marginTop: 6, fontSize: 12, color: '#55534E' }]}>{label}</AppText>
          </View>
        ))}
      </View>
    </View>
  );
}

function SectionTitle({ children }: { children: string }) {
  return (
    <AppText style={[sans('500'), { position: 'absolute', left: 24, top: 240, fontSize: 19, letterSpacing: -0.1, color: '#1D1C1A' }]}>{children}</AppText>
  );
}

/** The white sentence the week ends on — the same box on all three pages. */
function Verdict({ glyph, title, sub, body }: { glyph: ReactNode; title: string; sub: string; body: string }) {
  return (
    <View
      style={{
        position: 'absolute',
        left: 16,
        right: 16,
        top: 538,
        height: 76,
        borderRadius: 18,
        backgroundColor: '#FFFFFF',
        boxShadow: '0 0 0 1px rgba(0,0,0,0.06), 0 10px 24px rgba(40,38,32,0.06)',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 14,
      }}>
      <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: '#131313', alignItems: 'center', justifyContent: 'center' }}>{glyph}</View>
      <View>
        <AppText style={[sans('600'), { fontSize: 13.5, color: '#1D1C1A' }]}>{title}</AppText>
        <AppText style={[sans('400'), { marginTop: 2, fontSize: 11.5, color: '#8B8882' }]}>{sub}</AppText>
      </View>
      <AppText style={[sans('400'), { flex: 1, paddingLeft: 8, fontSize: 12.5, lineHeight: 17, color: '#55534E' }]}>{body}</AppText>
    </View>
  );
}

/* --------------------------------------------------------------- 031 · score */

function ScorePage({ values, gain, width }: { values: number[]; gain: number; width: number }) {
  const id = useId().replace(/:/g, '');
  // The chart is full-bleed: its 50pt left gutter and 16pt right gutter hold on
  // any width and only the plot interior stretches, so the axis labels and the
  // day letters keep sitting under the same gridlines.
  const px = (x: number) => 50 + ((x - 50) * (width - 66)) / 327;

  const hi = Math.max(...values);
  const lo = Math.min(...values);
  // The canvas's axis is quantised — 1,240 / 1,220 / 1,200, a round 20 a
  // gridline — so the step is snapped to a round number rather than read off the
  // week's own span, and the top gridline is the first multiple of it at or
  // above the high. The smallest step that still fits the whole week between the
  // top gridline (y 30) and the floor (y 178, 148px = 2.3125 gridlines) wins; the
  // 20-point floor keeps a flat week from drawing a step of nothing.
  const range = Math.max(hi - lo, 20);
  const step = NICE_STEPS.find((s) => (s * 148) / 64 >= range && Math.ceil(hi / s) * s - lo <= (s * 148) / 64) ?? NICE_STEPS[NICE_STEPS.length - 1];
  const top = Math.ceil(hi / step) * step;
  const y = (v: number) => 30 + ((top - v) * 64) / step;
  const gridValue = (row: number) => top - row * step;

  const pts = values.map((v, i) => ({ x: px(56 + (i * (352 - 56)) / 6), y: y(v) }));
  const line = smoothPath(pts);
  const end = values[6];
  const endY = pts[6].y;

  return (
    <View style={{ flex: 1 }}>
      <SectionTitle>Recovery score</SectionTitle>

      <View
        style={{
          position: 'absolute',
          right: 24,
          top: 234,
          height: 30,
          borderRadius: 15,
          backgroundColor: '#FFFFFF',
          boxShadow: '0 0 0 1px rgba(0,0,0,0.1)',
          flexDirection: 'row',
          alignItems: 'center',
          gap: 6,
          paddingHorizontal: 12,
        }}>
        <Svg width={13} height={9} viewBox="0 0 14 10" fill="none">
          <Path d="M1 8.5L5 4.5l2.5 2L12.5 1.5" stroke="#1D1C1A" strokeWidth={1.8} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
        <AppText style={[sans('500'), { fontSize: 12, color: '#1D1C1A' }]}>{gain > 0 ? 'steady climb' : gain < 0 ? 'a dip, then back' : 'holding'}</AppText>
      </View>

      {[0, 1, 2].map((row) => (
        <AppText key={row} style={[sans('500'), { position: 'absolute', left: 16, top: 308 + row * 64, fontSize: 11.5, color: '#B0AEA8' }]}>
          {gridValue(row).toLocaleString()}
        </AppText>
      ))}

      <Svg width={width} height={220} style={{ position: 'absolute', left: 0, top: 286 }}>
        <Defs>
          <SvgLinearGradient id={`fill${id}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="rgba(19,19,19,0.10)" />
            <Stop offset="1" stopColor="rgba(19,19,19,0)" />
          </SvgLinearGradient>
        </Defs>
        <Line x1={px(50)} y1={30} x2={px(377)} y2={30} stroke="rgba(19,19,19,0.07)" strokeWidth={1} />
        <Line x1={px(50)} y1={94} x2={px(377)} y2={94} stroke="rgba(19,19,19,0.07)" strokeWidth={1} />
        <Line x1={px(50)} y1={158} x2={px(377)} y2={158} stroke="rgba(19,19,19,0.07)" strokeWidth={1} />
        {/* the canvas's dashed rule runs 16 → 195, i.e. 14 above the end dot down to the floor; it has to keep that gap wherever the week ends */}
        <Line x1={px(352)} y1={endY - 14} x2={px(352)} y2={195} stroke="rgba(19,19,19,0.14)" strokeWidth={1} strokeDasharray="3 5" />
        <Path d={`${line} L${px(352)},195 L${px(56)},195 Z`} fill={`url(#fill${id})`} />
        <Path d={line} fill="none" stroke="#131313" strokeWidth={2.4} strokeLinecap="round" />
        <Circle cx={px(352)} cy={endY} r={9} fill="#F6F5F2" stroke="rgba(19,19,19,0.22)" strokeWidth={1.5} />
        <Circle cx={px(352)} cy={endY} r={4.5} fill="#131313" />
      </Svg>

      {/* the reading, centred on the last point — the canvas's translateX(-50%).
          Its bottom sits 3 above the r9 dot (frame: pill 330→358, dot top 361),
          so it rides with the dot instead of pinning to a week that ends high. */}
      <View style={{ position: 'absolute', left: px(352) - 50, top: 286 + endY - 40, width: 100, alignItems: 'center' }}>
        <View style={{ height: 28, borderRadius: 14, backgroundColor: '#131313', justifyContent: 'center', paddingHorizontal: 12, boxShadow: '0 6px 14px rgba(19,19,19,0.22)' }}>
          <AppText style={[sans('600'), { fontSize: 12.5, color: '#FFFFFF' }]}>{Math.round(end).toLocaleString()}</AppText>
        </View>
      </View>

      <View style={{ position: 'absolute', left: 50, right: 16, top: 510, flexDirection: 'row', justifyContent: 'space-between' }}>
        {DOW.map((d, i) => (
          <AppText key={`${d}${i}`} style={[sans('500'), { fontSize: 12, color: '#8B8882' }]}>
            {d}
          </AppText>
        ))}
      </View>

      <Verdict
        glyph={
          <Svg width={16} height={11} viewBox="0 0 16 11" fill="none">
            <Path d="M1.5 9.5L6 5l3 2.5L14.5 1.5" stroke="#FFFFFF" strokeWidth={1.9} fill="none" strokeLinecap="round" strokeLinejoin="round" />
            <Path d="M10.8 1.5h3.7V5.2" stroke="#FFFFFF" strokeWidth={1.9} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        }
        title={`${gain >= 0 ? '+' : '−'}${Math.abs(gain)} points`}
        sub="this week"
        body={gain > 0 ? 'A steady climb. Keep the evenings boring.' : gain < 0 ? 'The week gave some back. One anchor at a time.' : 'A flat week. Same anchors, nothing new.'}
      />
    </View>
  );
}

/* ---------------------------------------------------------------- 032 · days */

function DaysPage({
  thisMoods,
  lastMoods,
  thisAvg,
  lastAvg,
  prev,
}: {
  thisMoods: (number | null)[];
  lastMoods: (number | null)[];
  thisAvg: number;
  lastAvg: number | null;
  prev: string;
}) {
  const steady = thisMoods.filter((m) => m != null && m >= 3).length;
  // The canvas names Friday — the row's one #131313 cell, the darkest tone and
  // so the week's strongest day. The day that tested you is the one you met, not
  // the palest well, so the sentence points at the top of the tone ramp.
  const test = thisMoods.reduce<number | null>((best, m, i) => (m == null ? best : best == null || m > (thisMoods[best] ?? -1) ? i : best), null);

  return (
    <View style={{ flex: 1 }}>
      <SectionTitle>Day by day</SectionTitle>

      <View style={{ position: 'absolute', left: 24, right: 24, top: 288, flexDirection: 'row', gap: 7 }}>
        {DOW.map((d, i) => (
          <AppText key={`${d}${i}`} center style={[sans('500'), { flex: 1, fontSize: 11, color: '#8B8882' }]}>
            {d}
          </AppText>
        ))}
      </View>

      <AppText style={[sans('500'), { position: 'absolute', left: 24, top: 320, fontSize: 12.5, color: '#8B8882' }]}>Last week</AppText>
      <WeekRow moods={lastMoods} top={344} faded />

      <AppText style={[sans('500'), { position: 'absolute', left: 24, top: 412, fontSize: 12.5, color: '#8B8882' }]}>This week</AppText>
      <WeekRow moods={thisMoods} top={436} />

      <Verdict
        glyph={
          <Svg width={15} height={15} viewBox="0 0 18 18" fill="none">
            <Rect x={1.5} y={3} width={15} height={13.5} rx={3} fill="none" stroke="#FFFFFF" strokeWidth={1.8} />
            <Path d="M5.5 1.5v3M12.5 1.5v3M1.5 7.5h15" stroke="#FFFFFF" strokeWidth={1.8} strokeLinecap="round" />
          </Svg>
        }
        title={lastAvg == null ? 'Your first week' : thisAvg >= lastAvg ? 'Stronger week' : 'A heavier week'}
        sub={`vs ${prev}`}
        body={`${COUNT_WORD[steady]} steady ${steady === 1 ? 'day' : 'days'} of seven.${test != null ? ` ${DAY_NAME[test]} was the test.` : ''}`}
      />
    </View>
  );
}

/** Seven wells of tone. A day with no check-in has no tone, so it stays empty. */
function WeekRow({ moods, top, faded = false }: { moods: (number | null)[]; top: number; faded?: boolean }) {
  return (
    <View style={{ position: 'absolute', left: 24, right: 24, top, flexDirection: 'row', gap: 7, opacity: faded ? 0.4 : 1 }}>
      {moods.map((m, i) => (
        <View
          key={i}
          style={{
            flex: 1,
            height: 44,
            borderRadius: 12,
            backgroundColor: m == null ? 'rgba(19,19,19,0.06)' : DAY_TONES[MOOD_TONE[Math.max(0, Math.min(4, Math.round(m) - 1))]],
          }}
        />
      ))}
    </View>
  );
}

/* --------------------------------------------------------------- 033 · urges */

function UrgesPage({ urges, ridden, relapses, onOpen }: { urges: TidelineEvent[]; ridden: number; relapses: number; onOpen: () => void }) {
  // Three rows is what fits above the verdict card; the rest live in the overview.
  const rows = urges.slice(0, 3);

  return (
    <View style={{ flex: 1 }}>
      <SectionTitle>This week’s urges</SectionTitle>

      {rows.length === 0 ? (
        <AppText style={[sans('400'), { position: 'absolute', left: 24, right: 24, top: 286, fontSize: 14, color: '#8B8882' }]}>No urges logged this week.</AppText>
      ) : null}

      {rows.map((e, i) => (
        <UrgeRow key={e._id} event={e} top={286 + i * 74} onPress={onOpen} />
      ))}

      <Verdict
        glyph={
          <Svg width={15} height={12} viewBox="0 0 16 13" fill="none">
            <Path d="M1.5 7l4.5 4.5L14.5 1.5" stroke="#FFFFFF" strokeWidth={2} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        }
        title={`${ridden} of ${urges.length} ridden out`}
        sub={relapses ? `${relapses} ${relapses === 1 ? 'slip' : 'slips'}` : 'no relapse'}
        body={ridden === 0 ? 'Nothing rode out this week.' : ridden === 1 ? 'The timer did its job once.' : ridden === 2 ? 'The timer did its job twice.' : `The timer did its job ${ridden} times.`}
      />
    </View>
  );
}

/**
 * 91C3 draws the log's own white slip here, so the row itself comes from the
 * Log. What stays local is the stamp: this board reads a week that has closed,
 * so every entry names its weekday — never "Today".
 */
function UrgeRow({ event, top, onPress }: { event: TidelineEvent; top: number; onPress: () => void }) {
  const trigger = event.trigger?.split(' · ')[0];
  const word = severityWord(event.severity ?? null);
  const title = [trigger, word].filter(Boolean).join(' · ') || 'Urge';
  const when = new Date(event.createdAt);
  // the canvas writes `surfed the timer` for the outcome the picker calls
  // `Surfed with the timer`, so the Log's own table supplies the word here too
  const outcome = event.whatHelped ? (OUTCOME_WORD[event.whatHelped] ?? event.whatHelped.toLowerCase()) : event.type === 'urge_acted_on' ? 'slipped' : 'rode it out';

  return (
    <View style={{ position: 'absolute', left: 16, right: 16, top }}>
      <LogRow
        mark={<TriggerGlyph trigger={trigger} />}
        title={title}
        when={`${DAY_NAME[(when.getDay() + 6) % 7]} · ${when.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }).toLowerCase()}`}
        outcome={outcome}
        onPress={onPress}
      />
    </View>
  );
}

/* -------------------------------------------------------------------- maths */

/**
 * The score as it stood at a moment, on the same weights the Today card uses —
 * the weekly line has to end on the number that screen shows.
 */
function scoreAt(at: number, createdAt: number, checkins: DailyCheckin[], events: TidelineEvent[], lessons: number[]): number {
  const days = Math.max(0, Math.floor((at - createdAt) / DAY_MS) + 1);
  const slips = events.filter((e) => e.type === 'lapse' && e.createdAt <= at).length;
  const rode = events.filter((e) => e.type === 'urge_rode_out' && e.createdAt <= at).length;
  const logged = checkins.filter((c) => new Date(`${c.date}T00:00:00`).getTime() <= at).length;
  const done = lessons.filter((t) => t <= at).length;
  return (
    SCORE_BASE +
    Math.max(0, days - slips) * SCORE_WEIGHTS.cleanDay +
    logged * SCORE_WEIGHTS.checkin +
    done * SCORE_WEIGHTS.lesson +
    rode * SCORE_WEIGHTS.urgeRidden +
    slips * SCORE_WEIGHTS.slip
  );
}

/**
 * The canvas's line is two hand-drawn cubics over sample data; the real week has
 * to draw itself, so the same curve is generated from the seven scores with
 * Catmull-Rom tangents inside the canvas's own plot box.
 */
function smoothPath(pts: { x: number; y: number }[]): string {
  const r = (n: number) => Math.round(n * 10) / 10;
  let d = `M${r(pts[0].x)},${r(pts[0].y)}`;
  for (let i = 0; i < pts.length - 1; i += 1) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    d += ` C${r(p1.x + (p2.x - p0.x) / 6)},${r(p1.y + (p2.y - p0.y) / 6)} ${r(p2.x - (p3.x - p1.x) / 6)},${r(p2.y - (p3.y - p1.y) / 6)} ${r(p2.x)},${r(p2.y)}`;
  }
  return d;
}

/** "Jul 7–13", in the same shape the report's own label uses. */
function rangeLabel(startMs: number): string {
  const a = new Date(startMs);
  const b = new Date(startMs + 6 * DAY_MS);
  const month = (d: Date) => d.toLocaleDateString('en-US', { month: 'short' });
  return a.getMonth() === b.getMonth() ? `${month(a)} ${a.getDate()}–${b.getDate()}` : `${month(a)} ${a.getDate()} – ${month(b)} ${b.getDate()}`;
}
