import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { type ReactNode, useCallback, useState } from 'react';
import { Platform, ScrollView, View, useWindowDimensions, type TextStyle, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Defs, Ellipse, FeGaussianBlur, Filter, Path, RadialGradient, Stop } from 'react-native-svg';

import { O3LetterRead } from '@/components/onboarding/handover';
import { AppText, Grain, PressScale } from '@/components/ui';
import { useCreateJournalEntry, useCurrentUser, useLifeMap } from '@/lib/backend';
import { WEEK_XII_LETTER } from '@/content/weekXiiLetter';
import { getJSON, setJSON } from '@/lib/storage';
import { cssLineHeight, sans } from '@/lib/theme';

/**
 * The post — canvas `90B · VICI Post — Arrival` and `39 · The Letter — Read`,
 * plus `37 · A Letter Arrived` on the `week12` variant.
 *
 * Every piece of post in the app arrives the same way and is read the same way,
 * so the two halves live here and the other two drops — the medallion post and
 * the yearly drop — import them rather than redraw them.
 *
 *   `MailArrival`  the object on the lit paper field, named, with a way in and
 *                  a way to leave it for later.
 *   `MailSheet`    the sheet it opens into: a rounded page over the day, with a
 *                  grabber, a close, a scrolling body and two actions.
 *
 * The canvas retired the folded-paper composition it used to draw the letter
 * with — the creases, the dimmed day behind it, the postmark ring, the separate
 * week-XII page with its finished progress bar. What is left is the sheet.
 *
 * The `week12` variant re-opens the handover's own two boards from the Log and
 * from Settings, so it draws the handover's letter rather than a second copy.
 *
 * Canvas tops below are the 393 × 852 frame's, less the 54pt status bar.
 */

const noiseDark = require('../../assets/images/noise-dark.png');

const LETTER_KEY = 'tideline.letter.day3';
const PENDING_KEY = 'tideline.letter.pending';

type Variant = 'post' | 'week12';
type Phase = 'arrive' | 'read';

const ARRIVAL: Record<Variant, { title: string; sub: string; open: string; defer: string }> = {
  post: {
    title: 'The post is in.',
    sub: 'A short letter from VICI — two minutes, worth keeping.',
    open: 'Read it',
    defer: 'Tonight',
  },
  // `Letter Received` (#43) — the same board the handover draws on the way in.
  // Both copies say what the frame says; the frame is the only authority for a
  // screen the app renders twice.
  week12: {
    title: 'A letter arrived.',
    sub: 'From you, twelve weeks from now.',
    open: 'Open it',
    defer: 'Save it for later',
  },
};

export default function LetterScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ variant?: string }>();
  const user = useCurrentUser();
  const lifeMap = useLifeMap();
  const createJournalEntry = useCreateJournalEntry();
  const [phase, setPhase] = useState<Phase>('arrive');

  const variant: Variant = params.variant === 'week12' ? 'week12' : 'post';
  const name = user?.displayName?.trim().split(/\s+/)[0] || 'friend';
  const why = lifeMap?.whyStatement?.trim() || 'I want to be present for the people I love';

  const dismiss = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace('/(app)/today');
  }, [router]);

  // Tuck it into the Log — the letter becomes a journal entry, once. The
  // week-XII letter was already written there the night it was sealed, so that
  // variant only closes.
  const keep = useCallback(() => {
    if (variant === 'week12') {
      dismiss();
      return;
    }
    void (async () => {
      const prev = await getJSON<{ kept?: boolean }>(LETTER_KEY);
      await setJSON(LETTER_KEY, { kept: true, at: Date.now() });
      await setJSON(PENDING_KEY, null);
      if (prev?.kept) return;
      const body = `Dear ${name},\n\nIf you're reading this, it happened. Good — you opened the letter instead of disappearing. That's the only door that matters this morning.\n\nOne slip is a wave, not the sea. Nothing since day zero is erased — the days stood, the urges outlasted, the reason you started: ${why}. All still yours.\n\nThe only slip that can end this is the one you answer with a second. So: water, daylight, one lesson. Don’t fail twice.\n\nI'll see you tonight, steadier.\n\n— the you who makes it out`;
      await createJournalEntry({ tag: 'Letter', title: 'Don’t fail twice', body }).catch(() => {});
    })();
    dismiss();
  }, [createJournalEntry, dismiss, name, variant, why]);

  const later = useCallback(() => {
    if (variant === 'post') void setJSON(PENDING_KEY, null);
    dismiss();
  }, [dismiss, variant]);

  const copy = ARRIVAL[variant];

  return (
    <View style={{ flex: 1, backgroundColor: phase === 'arrive' ? '#F4F3F0' : '#EDECE7' }}>
      <StatusBar style="dark" />

      {phase === 'arrive' ? (
        <MailArrival
          art={<EnvelopeArt />}
          title={copy.title}
          sub={copy.sub}
          primary={copy.open}
          secondary={copy.defer}
          onPrimary={() => setPhase('read')}
          onSecondary={later}
        />
      ) : variant === 'week12' ? (
        /* `38 · A Letter From Week XII` is drawn once, in the handover, and this
           route re-opens the same board from the Log and from Settings. It used
           to hold a second, hand-written copy of the letter — three paragraphs
           of the previous bundle's text and a pill reading "Tuck it into your
           Log" — while the frame now runs to twelve paragraphs and closes on
           "Keep this letter". Two copies of one frame do not stay equal, so
           there is one. */
        <O3LetterRead name={name} paragraphs={WEEK_XII_LETTER} onKeep={later} next={later} />
      ) : (
        <MailSheet onClose={later}>
          <LetterBody>
            <PostLetter name={name} why={why} />
          </LetterBody>
          <LetterFooter primary="Tuck it into your Log" secondary="Close" onPrimary={keep} onSecondary={later} />
        </MailSheet>
      )}
    </View>
  );
}

/* ------------------------------------------------------------- 171 · arrival */

/**
 * The arrival every drop shares: grain, two washes, the object in a 260 × 260
 * frame at canvas y 160, the name of the thing, and the two ways on.
 *
 * The canvas puts the pair of actions at y 688 / 764 of its 852 frame; they are
 * held off the bottom by the same distance instead, so a shorter phone loses
 * artwork rather than the way in.
 */
export function MailArrival({
  art,
  title,
  sub,
  primary,
  secondary,
  onPrimary,
  onSecondary,
  onClose,
  /**
   * `Medallion Received` (90F) re-cut this arrival without changing the letter's
   * or the drop's, so the pieces it moves are optional overrides and every
   * default below is still the value `Letter Arrival` and `Drop Received` draw.
   */
  field,
  halo,
  eyebrow,
  chip,
  artTop = 106,
  titleTop = 418,
  titleStyle,
  subTop = 468,
}: {
  art: ReactNode;
  title: string;
  sub: string;
  primary: string;
  /**
   * The quiet line under the pill. `Medallion Received` styles the box and
   * leaves it empty — the only arrival in the bundle that does — so the slot is
   * optional and that board leaves by the corner X, which the frame draws (D138).
   */
  secondary?: string;
  onPrimary: () => void;
  onSecondary?: () => void;
  /** The corner X, when leaving is not the same thing as deferring. */
  onClose?: () => void;
  /** A gradient field in place of the letter's two washes. */
  field?: readonly [string, string];
  /** One centred disc of light, given as [size, top, colour, alpha, stop]. */
  halo?: readonly [number, number, string, number, number];
  eyebrow?: string;
  chip?: string;
  artTop?: number;
  titleTop?: number;
  titleStyle?: TextStyle;
  subTop?: number;
}) {
  const { width } = useWindowDimensions();

  return (
    <>
      {field ? <LinearGradient colors={[field[0], field[1]]} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} /> : null}
      {halo ? (
        <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: halo[1], alignItems: 'center' }}>
          <Svg width={halo[0]} height={halo[0]}>
            <Defs>
              <RadialGradient id="ma-halo" cx="50%" cy="50%" rx="50%" ry="50%">
                <Stop offset="0" stopColor={halo[2]} stopOpacity={halo[3]} />
                <Stop offset={halo[4]} stopColor={halo[2]} stopOpacity={0} />
              </RadialGradient>
            </Defs>
            <Ellipse cx={halo[0] / 2} cy={halo[0] / 2} rx={halo[0] / 2} ry={halo[0] / 2} fill="url(#ma-halo)" />
          </Svg>
        </View>
      ) : null}
      {/* the canvas paints the grain first and lays the two washes over it, not under */}
      <Grain source={noiseDark} opacity={0.07} />

      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden', opacity: field ? 0 : 1 }}>
        {/* canvas blurs this by 5px; RN SVG has no blur filter, so the falloff is the gradient's */}
        <Svg width={width * 1.3} height={300} style={{ position: 'absolute', left: -width * 0.15, top: -190 }}>
          <Defs>
            <RadialGradient id="lt-top" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#B4AA96" stopOpacity={0.32} />
              <Stop offset="0.55" stopColor="#B4AA96" stopOpacity={0.1} />
              <Stop offset="0.75" stopColor="#B4AA96" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={(width * 1.3) / 2} cy={150} rx={(width * 1.3) / 2} ry={150} fill="url(#lt-top)" />
        </Svg>
        <Svg width={520} height={520} style={{ position: 'absolute', left: '50%', bottom: -260, marginLeft: -260 }}>
          <Defs>
            <RadialGradient id="lt-bottom" cx="50%" cy="50%" rx="50%" ry="50%">
              <Stop offset="0" stopColor="#FFECC4" stopOpacity={0.4} />
              <Stop offset="0.45" stopColor="#FFECC4" stopOpacity={0.18} />
              <Stop offset="0.72" stopColor="#FFECC4" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Ellipse cx={260} cy={260} rx={260} ry={260} fill="url(#lt-bottom)" />
        </Svg>
      </View>

      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        {/* Yoga positions an absolute child from its parent's border box and never
            consults padding, and the safe-area inset IS padding — so an absolute
            child of SafeAreaView lands under the status bar. This plain flex child
            carries the inset into its own border box. */}
        <View style={{ flex: 1 }}>
          <PressScale
            onPress={onClose ?? onSecondary ?? onPrimary}
            accessibilityRole="button"
            accessibilityLabel="Close"
            hitSlop={{ top: 18, bottom: 18, left: 18, right: 18 }}
            style={{ position: 'absolute', right: 20, top: 12, minHeight: 0 }}>
            <Svg width={18} height={18} viewBox="0 0 18 18">
              <Path d="M3 3l12 12M15 3L3 15" stroke="#55534E" strokeWidth={2.2} strokeLinecap="round" />
            </Svg>
          </PressScale>

          {eyebrow ? (
            <AppText center style={[sans('600'), { position: 'absolute', left: 0, right: 0, top: 46, fontSize: 11, letterSpacing: 1.6, color: 'rgba(91,74,40,0.55)' }]}>
              {eyebrow}
            </AppText>
          ) : null}

          <View pointerEvents="none" style={{ position: 'absolute', left: '50%', top: artTop, width: 260, height: 260, marginLeft: -130 }}>
            {art}
          </View>

          <AppText
            center
            style={[
              sans('500'),
              { position: 'absolute', left: 36, right: 36, top: titleTop, fontSize: 24, lineHeight: 32, letterSpacing: -0.1, color: '#1D1C1A' },
              titleStyle,
            ]}>
            {title}
          </AppText>
          {chip ? (
            <View style={{ position: 'absolute', left: 0, right: 0, top: 422, alignItems: 'center' }}>
              <View style={{ height: 30, borderRadius: 15, backgroundColor: '#FFFFFF', boxShadow: '0 0 0 1px rgba(0,0,0,0.1)', paddingHorizontal: 14, justifyContent: 'center' }}>
                <AppText style={[sans('600'), { fontSize: 12.5, color: '#55534E' }]}>{chip}</AppText>
              </View>
            </View>
          ) : null}
          <AppText center style={[sans('400'), { position: 'absolute', left: 44, right: 44, top: subTop, fontSize: 15.5, lineHeight: 23, color: '#55534E' }]}>
            {sub}
          </AppText>

          <PressScale
            onPress={onPrimary}
            accessibilityRole="button"
            style={{
              position: 'absolute',
              left: 24,
              right: 24,
              bottom: 108,
              height: 56,
              borderRadius: 28,
              backgroundColor: '#131313',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: '#FFFFFF' }]}>{primary}</AppText>
          </PressScale>
          {secondary && onSecondary ? (
            <PressScale
              onPress={onSecondary}
              accessibilityRole="button"
              hitSlop={{ top: 14, bottom: 14, left: 40, right: 40 }}
              style={{ position: 'absolute', left: 0, right: 0, bottom: 70, minHeight: 0, alignItems: 'center' }}>
              <AppText style={[sans('500'), { fontSize: 15, color: '#8B8882' }]}>{secondary}</AppText>
            </PressScale>
          ) : null}
        </View>
      </SafeAreaView>
    </>
  );
}

/**
 * The contact shadow every drop casts: a flat ellipse of ink under a CSS blur.
 *
 * D010 rules that a blurred `radial-gradient(closest-side, …)` needs no filter,
 * because it has no hard edge to soften. This is the other case D063 carved out
 * — a solid fill, whose edge the blur is the whole of — so it is drawn as the
 * canvas states it, with a real Gaussian at the CSS radius (a `filter: blur(r)`
 * IS r standard deviations, unlike a box-shadow's radius, which is two).
 *
 * The wrapper keeps the canvas's own box so the two signatures still pair on it;
 * the `<Svg>` inside overhangs it, because an `<Svg>` clips to its viewport and
 * a σ-6 blur reaches about three σ past the shape it softens.
 */
export function ContactShadow({ left, top, width, height, fill, blur = 6 }: { left: number; top: number; width: number; height: number; fill: string; blur?: number }) {
  const pad = blur * 4;
  const id = `cs${Math.round(left)}-${Math.round(top)}-${width}`;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left, top, width, height }}>
      <Svg width={width + pad * 2} height={height + pad * 2} style={{ position: 'absolute', left: -pad, top: -pad }}>
        <Defs>
          <Filter id={id} x="-100%" y="-100%" width="300%" height="300%">
            <FeGaussianBlur stdDeviation={String(blur)} />
          </Filter>
        </Defs>
        <Ellipse cx={pad + width / 2} cy={pad + height / 2} rx={width / 2} ry={height / 2} fill={fill} filter={`url(#${id})`} />
      </Svg>
    </View>
  );
}

/** Canvas frame 260 × 260: glow, contact shadow, envelope face down, wax seal. */
export function EnvelopeArt() {
  return (
    <>
      {/* the glow is a `closest-side` radial already at zero on its own edge, so
          its 5px blur has nothing to soften (D010); the shadow underneath is a
          flat fill and gets the canvas's own blur */}
      <Svg width={180} height={180} style={{ position: 'absolute', left: 40, top: 10 }}>
        <Defs>
          <RadialGradient id="lt-glow" cx="50%" cy="50%" r="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.5} />
            <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={90} cy={90} rx={90} ry={90} fill="url(#lt-glow)" />
      </Svg>
      <ContactShadow left={40} top={226} width={180} height={16} fill="rgba(0,0,0,0.10)" />

      <View
        style={{
          position: 'absolute',
          left: 46,
          top: 70,
          width: 168,
          height: 118,
          borderRadius: 10,
          boxShadow: '0 0 0 1px rgba(0,0,0,0.07), 0 16px 32px rgba(40,38,32,0.18)',
          transform: [{ rotate: '-2deg' }],
          overflow: 'hidden',
        }}>
        <LinearGradient colors={['#FCFAF4', '#F1EEE4']} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <Grain source={noiseDark} opacity={0.07} />
        <Svg width={168} height={118} viewBox="0 0 168 118" style={{ position: 'absolute', top: 0, left: 0 }}>
          <Path d="M2 4 L84 66 L166 4" fill="none" stroke="rgba(0,0,0,0.12)" strokeWidth={1.6} />
        </Svg>
      </View>

      <View style={{ position: 'absolute', left: 106, top: 112, transform: [{ rotate: '-2deg' }] }}>
        <WaxSeal size={48} glyph={20} shadow="inset 0 0 0 3px rgba(255,255,255,0.25), 0 5px 12px rgba(180,140,70,0.45)" />
      </View>
    </>
  );
}

/**
 * The inset half of a canvas box-shadow, for repainting over artwork.
 *
 * CSS draws an inset shadow above the element's own background, so a canvas
 * disc's white rim sits over its gradient. In the app the gradient is an `<Svg>`
 * child, which lands on top of the parent's inset ring and hides it — so the
 * inset segments are lifted out and drawn again on an overlay above the art.
 */
export function insetOf(shadow: string): string {
  return shadow
    .split(/,(?![^(]*\))/)
    .map((s) => s.trim())
    .filter((s) => s.startsWith('inset'))
    .join(', ');
}

/** The gold wax disc — `radial-gradient(circle at 38% 30%, …)` with the laurel struck into it. */
export function WaxSeal({ size, glyph, shadow }: { size: number; glyph: number; shadow: string }) {
  const id = `seal-${size}`;
  const ring = insetOf(shadow);
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, boxShadow: shadow, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute', top: 0, left: 0 }}>
        <Defs>
          {/* `circle at 38% 30%` takes CSS's default farthest-corner extent: the far
              corner sits 0.935 of the box away, so the ramp runs to 93.5%, not 50%.
              `r` is stated alongside `rx`/`ry` because the web build forwards only
              the native props, which no browser reads, and falls back to 50% (D064) */}
          <RadialGradient id={id} cx="38%" cy="30%" r="93.5%" rx="93.5%" ry="93.5%">
            <Stop offset="0" stopColor="#F0DBB4" />
            <Stop offset="0.62" stopColor="#E2BA78" />
            <Stop offset="1" stopColor="#C99F5F" />
          </RadialGradient>
        </Defs>
        <Ellipse cx={size / 2} cy={size / 2} rx={size / 2} ry={size / 2} fill={`url(#${id})`} />
      </Svg>
      {ring ? (
        <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: size / 2, boxShadow: ring }} />
      ) : null}
      <LaurelStrike width={glyph} />
    </View>
  );
}

/**
 * The laurel struck into wax — the canvas's two-path mark at 55% ink.
 *
 * It stays in flow (both callers centre it in a flex column) but is positioned,
 * because on web `<Svg>` lays out static and CSS paints every positioned box in
 * a stacking context above every static one, whatever the document order — so a
 * static mark would slide underneath the absolutely-placed disc it is struck on.
 */
export function LaurelStrike({ width, color = '#5b4a28' }: { width: number; color?: string }) {
  return (
    <Svg width={width} height={(width * 26) / 40} viewBox="0 0 40 26" opacity={0.55} style={{ position: 'relative' }}>
      <Path d="M21 3 L21 16 L12 16 Z" fill={color} />
      <Path d="M7 18 L33 18 Q30 24 20 24 Q10 24 7 18 Z" fill={color} />
    </Svg>
  );
}

/* ---------------------------------------------------------------- 172 · read */

/**
 * The sheet a drop opens into — canvas y 52, so it rides two points over the
 * top of the safe area and the field behind it (#EDECE7) shows only in the
 * status bar. Children position themselves against the sheet, not the screen.
 */
export function MailSheet({ onClose, children }: { onClose: () => void; children: ReactNode }) {
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']} pointerEvents="box-none">
      {/* the inset is Yoga padding on the SafeAreaView, and an absolute child is
          laid out from the border box — this plain flex child carries it */}
      <View style={{ flex: 1 }} pointerEvents="box-none">
        <View
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: -2,
            bottom: 0,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            backgroundColor: '#F4F3F0',
            overflow: 'hidden',
          }}>
          <Grain source={noiseDark} opacity={0.07} />

          <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 12, alignItems: 'center' }}>
            <View style={{ width: 38, height: 5, borderRadius: 3, backgroundColor: 'rgba(19,19,19,0.16)' }} />
          </View>

          <PressScale
            onPress={onClose}
            accessibilityRole="button"
            accessibilityLabel="Close"
            hitSlop={{ top: 16, bottom: 16, left: 16, right: 16 }}
            style={{ position: 'absolute', right: 22, top: 26, minHeight: 0 }}>
            <Svg width={20} height={20} viewBox="0 0 20 20">
              <Path d="M3 3l14 14M17 3L3 17" stroke="#55534E" strokeWidth={2} strokeLinecap="round" />
            </Svg>
          </PressScale>

          {children}
        </View>
      </View>
    </SafeAreaView>
  );
}

/**
 * The written half of a letter: canvas left 34 / right 34, top 84, over the
 * 160 floor the pinned pill and its quiet line stand on.
 */
export function LetterBody({ bottom = 160, children }: { bottom?: number; children: ReactNode }) {
  return (
    <ScrollView
      style={{ position: 'absolute', left: 34, right: 34, top: 84, bottom }}
      showsVerticalScrollIndicator={false}
      contentInsetAdjustmentBehavior="never">
      {children}
    </ScrollView>
  );
}

/** The bookmark pill both post letters are kept with. */
export function KeepPill({ label, onPress, style }: { label: string; onPress: () => void; style?: ViewStyle }) {
  return (
    <PressScale
      onPress={onPress}
      accessibilityRole="button"
      style={[
        {
          height: 54,
          minHeight: 54,
          borderRadius: 27,
          backgroundColor: '#131313',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 9,
        },
        style,
      ]}>
      <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
        <Path
          d="M6 4.4h12a1 1 0 0 1 1 1v14.3a.8.8 0 0 1-1.27.65L12 16.7l-5.73 3.65A.8.8 0 0 1 5 19.7V5.4a1 1 0 0 1 1-1z"
          stroke="#FFFFFF"
          strokeWidth={2}
          strokeLinejoin="round"
        />
      </Svg>
      <AppText style={[sans('600'), { fontSize: 16.5, letterSpacing: 0.2, color: '#FFFFFF' }]}>{label}</AppText>
    </PressScale>
  );
}

/** Keep it, or leave it — the pair every post letter closes on. */
export function LetterFooter({
  primary,
  secondary,
  onPrimary,
  onSecondary,
  secondaryBottom = 44,
}: {
  primary: string;
  secondary: string;
  onPrimary: () => void;
  onSecondary: () => void;
  secondaryBottom?: number;
}) {
  return (
    <>
      <KeepPill label={primary} onPress={onPrimary} style={{ position: 'absolute', left: 24, right: 24, bottom: 88 }} />
      <PressScale
        onPress={onSecondary}
        accessibilityRole="button"
        hitSlop={{ top: 14, bottom: 14, left: 40, right: 40 }}
        style={{ position: 'absolute', left: 0, right: 0, bottom: secondaryBottom, minHeight: 0, alignItems: 'center' }}>
        <AppText style={[sans('500'), { fontSize: 14.5, color: '#8B8882' }]}>{secondary}</AppText>
      </PressScale>
    </>
  );
}

/** "Dear Sam," — 22/600 at 0.6 tracking, on both letters VICI sends. */
export function Salutation({ children }: { children: ReactNode }) {
  return <AppText style={[sans('600'), { fontSize: 22, letterSpacing: 0.6, color: '#1D1C1A', marginBottom: 24 }]}>{children}</AppText>;
}

/** A paragraph of letter: 15.5 at line-height 1.8. */
export function LetterP({ children, gap = 26 }: { children: ReactNode; gap?: number }) {
  return <AppText style={[sans('400'), { fontSize: 15.5, lineHeight: cssLineHeight(15.5, 1.8), color: '#3A3934', marginBottom: gap }]}>{children}</AppText>;
}

/**
 * The name at the foot, and the pen stroke under it.
 *
 * The canvas gives it `margin-top: 20` under a paragraph carrying
 * `margin-bottom: 26`. CSS collapses the pair to the larger, so the gap the
 * frame draws is 26 — which the paragraph has already spent — and Yoga, which
 * adds them, must state none of its own. See D023.
 */
export function Signoff({ children }: { children: ReactNode }) {
  return (
    <>
      <AppText style={[sans('600'), { fontSize: 16, color: '#1D1C1A' }]}>{children}</AppText>
      <Svg width={150} height={12} viewBox="0 0 150 12" fill="none" style={{ marginTop: 4 }}>
        <Path d="M2 8 C 34 2, 58 10, 86 6 S 132 4, 148 7" stroke="rgba(38,38,31,0.5)" strokeWidth={1.6} fill="none" strokeLinecap="round" />
      </Svg>
    </>
  );
}

/* --------------------------------------------------------- the two letters */

/** 172 · the morning after a slip, with the reason you started set in your own words. */
function PostLetter({ name, why }: { name: string; why: string }) {
  return (
    <>
      <Salutation>Dear {name},</Salutation>
      {/* the frame sets this paragraph with straight apostrophes and keeps the
          curly one only in "Don’t" three paragraphs down — transcribed as drawn */}
      <LetterP>
        If you&#39;re reading this, it happened. Good — you opened the letter instead of disappearing. That&#39;s the only door that matters this morning.
      </LetterP>
      <LetterP>
        One slip is a wave, not the sea. Nothing since day zero is erased — the days stood, the urges outlasted, the reason you started:{' '}
        {/* the run inherits the paragraph's size and leading in CSS; AppText would
            hand a nested run its own variant metrics, so both are restated here.
            RN has no prop for the rule's thickness or its distance from the
            baseline, so the canvas's 1.5px at a 4px offset is stated in CSS on
            web — where the capture is measured — and left to the platform's own
            underline on device, which is what RN draws either way. */}
        <AppText
          style={[
            sans('500'),
            { fontSize: 15.5, lineHeight: cssLineHeight(15.5, 1.8), color: '#1D1C1A', textDecorationLine: 'underline', textDecorationColor: 'rgba(0,0,0,0.28)' },
            // react-native-web sets `white-space: pre-wrap` on every Text, which
            // keeps the space that ends a wrapped line and paints the underline
            // under it; the canvas's <em> collapses it. `normal` is CSS's own
            // default and this run has no significant whitespace in it.
            Platform.OS === 'web' ? ({ textDecorationThickness: '1.5px', textUnderlineOffset: '4px', whiteSpace: 'normal' } as TextStyle) : null,
          ]}>
          {why}
        </AppText>
        . All still yours.
      </LetterP>
      <LetterP>The only slip that can end this is the one you answer with a second. So: water, daylight, one lesson. Don&rsquo;t fail twice.</LetterP>
      <LetterP>I&#39;ll see you tonight, steadier.</LetterP>
      <Signoff>— the you who makes it out</Signoff>
    </>
  );
}
