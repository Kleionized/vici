import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Platform, ScrollView, type TextStyle, View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Ellipse, G, Line, Path, Polygon, Polyline, Rect } from 'react-native-svg';

import { TaskScene } from '@/components/task/TaskScene';
import { AppText, Grain, PressScale } from '@/components/ui';
import { lessonForDay } from '@/content/curriculum84';
import { TASK_OPTION_ICONS, type TaskSvgChild } from '@/content/taskScenes';
import { useCheckins, useUpsertCheckin } from '@/lib/backend';
import { todayKey } from '@/lib/date';
import { sans } from '@/lib/theme';

/**
 * `Task DNN Intro` and `Task DNN Options` — the day's task, in two boards.
 *
 * The bundle draws a third frame per day, `Task DNN Card`, but it is a
 * specimen rather than a screen: it shows the same task as it appears on the
 * Today home and again in the night reminder, both of which are cards this app
 * already builds (DECISIONS D-045).
 *
 * Canvas tops include the 54pt status bar the app never builds, so every number
 * below is the canvas value less 54.
 */

const noiseDark = require('../../../assets/images/noise-dark.png');

/** The rule card's shell, shared by the absolute board and day 1's flow one. */
const ruleCard = {
  backgroundColor: '#FFFFFF',
  borderCurve: 'continuous',
  boxShadow: '0 0 0 1px rgba(0,0,0,0.07), 0 6px 16px rgba(40,38,32,0.05)',
  flexDirection: 'row',
  alignItems: 'center',
} as const;

/** The frame states `text-wrap: balance` on the board titles. */
const BALANCE = Platform.OS === 'web' ? ({ textWrap: 'balance' } as unknown as TextStyle) : null;

/**
 * The frame's own `text-wrap`, and CSS's initial value where it states none.
 *
 * `AppText` applies `pretty` on web to everything that is not a heading, so a
 * run the canvas leaves alone gets rebalanced and breaks somewhere else. The
 * property is web-only, but it is what makes a headless capture a faithful
 * proxy for the frame (F8).
 */
const wrapOf = (wrap?: string) => (Platform.OS === 'web' ? ({ textWrap: wrap ?? 'wrap' } as unknown as TextStyle) : null);

/**
 * The tick on the rule card: a 20pt box on an 18-unit grid, hairline circle and
 * check, both #1D1C1A. Every one of the 83 intro frames draws this mark; the app
 * drew a bare heavy check, which is a different one.
 */
function DoneMark() {
  return (
    // the canvas states `flex-shrink: 0` on it, and the line beside it is the
    // one thing on the card that gives way
    <Svg width={20} height={20} viewBox="0 0 18 18" fill="none" style={{ flexShrink: 0 }}>
      <Circle cx={9} cy={9} r={7.5} fill="none" stroke="#1D1C1A" strokeWidth={1.6} />
      <Path d="M5.8 9l2.3 2.3 4.1-4.6" fill="none" stroke="#1D1C1A" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export default function TaskBoards() {
  const router = useRouter();
  const { day } = useLocalSearchParams<{ day?: string }>();
  const n = Number(day) || 1;
  const lesson = lessonForDay(n);
  const checkins = useCheckins();
  const upsert = useUpsertCheckin();
  const [board, setBoard] = useState(0);
  const width = useWindowDimensions().width;

  if (!lesson) return null;
  const task = lesson.task;
  const options = task.options;
  const board1 = task.board;
  const intro = task.intro2;
  // `Task D01` draws both boards as a centred flow column with its own type
  // ramp — the one frame the batch that laid the other 82 out absolutely never
  // reached. `flow` is stated only on that day.
  const flow = task.flow;
  const step = board1.kind === 'step';
  const badge = board1.badge?.size ?? (step ? 24 : 40);
  const close = () => (router.canGoBack() ? router.back() : router.replace('/(app)/today'));

  const done = () => {
    void upsert({ date: todayKey(), dailyAction: task.cardSummary, dailyActionDone: true }).catch(() => {});
    close();
  };
  const alreadyDone = (checkins ?? []).find((c) => c.date === todayKey())?.dailyActionDone ?? false;

  // The option rows, built once: the absolute column and day 1's flow column
  // draw the same rows with the same per-day metrics, only in different boxes.
  const rows = options.map((option, index) => {
    const head = option.ramp?.head ?? board1.head;
    const body = option.ramp ? option.ramp.body : board1.body;
    return (
    <View key={`${index}-${option.head}`} style={{ flexDirection: 'row', alignItems: 'flex-start', gap: board1.cellGap ?? 14 }}>
      {step ? (
        // The numbered variant: a 24pt disc carrying the step's own number,
        // hairline-ringed and nudged 1pt down off the heading.
        <View
          style={{
            width: badge,
            height: badge,
            // The frame states `border-radius: 50%`, and a signature reads the
            // computed value — so the per cent is transcribed rather than
            // resolved to half the badge, which reports as `12px`.
            borderRadius: '50%',
            marginTop: 1,
            backgroundColor: '#FFFFFF',
            boxShadow: '0 0 0 1px rgba(0,0,0,0.09)',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <AppText style={[sans('600'), { fontSize: 12, color: '#55534E' }]}>{index + 1}</AppText>
        </View>
      ) : (
        <View
          style={{
            width: badge,
            height: badge,
            borderRadius: typeof board1.badge?.radius === 'number' ? board1.badge.radius : 12,
            borderCurve: 'continuous',
            backgroundColor: '#FFFFFF',
            boxShadow: '0 0 0 1px rgba(0,0,0,0.08), 0 3px 8px rgba(40,38,32,0.06)',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <OptionGlyph day={n} index={index} />
        </View>
      )}
      <View style={{ flex: 1, minWidth: 0 }}>
        {/* Day 43 gives every row one plain line rather than a bold heading
            over a body, and day 82 does it to its fourth row alone — so the
            weight and the ink are read off the frame with the size, per row
            where the row breaks from the board. */}
        <AppText
          style={[
            sans((head?.weight ?? '600') as '400' | '600'),
            { fontSize: head?.size ?? 15.5, lineHeight: head?.lineHeight ?? 21, color: head?.color ?? '#1D1C1A' },
            wrapOf(head?.wrap),
          ]}>
          {option.head}
        </AppText>
        {/* Some rows are a heading alone — drawing an empty line would still
            cost its line-height and push everything below it. */}
        {option.body ? (
          <AppText
            style={[
              sans('400'),
              {
                marginTop: body?.marginTop ?? 3,
                fontSize: body?.size ?? 13,
                lineHeight: body?.lineHeight ?? 19,
                color: body?.color ?? '#767370',
              },
              wrapOf(body?.wrap),
            ]}>
            {option.body}
          </AppText>
        ) : null}
      </View>
    </View>
    );
  });

  return (
    <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
      <StatusBar style="dark" />
      <Grain source={noiseDark} opacity={0.07} />

      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
        {/* Yoga positions an absolute child against its parent's border box and
          ignores the padding SafeAreaView spends the inset with, so absolute
          children of the SafeAreaView itself sit at the top of the screen
          rather than below the notch. One plain View deeper restores it. */}
        <View style={{ flex: 1 }}>
          <PressScale
            onPress={board === 0 ? close : () => setBoard(0)}
            accessibilityRole="button"
            accessibilityLabel={board === 0 ? 'Close' : 'Back'}
            hitSlop={{ top: 16, bottom: 16, left: 16, right: 24 }}
            style={{ position: 'absolute', left: 16, top: 12, minHeight: 0, zIndex: 5 }}>
            <AppText style={[sans('400'), { fontSize: 17, color: '#3A3934' }]}>Close</AppText>
          </PressScale>

          {/* The `DAY N · TODAY'S TASK` eyebrow the previous bundle drew at canvas
              116 is gone: the new bundle deletes it from all 166 task frames, and
              from the reader's task page too. The title keeps its own absolute
              top, so nothing below it moves. */}
          {flow ? null : (
            /* canvas 144 */
            <AppText
              center
              style={[sans('500'), BALANCE, { position: 'absolute', left: 30, right: 30, top: 90, fontSize: 27, lineHeight: 35, color: '#1D1C1A' }]}>
              {board === 0 ? task.title : task.secondTitle}
            </AppText>
          )}

          {flow ? (
            // Day 1's centred column. Both boards share the spacer, the title
            // and the gap; only the padding, the floor and the last child differ.
            <View
              style={{
                position: 'absolute',
                left: 0,
                right: 0,
                top: board === 0 ? flow.introTop : flow.boardTop,
                bottom: board === 0 ? flow.introBottom : flow.boardBottom,
                alignItems: 'center',
                justifyContent: 'center',
                gap: flow.gap,
                paddingHorizontal: board === 0 ? flow.introPadX : flow.boardPadX,
              }}>
              <View style={{ height: flow.spacer }} />
              <AppText
                center
                style={[sans('500'), BALANCE, { maxWidth: flow.title.maxWidth, fontSize: flow.title.size, lineHeight: flow.title.lineHeight, color: '#1D1C1A' }]}>
                {board === 0 ? task.title : task.secondTitle}
              </AppText>
              {board === 0 ? (
                <>
                  {/* The canvas scales the 340 x 200 scene by 0.85 into a slot of
                      its own height rather than composing a smaller one. */}
                  <View style={{ height: flow.scene.height }}>
                    <TaskScene day={n} width={intro.sceneWidth * flow.scene.scale} />
                  </View>
                  <AppText
                    center
                    style={[sans('400'), { maxWidth: flow.intro.maxWidth, fontSize: flow.intro.size, lineHeight: flow.intro.lineHeight, color: '#55534E' }]}>
                    {task.intro}
                  </AppText>
                  <View style={[ruleCard, { alignSelf: 'stretch', borderRadius: flow.rule.radius, paddingVertical: flow.rule.padV, paddingHorizontal: flow.rule.padH, gap: flow.rule.gap }]}>
                    <DoneMark />
                    <AppText style={[sans('500'), { flexShrink: 1, fontSize: flow.rule.size, lineHeight: flow.rule.lineHeight, color: '#55534E' }]}>{task.done}</AppText>
                  </View>
                </>
              ) : (
                <View style={{ alignSelf: 'stretch', gap: flow.rowGap }}>{rows}</View>
              )}
            </View>
          ) : board === 0 ? (
            <>
              <AppText
                center
                style={[sans('400'), { position: 'absolute', left: 38, right: 38, top: intro.introTop, fontSize: 14.5, lineHeight: 21, color: '#55534E' }]}>
                {task.intro}
              </AppText>

              {/* The scene box, at the top and size this day's frame states: it
                  sits anywhere from 197 to 386, and two days draw it shorter
                  than 200. */}
              <View style={{ position: 'absolute', left: intro.sceneLeft, top: intro.sceneTop }}>
                <TaskScene day={n} width={Math.min(intro.sceneWidth, width - intro.sceneLeft * 2)} height={intro.sceneHeight} />
              </View>

              {/* What finishing it means — always 20pt below the scene's foot,
                  which is why it moves with the scene rather than sitting at a
                  top of its own. */}
              <View
                style={[
                  ruleCard,
                  {
                    position: 'absolute',
                    left: 24,
                    right: 24,
                    top: intro.ruleTop,
                    minHeight: intro.ruleHeight,
                    borderRadius: 16,
                    paddingHorizontal: 18,
                    gap: 13,
                  },
                ]}>
                <DoneMark />
                {/* The canvas's rule line is a `<span>`: it takes the width of
                    its own words and wraps only when they do not fit, where a
                    `flex: 1` box fills the card whatever it says. */}
                <AppText style={[sans('500'), { flexShrink: 1, fontSize: 13.5, lineHeight: 19, color: '#55534E' }]}>{task.done}</AppText>
              </View>
            </>
          ) : (
            // The board's own geometry, per day. The canvas puts this column at
            // canvas 209, 225 or 260 and varies every metric inside it, so none
            // of it is hardcoded here — `board` carries what the frame states.
            // Its floor is the canvas's own `bottom`, measured off the frame's
            // foot (D026) — 108 on every batch day, i.e. the button's own top.
            <ScrollView
              showsVerticalScrollIndicator={false}
              style={{ position: 'absolute', left: 24, right: 24, top: board1.top ?? 171, bottom: board1.bottom ?? 108 }}
              contentContainerStyle={{ gap: board1.rowGap ?? 22 }}>
              {/* Days 74 and 76 draw this board empty — a title and the button,
                  nothing between them. `task-src.json` lists no bullets for
                  either, so the blank column is authored, not a gap: the app
                  used to fill it with the intro board's rule line, which the
                  canvas puts on the intro board and nowhere else. */}
              {rows}
              {/* The note under the last row. On most days it repeats the intro
                  board's rule; on 23 it says something else, so it is its own
                  field rather than a second render of `task.done`. Day 43 writes
                  two paragraphs, each with its own gap above it — and the column
                  already contributes `rowGap`, so that much is taken back out. */}
              {(task.close ?? []).map((para, i) => (
                <AppText
                  key={i}
                  style={[
                    sans('400'),
                    {
                      marginTop: para.marginTop - (board1.rowGap ?? 22),
                      // The note has its own leading — day 10 sets its option
                      // bodies 12.5/17.5 and this 12.5/17.
                      fontSize: para.size ?? board1.body?.size ?? 13,
                      lineHeight: para.lineHeight ?? board1.body?.lineHeight ?? 19,
                      color: '#767370',
                    },
                    wrapOf(para.wrap),
                  ]}>
                  {para.text}
                </AppText>
              ))}
            </ScrollView>
          )}

          {/* canvas 706 — two dots, one per board */}
          <View style={{ position: 'absolute', left: 0, right: 0, top: 652, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6 }}>
            {[0, 1].map((i) => (
              <View key={i} style={{ width: i === board ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === board ? '#131313' : 'rgba(19,19,19,0.18)' }} />
            ))}
          </View>

          {/* canvas 744 */}
          <PressScale
            onPress={board === 0 ? () => setBoard(1) : done}
            accessibilityRole="button"
            style={{
              position: 'absolute',
              left: 24,
              right: 24,
              top: 690,
              height: 52,
              minHeight: 52,
              borderRadius: 26,
              backgroundColor: '#131313',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: '#FFFFFF' }]}>
              {board === 0 ? 'Continue' : alreadyDone ? 'Done' : 'Mark as done'}
            </AppText>
          </PressScale>
        </View>
      </SafeAreaView>
    </View>
  );
}

/** The row's own glyph, at the size the frame states, transcribed off the canvas. */
function OptionGlyph({ day, index }: { day: number; index: number }) {
  const icon = TASK_OPTION_ICONS[day]?.[index];
  if (!icon) return null;
  // 223 of the 257 glyphs are drawn at 22 and 34 at 20 — the frame states which.
  const size = Number(icon.attrs.width) || 22;
  return (
    <Svg width={size} height={size} viewBox={icon.attrs.viewBox ?? '0 0 20 20'} fill="none">
      {icon.children.map((child, i) => (
        <GlyphChild key={i} child={child} />
      ))}
    </Svg>
  );
}

const NUM = new Set(['x', 'y', 'width', 'height', 'rx', 'ry', 'cx', 'cy', 'r', 'x1', 'y1', 'x2', 'y2', 'stroke-width', 'stroke-opacity', 'fill-opacity']);

function GlyphChild({ child }: { child: TaskSvgChild }) {
  const props: Record<string, string | number> = {};
  for (const [key, value] of Object.entries(child.attrs)) {
    props[key.replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = NUM.has(key) && !Number.isNaN(Number(value)) ? Number(value) : value;
  }
  switch (child.tag) {
    case 'path':
      return <Path {...props} />;
    case 'rect':
      return <Rect {...props} />;
    case 'circle':
      return <Circle {...props} />;
    case 'ellipse':
      return <Ellipse {...props} />;
    case 'line':
      return <Line {...props} />;
    case 'polygon':
      return <Polygon {...props} />;
    case 'polyline':
      return <Polyline {...props} />;
    case 'g':
      return <G {...props} />;
    default:
      return null;
  }
}
