import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { ScrollView, View, type TextStyle } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';

import { KKMedallion, KK_ALBUM, KK_METALS, kkFace, kkRoman, kkRung, type KKFace, type KKMetal } from '@/components/keepsakes/Medallion';
import { AppText, EmptyState, Grain, PressScale } from '@/components/ui';
import { colors, sans } from '@/lib/theme';

/**
 * 088I–088Q · The ladder behind one medallion.
 *
 * Five rows, one per metal, each the same coin struck differently and the rung
 * that strikes it. It is a reference page, not a state page: the canvas draws
 * no earned mark, no lock and no current-rung highlight on any of the nine
 * frames, so neither does this — where you actually stand is the pill on the
 * detail screen you arrived from.
 *
 * The four faces that mint once share `Earned once` (088Q): four rows instead
 * of five, all struck in platinum, and a requirement sentence where a rung
 * would be.
 *
 * Canvas y − 54 throughout (the frame's status bar is the safe-area top inset).
 */

const noiseDark = require('../../../../assets/images/noise-dark.png');

/** `AppText` gives a body run `text-wrap: pretty` on web (D052); these frames state none. */
const NO_WRAP = { textWrap: 'wrap' } as unknown as TextStyle;

/** The board-coloured ring each coin is mounted in, per metal. */
const MOUNT: Record<KKMetal, string> = {
  paper: '#F4F3F0',
  bronze: '#F2E8DA',
  silver: '#F1F2F4',
  gold: '#F5EBD2',
  // The ladder mounts platinum in a pale ring, not the detail screen's `#201F1C` —
  // this board stays paper even where the detail board turns to night.
  platinum: '#EEF0F4',
};

const METAL_NAME: Record<KKMetal, string> = {
  paper: 'Paper',
  bronze: 'Bronze',
  silver: 'Silver',
  gold: 'Gold',
  platinum: 'Platinum',
};

/** The album's four one-off faces, in the order 088Q lists them. */
const ONCE: KKFace[] = KK_ALBUM.filter((face) => !face.steps.length);

type Row = { face: KKFace; metal: KKMetal; name: string; sub: string };

export default function MedallionTiers() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ key?: string }>();
  const once = params.key === 'once';
  const face = once ? undefined : kkFace(params.key ?? '');

  const back = () => (router.canGoBack() ? router.back() : router.replace('/(app)/milestones'));

  if (!once && (!face || !face.steps.length)) {
    return (
      <SafeAreaView edges={['top', 'bottom']} style={{ flex: 1, backgroundColor: colors.bg, paddingHorizontal: 16 }}>
        <EmptyState title="Medallion not found" body="It may have been renamed." />
      </SafeAreaView>
    );
  }

  const title = once ? 'Earned once' : face!.name;
  const subtitle = once ? 'One tier only · platinum' : face!.blurb;
  const rows: Row[] = once
    ? ONCE.map((f) => ({ face: f, metal: 'platinum' as KKMetal, name: f.name, sub: f.blurb }))
    : KK_METALS.map((metal, i) => ({
        face: face!,
        metal,
        name: METAL_NAME[metal],
        // The ladder writes a day rung in Arabic where the album card writes it
        // in Roman — `Tier I · Day 7` here against `Tier I · Day VII` there.
        sub: `Tier ${kkRoman(i + 1)} · ${kkRung(face!, face!.steps[i], 'arabic')}`,
      }));

  return (
    <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
      <StatusBar style="dark" />
      <Grain source={noiseDark} opacity={0.07} />

      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        {/* the canvas's own 852 less the status bar it actually has, so the
            absolute rows measure off the safe area and a short screen still
            scrolls to the last one */}
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ height: 852 - insets.top }}>
          {/* canvas y 64 */}
          <PressScale
            onPress={back}
            accessibilityRole="button"
            accessibilityLabel="Back"
            hitSlop={{ top: 16, bottom: 16, left: 20, right: 20 }}
            style={{ position: 'absolute', left: 16, top: 10, minHeight: 0 }}>
            <Svg width={11} height={19} viewBox="0 0 11 19" fill="none">
              <Path d="M9.5 1.5L2 9.5l7.5 8" fill="none" stroke="#55534E" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
            </Svg>
          </PressScale>

          {/* canvas y 72 — the album's page marks, carried through as chrome */}
          <View pointerEvents="none" style={{ position: 'absolute', right: 20, top: 18, flexDirection: 'row', gap: 4.5 }}>
            {[0, 1, 2].map((i) => (
              <View key={i} style={{ width: 4.5, height: 4.5, borderRadius: 2.25, backgroundColor: '#55534E' }} />
            ))}
          </View>

          {/* canvas y 114 */}
          <AppText style={[sans('600'), { position: 'absolute', left: 16, top: 60, fontSize: 27, letterSpacing: -0.2, color: '#1D1C1A' }]}>{title}</AppText>

          {/* canvas y 156 */}
          <AppText style={[sans('600'), NO_WRAP, { position: 'absolute', left: 16, right: 16, top: 102, fontSize: 13, color: '#8B8882' }]}>{subtitle}</AppText>

          {/* canvas y 200, on a 110 stride */}
          {rows.map((row, i) => (
            <View
              key={row.name}
              style={{
                position: 'absolute',
                left: 16,
                right: 16,
                top: 146 + i * 110,
                height: 96,
                borderRadius: 16,
                borderCurve: 'continuous',
                backgroundColor: '#FFFFFF',
                boxShadow: '0 0 0 1px rgba(0,0,0,0.06)',
                flexDirection: 'row',
                alignItems: 'center',
                gap: 20,
                paddingHorizontal: 20,
              }}>
              <View style={{ borderRadius: 9999, boxShadow: `0 0 0 1.5px rgba(0,0,0,0.2), 0 0 0 4px ${MOUNT[row.metal]}, 0 0 0 5px rgba(0,0,0,0.16)` }}>
                <KKMedallion scene={row.face.key} size={64} metal={row.metal} variant="tier" />
              </View>
              <View>
                <AppText style={[sans('600'), { fontSize: 15.5, color: '#1D1C1A' }]}>{row.name}</AppText>
                <AppText style={[sans('500'), { marginTop: 3, fontSize: 12.5, color: '#8B8882' }]}>{row.sub}</AppText>
              </View>
            </View>
          ))}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}
