import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle, Path, Rect } from 'react-native-svg';

import { kkFace, kkRoman, kkStanding } from '@/components/keepsakes/Medallion';
import { AppText, BackChevron, LoadingView, PressScale } from '@/components/ui';
import { useCheckins, useCurrentUser, useEvents } from '@/lib/backend';
import { getJSON } from '@/lib/storage';
import { buildWeeklyReport, completedWeekStarts } from '@/lib/weeklyReport';
import { colors, fonts, sans, spacing } from '@/lib/theme';

const LETTER_KEY = 'tideline.letter.day3';
const POST_DONE_KEY = 'tideline.post.backondeck.delivered';

type Item =
  | { kind: 'letter'; title: string; sub: string; kept: boolean; go: () => void }
  | { kind: 'report'; title: string; sub: string; go: () => void };

export default function Mail() {
  const router = useRouter();
  const user = useCurrentUser();
  const checkins = useCheckins();
  const events = useEvents();
  const [letter, setLetter] = useState<{ kept?: boolean } | null>(null);
  const [postDelivered, setPostDelivered] = useState(false);

  useEffect(() => {
    void getJSON<{ kept?: boolean }>(LETTER_KEY).then(setLetter);
    // The key still spells the retired `Back on deck` face; it is load-bearing
    // storage on accounts that already have the post, so it keeps its name.
    void getJSON<number>(POST_DONE_KEY).then((v) => setPostDelivered(!!v));
  }, []);

  const items = useMemo<Item[]>(() => {
    if (!user || !checkins || !events) return [];
    const out: Item[] = [];

    // weekly reports — newest first
    for (const weekStart of completedWeekStarts(user.createdAt)) {
      const r = buildWeeklyReport(weekStart, checkins, events);
      const verdict =
        r.thisAvg == null
          ? 'A quiet week'
          : r.lastAvg == null
            ? 'Your first full week'
            : r.thisAvg - r.lastAvg >= 0.25
              ? 'Steadier than the week before'
              : r.lastAvg - r.thisAvg >= 0.25
                ? 'A heavier week'
                : 'A steady week';
      out.push({
        kind: 'report',
        title: 'Weekly report',
        sub: `${r.label} · ${verdict}`,
        go: () => router.push({ pathname: '/weekly-report', params: { week: weekStart } }),
      });
    }

    // Post from VICI — the medallion letter (and its enclosure), re-readable.
    // The row names the same face and the same rung the post itself delivers,
    // which `/medallion-post` reads out of the album from the ridden-out count
    // (F11). It used to claim `Vici, tier II` flat, and went stale the moment
    // the post stopped naming its own tier.
    if (postDelivered) {
      const face = kkFace('vici');
      const ridden = events.filter((e) => e.type === 'urge_rode_out').length;
      const standing = face ? kkStanding(face, ridden) : 0;
      out.push({
        kind: 'letter',
        title: 'VICI Post · A medallion',
        sub: `${face?.name ?? 'Vici'}, tier ${kkRoman(Math.max(1, standing))} · enclosure inside`,
        kept: true,
        go: () => router.push('/medallion-post'),
      });
    }

    // the sealed letter — written on day zero, resealed after each reading
    out.push({
      kind: 'letter',
      title: 'A letter from day zero',
      sub: letter?.kept ? 'Resealed · don’t fail twice' : 'Sealed · waits until it’s needed',
      kept: !!letter?.kept,
      go: () => router.push('/letter'),
    });
    return out;
  }, [user, checkins, events, letter, postDelivered, router]);

  const back = () => (router.canGoBack() ? router.back() : router.replace('/(app)/dashboard'));

  if (checkins === undefined || events === undefined) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        <LoadingView />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <StatusBar style="dark" />
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
        <View style={{ paddingHorizontal: 16, paddingTop: spacing.sm }}>
          <BackChevron onPress={back} />
          <AppText style={[sans('600'), { fontSize: 27, letterSpacing: -0.4, color: colors.inkAlt, marginTop: 8 }]}>Mail</AppText>
        </View>

        {items.length === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40, gap: 8 }}>
            <QuoteMark />
            <AppText center style={[sans('500'), { fontSize: 22, color: colors.text, maxWidth: 260, lineHeight: 28 }]}>
              Nothing’s arrived yet.
            </AppText>
            <AppText center style={[sans('400'), { fontSize: 13.5, color: colors.textMuted, maxWidth: 280, lineHeight: 20 }]}>
              A report lands here at the end of each week, and letters arrive along the way.
            </AppText>
          </View>
        ) : (
          <ScrollView contentInsetAdjustmentBehavior="automatic" showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingTop: 24, gap: 11 }}>
            {items.map((it, i) => (
              <PressScale
                key={i}
                onPress={it.go}
                accessibilityRole="button"
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 14,
                  backgroundColor: colors.surface,
                  borderRadius: 18,
                  padding: 16,
                }}>
                <View style={{ width: 46, height: 46, borderRadius: 12, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center' }}>
                  {it.kind === 'letter' ? <LetterMark /> : <ReportMark />}
                </View>
                <View style={{ flex: 1 }}>
                  <AppText style={[sans('600'), { fontSize: 15.5, color: colors.text }]}>{it.title}</AppText>
                  <AppText style={[sans('400'), { fontSize: 13, color: colors.textMuted, marginTop: 2 }]}>{it.sub}</AppText>
                </View>
                <Svg width={9} height={16} viewBox="0 0 9 16" fill="none">
                  <Path d="M1.5 1l6 7-6 7" stroke={colors.textSoft} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
                </Svg>
              </PressScale>
            ))}
          </ScrollView>
        )}
      </SafeAreaView>
    </View>
  );
}

function QuoteMark() {
  return (
    <AppText style={{ fontFamily: fonts.serifSharp, fontSize: 52, lineHeight: 40, color: 'rgba(29,28,26,0.18)' }}>{'“'}</AppText>
  );
}

function LetterMark() {
  return (
    <Svg width={22} height={22} viewBox="0 0 24 24" fill="none">
      <Rect x={3} y={5} width={18} height={14} rx={2.4} stroke={colors.text} strokeWidth={1.8} />
      <Path d="M4.5 7.5l7.5 5.5 7.5-5.5" stroke={colors.text} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

function ReportMark() {
  return (
    <Svg width={24} height={22} viewBox="0 0 24 22" fill="none">
      <Circle cx={17} cy={7} r={3.4} fill={colors.text} />
      <Path d="M2 13c2.2-2 4.4-2 6.6 0s4.4 2 6.6 0 4.4-2 6.6 0" stroke={colors.text} strokeWidth={1.8} strokeLinecap="round" />
      <Path d="M2 17.5c2.2-2 4.4-2 6.6 0s4.4 2 6.6 0 4.4-2 6.6 0" stroke={colors.text} strokeWidth={1.6} strokeLinecap="round" opacity={0.5} />
    </Svg>
  );
}
