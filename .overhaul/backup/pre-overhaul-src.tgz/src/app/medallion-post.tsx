import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { View } from 'react-native';
import Svg, { Defs, Ellipse, RadialGradient, Stop } from 'react-native-svg';

import { ContactShadow, LaurelStrike, LetterBody, LetterFooter, LetterP, MailArrival, MailSheet, Salutation, insetOf } from '@/app/letter';
import { kkFace, kkStanding } from '@/components/keepsakes/Medallion';
import { AppText } from '@/components/ui';
import { useCreateJournalEntry, useCurrentUser, useEvents } from '@/lib/backend';
import { setJSON } from '@/lib/storage';
import { fonts } from '@/lib/theme';

/**
 * The medallion post — canvas 110 → 173.
 *
 * A medallion struck in the night arrives the same way a letter does: the thing
 * itself on the lit field, then a short letter that says what it is for. The
 * canvas retired the whole three-act version of this screen — the breathing
 * envelope card, the medallion presented mid-letter, the enclosure drawn as a
 * black offer card — and left the arrival, the letter, and a way through to the
 * enclosure, which now lives on its own page.
 *
 * Both halves are the shared post furniture in `./letter`; only the object in
 * the 260 × 260 frame and the words are this screen's own.
 *
 * `Latest Vici FULL` draws no arrival for this post — its post chain is the
 * envelope (`Letter Arrival`), the slip letter, then `Medallion Letter` — so
 * the only frame in the bundle that draws a medallion arriving is
 * `Medallion Received`, which the onboarding handover owns. This board takes
 * that frame's current cut: the MEDALLION EARNED eyebrow and the tier chip are
 * both withdrawn and the name and the line under it sit at its 432 / 482.
 *
 * The face it delivers is read out of the album rather than named here. The
 * post fires when an urge was logged and did not end in a slip, which is
 * exactly `Vici`'s own rule, and the rung is whatever that count has cleared —
 * so the post can no longer promise a face the album cannot show. (It used to
 * deliver `Back on Deck` under `Tier II · The Return`, a face the canvas
 * dropped from the album two drops ago.)
 *
 * The contradiction that leaves: the letter's own words say "This one isn't
 * for resisting. It's for coming back", which was written for that retired
 * face. The letter is drawn by a frame and is transcribed verbatim; the
 * arrival is not, so it is the half that follows the album.
 */

const POST_DONE_KEY = 'tideline.post.backondeck.delivered';

type Phase = 'arrive' | 'read';

export default function MedallionPost() {
  const router = useRouter();
  const user = useCurrentUser();
  const events = useEvents();
  const createJournalEntry = useCreateJournalEntry();
  const [phase, setPhase] = useState<Phase>('arrive');
  const name = (user?.displayName || '').trim().split(/\s+/)[0] || 'friend';

  const face = kkFace('vici');
  const ridden = (events ?? []).filter((e) => e.type === 'urge_rode_out').length;
  const standing = face ? kkStanding(face, ridden) : 0;
  const story = face ? face.stories[Math.max(0, Math.min(face.stories.length, standing) - 1)] : '';

  const close = () => (router.canGoBack() ? router.back() : router.replace('/(app)/today'));

  /** Leaving the arrival — the medallion is yours either way; the post is done. */
  const shelve = () => {
    void setJSON(POST_DONE_KEY, Date.now());
    close();
  };

  const keep = () => {
    void (async () => {
      await setJSON(POST_DONE_KEY, Date.now());
      await createJournalEntry({
        tag: 'Letter',
        title: 'VICI Post · A medallion',
        body: `Dear ${name},\n\nLast night an urge rose, crested, and left without you. This morning you opened the app anyway — logged it, stayed. Most men vanish for a week after a night like that. You came back.\n\nThe return is the strongest predictor there is — stronger than any count. This one isn't for resisting. It's for coming back.`,
      }).catch(() => {});
    })();
    close();
  };

  return (
    <View style={{ flex: 1, backgroundColor: phase === 'arrive' ? '#F6EEDD' : '#EDECE7' }}>
      <StatusBar style="dark" />

      {phase === 'arrive' ? (
        <MailArrival
          art={<MedallionArt />}
          // `Medallion Received` dresses the arrival as a warm gradient field
          // with one halo instead of the letter's two washes, and sets the name
          // at 27/600. The eyebrow and the tier chip it used to carry are gone.
          field={['#F6EEDD', '#F0E1C2']}
          halo={[340, 70, '#E2BA78', 0.38, 0.74]}
          artTop={86}
          title={face?.name ?? 'Vici'}
          titleTop={378}
          titleStyle={{ fontSize: 27, fontWeight: '600', letterSpacing: -0.2 }}
          sub={story}
          subTop={428}
          primary="Take it"
          // `Medallion Received` styles the 15/500 slot at 764 and leaves it
          // empty — the one arrival in the bundle that does, and the handover's
          // own copy of that frame already draws nothing there. So this board
          // draws nothing there either and shelves by the corner X, which the
          // frame does draw (D138).
          onPrimary={() => setPhase('read')}
          onClose={shelve}
        />
      ) : (
        <MailSheet onClose={shelve}>
          <LetterBody>
            <Salutation>Dear {name},</Salutation>
            <LetterP>
              Last night an urge rose, crested, and left without you. This morning you opened the app anyway — logged it, stayed. Most men vanish for a week
              after a night like that. You came back.
            </LetterP>
            <LetterP>
              The return is the strongest predictor there is — stronger than any count. This one isn&#39;t for resisting. It&#39;s for coming back.
            </LetterP>
          </LetterBody>
          <LetterFooter primary="Tuck it into your Log" secondary="Open the enclosure" onPrimary={keep} onSecondary={() => router.push('/drop')} />
        </MailSheet>
      )}
    </View>
  );
}

/**
 * 110 · the medallion as an object — a 136pt gold disc struck with the laurel
 * and the numeral, tilted three degrees, lit from behind and casting a contact
 * shadow. Canvas frame 260 × 260.
 */
const DISC_SHADOW = 'inset 0 0 0 4px rgba(255,255,255,0.25), inset 0 -8px 18px rgba(120,88,40,0.28), 0 14px 30px rgba(180,140,70,0.45)';

function MedallionArt() {
  return (
    <>
      {/* the light is a `closest-side` radial, already zero on its own edge, so
          its 6px blur has nothing to soften (D010); the shadow beneath is a flat
          ellipse and is drawn with the canvas's own blur (D063) */}
      <Svg width={200} height={200} style={{ position: 'absolute', left: 30, top: 20 }}>
        <Defs>
          <RadialGradient id="md-glow" cx="50%" cy="50%" r="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#E2BA78" stopOpacity={0.55} />
            <Stop offset="0.74" stopColor="#E2BA78" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={100} cy={100} rx={100} ry={100} fill="url(#md-glow)" />
      </Svg>
      <ContactShadow left={52} top={230} width={156} height={16} fill="rgba(0,0,0,0.11)" />

      <View
        style={{
          position: 'absolute',
          left: 62,
          top: 52,
          width: 136,
          height: 136,
          borderRadius: 68,
          boxShadow: DISC_SHADOW,
          transform: [{ rotate: '-3deg' }],
          alignItems: 'center',
          justifyContent: 'center',
          gap: 7,
        }}>
        <Svg width={136} height={136} style={{ position: 'absolute', top: 0, left: 0 }}>
          <Defs>
            {/* `circle at 38% 30%` is farthest-corner by default: the far corner of a
                136 box sits 0.935 of it away, so the ramp runs to 93.5%. `r` is
                stated as well as `rx`/`ry` because only `r` reaches the DOM on
                web, where the others fall back to 50% and darken the rim (D064) */}
            <RadialGradient id="md-face" cx="38%" cy="30%" r="93.5%" rx="93.5%" ry="93.5%">
              <Stop offset="0" stopColor="#F0DBB4" />
              <Stop offset="0.62" stopColor="#E2BA78" />
              <Stop offset="1" stopColor="#C99F5F" />
            </RadialGradient>
          </Defs>
          <Ellipse cx={68} cy={68} rx={68} ry={68} fill="url(#md-face)" />
        </Svg>

        {/* CSS paints an inset shadow over the element's own background; here the
            background is that <Svg>, which lands on top of it — so the rim light
            and the warm floor are drawn again above the face */}
        <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 68, boxShadow: insetOf(DISC_SHADOW) }} />

        {/* the engraved ring, 9 in from the rim */}
        <View
          pointerEvents="none"
          style={{ position: 'absolute', top: 9, left: 9, right: 9, bottom: 9, borderRadius: 59, boxShadow: 'inset 0 0 0 1.5px rgba(91,74,40,0.35)' }}
        />

        <LaurelStrike width={42} />
        <AppText style={{ fontFamily: fonts.quote, fontWeight: '600', fontSize: 17, letterSpacing: 3, color: '#5b4a28', opacity: 0.6, marginRight: -3 }}>
          V
        </AppText>
      </View>
    </>
  );
}
