import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useMemo, useRef, useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  BALANCE,
  PLAIN,
  SLIP_FED,
  SlipAnswerRow,
  SlipBeginSky,
  SlipFedTile,
  SlipClose,
  SlipHeading,
  SlipPage,
  SlipPledgeCard,
  SlipSheet,
  SlipSummaryRow,
  type FedName,
} from '@/components/slip/kit';
import { AppText, Grain, PressScale } from '@/components/ui';
import { useCreateEvent, useCurrentUser, useEvents, useJournalEntries } from '@/lib/backend';
import { setJSON } from '@/lib/storage';
import type { SlipArtName } from '@/components/slip/art';
import { SLIP_CARDS, SLIP_FED_TO_CARD } from '@/content/slipCards';
import { sans } from '@/lib/theme';

import { FlowTop, GRID_GAP, GRID_GUTTER, LoggedNote, PrimaryButton, TimeWheel, triggerTileWidth, WHEN_CHIPS } from './urge-log';

/**
 * The post-slip flow — canvas 98A–98L, plus the nineteen cards at 99A–100K.
 *
 * This is NOT `/relapse`. `Latest Vici FULL` carries both: the older four-frame
 * `36 · Relapse` run (`Relapse Log`, `Twice`, `Resign`, `Begin`), still drawn by
 * `src/app/relapse.tsx`, and this twelve-frame `98 · RELAPSE — POST-SLIP` one.
 * They share three headlines and none of their geometry — `Relapse Log` puts its
 * art at 180 and its headline at 398 where `Slip Entry` puts them at 170 and
 * 446, and draws a different picture under it. Two flows, two screens each.
 *
 * Three things the canvas does not state, and how they are read here:
 *
 * 1. **98G / 98H / 98I are alternates, not a run.** “Don’t let it become two”,
 *    “It happened again” and the dark “You can still stop here” are first,
 *    second and third slip of the same day. `FLOW.txt` lists them consecutively
 *    because it lists every frame consecutively — including all nineteen cards,
 *    which are plainly a picker.
 * 2. **The card is chosen by what fed the slip**, and “Give me another” walks
 *    the rest of the deck. The nineteen keys and the nine grid tiles are two
 *    lists that only partly overlap; `SLIP_FED_TO_CARD` is the mapping, with
 *    its reasoning on it.
 * 3. **98L is the morning after.** Its own words say so — “Last night happened.”
 *    It is reached when the slip was logged as yesterday, and directly at
 *    `/slip?stage=morning`.
 */

const noiseDark = require('../../assets/images/noise-dark.png');

const INK = '#1D1C1A';
const MUTED = '#55534E';

/** The three alternates at the end of the questions, by how many slips today. */
const WARNINGS: readonly { art: SlipArtName; artTop: number; headline: string; headlineTop: number; body: string; bodyTop: number; cta: string; dark?: boolean }[] = [
  { art: 'dominoes', artTop: 166, headline: 'Don’t let it become two.', headlineTop: 382, body: 'One slip happened. You can still turn the rest of today around.', bodyTop: 426, cta: 'Continue' },
  { art: 'screendark', artTop: 166, headline: 'Stop here.', headlineTop: 408, body: 'It happened again. The next hour can still be different.', bodyTop: 452, cta: 'Turn it around' },
  { art: 'tvnight', artTop: 176, headline: 'You can still stop here.', headlineTop: 428, body: 'The day is not gone. The phone goes away for the rest of the evening — that’s the only job.', bodyTop: 478, cta: 'Phone is away', dark: true },
] as const;

type Step = 'entry' | 'closeit' | 'when' | 'fed' | 'logged' | 'urgenow' | 'warn' | 'card' | 'pledge' | 'begin' | 'morning';

const ORDER: Step[] = ['entry', 'closeit', 'when', 'fed', 'logged', 'urgenow', 'warn', 'card', 'pledge', 'begin'];

/**
 * 98F’s four answers, top to bottom.
 *
 * `relapse-workflow.md` §11 branches the post-slip flow on a 0–5 current-urge
 * scale, and this board asks the same question with four answers instead of six
 * — so the four map onto the doc's bands: “No” is 0–1, “A little” is 2, “Yes”
 * is 3 and “I’m already watching again” is the 4–5 the doc overrides on three
 * separate pages (§4, §11, §21) — D149. 0–3 all end in the same place here, because the
 * doc's “one reset action” for 2–3 is exactly what 98G/98H/98I and the card
 * already are — the canvas draws no separate reset board to send them to. 4–5
 * has a destination the app really has: the SOS interrupt.
 */
const WATCHING = ['No', 'A little', 'Yes', 'I’m already watching again'];

/** The one answer that leaves the flow — “I’m already watching again”. */
const STILL_WATCHING = 3;

/**
 * “Tonight · 11:40 PM”, the way 98E writes it: the day word, a middot, and an
 * UPPER-case meridiem. `Lapse Done` wrote “Last night” and the urge log's own
 * `stamp()` lower-cases the meridiem on the strength of it; this frame does
 * neither, and it can say `Tonight`, which that function never produces.
 */
function slipStamp(at: number, today: number): string {
  const picked = new Date(at);
  const days = Math.round((new Date(today).setHours(0, 0, 0, 0) - new Date(at).setHours(0, 0, 0, 0)) / 86_400_000);
  const evening = picked.getHours() >= 18;
  const day = days === 0 ? (evening ? 'Tonight' : 'Today') : days === 1 ? 'Yesterday' : picked.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  return `${day} · ${picked.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`;
}

/** 98E splits the one grid across two rows: the feelings, then the situations. */
const FED_FEELINGS: readonly FedName[] = ['Bored', 'Lonely', 'Stressed', 'Tired', 'Not sure'];

export default function Slip() {
  const router = useRouter();
  const { stage } = useLocalSearchParams<{ stage?: string }>();
  const createEvent = useCreateEvent();
  const user = useCurrentUser();
  const events = useEvents();
  const journal = useJournalEntries();
  const pledge = (journal ?? []).find((entry) => entry.tag === 'Pledge');
  const { width: screenWidth } = useWindowDimensions();

  const [step, setStep] = useState<Step>(stage === 'morning' ? 'morning' : 'entry');
  const [when, setWhen] = useState(0);
  const [showWheel, setShowWheel] = useState(false);
  // A time nudged on the wheel outranks the chips until Cancel puts it back.
  const [customAt, setCustomAt] = useState<number | null>(null);
  const [fed, setFed] = useState<FedName[]>([]);
  const [watching, setWatching] = useState<number | null>(null);
  const [deck, setDeck] = useState(0);
  // Read once: the wheel must not slide under a re-render while it is open.
  const [now] = useState(() => Date.now());
  // Whether this run has written its event — read during render to discount it
  // from the day's slip count, so the ref is only the re-entry guard.
  const [logged, setLogged] = useState(false);
  const saving = useRef(false);

  const at = customAt ?? now - WHEN_CHIPS[when].offsetMs;
  const close = () => (router.canGoBack() ? router.back() : router.replace('/(app)/today'));
  const go = (next: Step) => setStep(next);
  const back = () => {
    const here = ORDER.indexOf(step);
    if (here <= 0) close();
    else go(ORDER[here - 1]);
  };

  /**
   * Slips already on the log for this day, NOT counting the one this run has
   * just written — 98G is the first slip's screen, so a clean day must land on
   * index 0 after the save, not on 98H.
   */
  const slipsToday = (events ?? []).filter((e) => e.type === 'lapse' && new Date(e.createdAt).toDateString() === new Date(at).toDateString()).length;
  const priorToday = Math.max(0, slipsToday - (logged ? 1 : 0));
  const warning = WARNINGS[Math.min(priorToday, WARNINGS.length - 1)];

  /**
   * 98J is conditional, and the canvas cannot say so — it draws one state (D148).
   * `relapse-workflow.md` §9 gives the table: an active pledge on the first slip
   * since signing shows the card; a same-day repeat “usually no, focus on
   * access/friction first”; **no pledge exists → skip the screen**. §21's QA
   * line and §22's tree say the same twice more. Both of those collapse into
   * one test: there must be a pledge, and no slip may already stand between the
   * signature and this one — a same-day repeat necessarily has one.
   *
   * Ungated, the screen put the canvas's own SAMPLE pledge (“The mornings are
   * mine again.”) in the mouth of an account that had never written one, signed
   * “You”. That is worse than a pixel miss, which is why the fallback string is
   * gone from the card as well as the screen being gated.
   */
  const priorSincePledge = pledge
    ? (events ?? []).filter((e) => e.type === 'lapse' && e.createdAt >= pledge.createdAt && !(logged && e.createdAt === at)).length
    : 0;
  const pledgeEligible = Boolean(pledge) && priorSincePledge === 0;

  /**
   * The deck: the cards the user's own answers name, in grid order, then every
   * other card so “Give me another” never runs out.
   */
  const cards = useMemo(() => {
    const picked = fed.map((name) => SLIP_FED_TO_CARD[name]).filter(Boolean);
    const first = picked.map((id) => SLIP_CARDS.find((card) => card.id === id)!).filter((card, i, all) => all.indexOf(card) === i);
    return [...first, ...SLIP_CARDS.filter((card) => !first.includes(card))];
  }, [fed]);

  async function save() {
    if (saving.current) return;
    saving.current = true;
    setLogged(true);
    await createEvent({ type: 'lapse', trigger: fed.length ? fed.join(' · ') : undefined, createdAt: at });
    // The sealed letter arrives over Today the launch after a slip is logged.
    await setJSON('tideline.letter.pending', Date.now());
  }

  switch (step) {
    // ── 98A · Slip — It Happened ────────────────────────────────────
    case 'entry':
      return (
        <>
          <StatusBar style="dark" />
          <SlipPage
            art="phoneflat"
            artTop={170}
            headline="It happened."
            headlineTop={446}
            body="The day isn’t over. Log what happened, then stop it here."
            bodyTop={492}
            cta="Log the slip"
            onCta={() => go('closeit')}
            onClose={close}
            ghost="Not now"
            onGhost={close}
          />
        </>
      );

    // ── 98B · Slip — Close It Now ───────────────────────────────────
    case 'closeit':
      return (
        <>
          <StatusBar style="dark" />
          {/* the only card frame with no ghost link under its pill */}
          <SlipPage
            art="phoneup"
            artTop={170}
            headline="Close it now."
            headlineTop={436}
            body="Everything else can wait. Close the tab, close the app, put the screen down."
            bodyTop={482}
            cta="Closed"
            onCta={() => go('when')}
            onClose={close}
          />
        </>
      );

    // ── 98C · Slip — When ───────────────────────────────────────────
    case 'when':
      return (
        <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
          <StatusBar style="dark" />
          <Grain source={noiseDark} opacity={0.07} />
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={{ flex: 1 }}>
              {/* four bars: this flow asks two questions and then shows two cards */}
              <FlowTop index={0} steps={4} onBack={back} onClose={close} />
              <SlipHeading>When did it happen?</SlipHeading>

              <View style={{ position: 'absolute', left: 0, right: 0, top: 152, flexDirection: 'row', justifyContent: 'center', gap: 10 }}>
                {WHEN_CHIPS.map((chip, index) => {
                  const on = customAt == null && when === index;
                  return (
                    <PressScale
                      key={chip.label}
                      onPress={() => {
                        setWhen(index);
                        setCustomAt(null);
                      }}
                      accessibilityRole="radio"
                      accessibilityState={{ checked: on }}
                      style={{
                        minHeight: 0,
                        paddingVertical: 13,
                        paddingHorizontal: 20,
                        borderRadius: 24,
                        backgroundColor: on ? '#131313' : '#FFFFFF',
                        boxShadow: on ? undefined : '0 0 0 1px rgba(0,0,0,0.10)',
                      }}>
                      <AppText style={[sans('500'), { fontSize: 14, color: on ? '#FFFFFF' : INK }]}>{chip.label}</AppText>
                    </PressScale>
                  );
                })}
              </View>

              <PressScale
                onPress={() => setShowWheel((open) => !open)}
                accessibilityRole="button"
                hitSlop={{ top: 14, bottom: 14, left: 30, right: 30 }}
                style={{ position: 'absolute', left: 0, right: 0, top: 222, minHeight: 0 }}>
                <AppText center style={[sans('500'), { fontSize: 14, color: MUTED }]}>Choose a time</AppText>
              </PressScale>

              {showWheel ? (
                <TimeWheel
                  at={at}
                  today={now}
                  onShift={(ms) => setCustomAt((current) => (current ?? at) + ms)}
                  onCancel={() => {
                    setCustomAt(null);
                    setShowWheel(false);
                  }}
                  onSave={() => setShowWheel(false)}
                />
              ) : null}

              <View style={{ position: 'absolute', left: 24, right: 24, top: 690 }}>
                <PrimaryButton label="Continue" onPress={() => go('fed')} />
              </View>
            </View>
          </SafeAreaView>
        </View>
      );

    // ── 98D · Slip — What Fed It ────────────────────────────────────
    case 'fed': {
      const tile = triggerTileWidth(screenWidth);
      return (
        <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
          <StatusBar style="dark" />
          <Grain source={noiseDark} opacity={0.07} />
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={{ flex: 1 }}>
              <FlowTop index={1} steps={4} onBack={back} onClose={close} />
              <SlipHeading>What fed it?</SlipHeading>
              <AppText center style={[sans('400'), { position: 'absolute', left: 0, right: 0, top: 132, fontSize: 14.5, color: MUTED }]}>
                Tap all that apply.
              </AppText>

              <View
                style={{
                  position: 'absolute',
                  left: GRID_GUTTER,
                  right: GRID_GUTTER,
                  top: 180,
                  flexDirection: 'row',
                  flexWrap: 'wrap',
                  gap: GRID_GAP,
                }}>
                {SLIP_FED.map((name) => (
                  <SlipFedTile
                    key={name}
                    name={name}
                    width={tile}
                    selected={fed.includes(name)}
                    onPress={() => setFed((current) => (current.includes(name) ? current.filter((item) => item !== name) : [...current, name]))}
                  />
                ))}
              </View>

              <View style={{ position: 'absolute', left: 24, right: 24, top: 690 }}>
                <PrimaryButton
                  label={fed.length ? `Continue · ${fed.length}` : 'Continue'}
                  enabled={fed.length > 0}
                  onPress={() => {
                    void save();
                    go('logged');
                  }}
                />
              </View>
            </View>
          </SafeAreaView>
        </View>
      );
    }

    // ── 98E · Slip — Logged ─────────────────────────────────────────
    case 'logged': {
      const feelings = fed.filter((name) => FED_FEELINGS.includes(name));
      const situations = fed.filter((name) => !FED_FEELINGS.includes(name));
      // 98E's own sample takes the change line off the SITUATION, not the
      // feeling: `Tired · Phone in bed · Late night` reads back as “Phone
      // charges outside the bedroom”, which is the Late night card's move.
      const change = (cards.find((card) => card.kind === 'trigger' && fed.some((name) => SLIP_FED_TO_CARD[name] === card.id)) ?? cards[0])?.change ?? '—';
      return (
        <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
          <StatusBar style="dark" />
          <Grain source={noiseDark} opacity={0.07} />
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={{ flex: 1 }}>
              <LoggedNote />
              <AppText center style={[sans('500'), { position: 'absolute', left: 0, right: 0, top: 244, fontSize: 27, letterSpacing: -0.2, color: INK }]}>
                Slip logged.
              </AppText>
              <AppText center style={[sans('400'), { position: 'absolute', left: 52, right: 52, top: 286, fontSize: 13.5, lineHeight: 19, color: '#8B8882' }]}>
                You stopped, logged it, and changed something for next time.
              </AppText>

              <View
                style={{
                  position: 'absolute',
                  left: 24,
                  right: 24,
                  top: 338,
                  borderRadius: 18,
                  borderCurve: 'continuous',
                  backgroundColor: '#FFFFFF',
                  boxShadow: '0 0 0 1px rgba(0,0,0,0.09)',
                  paddingVertical: 4,
                  paddingHorizontal: 20,
                }}>
                <SlipSummaryRow label="When" value={slipStamp(at, now)} />
                <SlipSummaryRow label="What was going on" value={feelings.length ? feelings.join(' · ') : '—'} />
                <SlipSummaryRow label="Set off by" value={situations.length ? situations.join(' · ') : '—'} />
                <SlipSummaryRow label="Change for next time" value={change} last />
              </View>

              <View style={{ position: 'absolute', left: 24, right: 24, top: 690 }}>
                <PrimaryButton label="Continue" onPress={() => go('urgenow')} />
              </View>
            </View>
          </SafeAreaView>
        </View>
      );
    }

    // ── 98F · Slip — Current Urge ───────────────────────────────────
    case 'urgenow':
      return (
        <>
          <StatusBar style="dark" />
          <SlipSheet>
            <SlipClose onPress={close} />
            <AppText
              center
              style={[
                sans('500'),
                { position: 'absolute', left: 44, right: 44, top: 98, fontSize: 22, lineHeight: 30, letterSpacing: 0.1, color: INK },
                BALANCE,
              ]}>
              Do you still want to keep watching?
            </AppText>
            {WATCHING.map((label, index) => (
              <SlipAnswerRow key={label} label={label} top={196 + index * 76} selected={watching === index} onPress={() => setWatching(index)} />
            ))}
            {/* the one primary in the group anchored off the top, at 54pt tall */}
            <PressScale
              // §11's 4–5 override: the answer is not decoration, it is the one
              // question in the flow whose whole job is to branch it.
              onPress={() => (watching === STILL_WATCHING ? router.replace('/urge-hub') : go('warn'))}
              accessibilityRole="button"
              style={{
                position: 'absolute',
                left: 24,
                right: 24,
                top: 692,
                height: 54,
                minHeight: 0,
                borderRadius: 27,
                backgroundColor: '#131313',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: '#FFFFFF' }]}>Continue</AppText>
            </PressScale>
          </SlipSheet>
        </>
      );

    // ── 98G / 98H / 98I · one slip, two, or three ───────────────────
    case 'warn':
      return (
        <>
          <StatusBar style={warning.dark ? 'light' : 'dark'} />
          <SlipPage
            art={warning.art}
            artTop={warning.artTop}
            headline={warning.headline}
            headlineTop={warning.headlineTop}
            body={warning.body}
            bodyTop={warning.bodyTop}
            cta={warning.cta}
            dark={warning.dark}
            onCta={() => go('card')}
            onClose={close}
          />
        </>
      );

    // ── 99A–99H, 100A–100K · the card the answers named ─────────────
    case 'card': {
      const card = cards[deck % cards.length];
      return (
        <>
          <StatusBar style="dark" />
          <SlipPage
            art={card.art}
            artTop={180}
            headline={card.headline}
            headlineTop={434}
            body={card.body}
            bodyTop={480}
            cta={card.cta}
            onCta={() => go(pledgeEligible ? 'pledge' : 'begin')}
            onClose={close}
            ghost="Give me another"
            onGhost={() => setDeck((index) => index + 1)}
          />
        </>
      );
    }

    // ── 98J · Slip — The Pledge Still Stands ────────────────────────
    case 'pledge':
      return (
        <View style={{ flex: 1, backgroundColor: '#F4F3F0' }}>
          <StatusBar style="dark" />
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={{ flex: 1 }}>
              <AppText center style={[sans('500'), { position: 'absolute', left: 36, right: 36, top: 96, fontSize: 26, letterSpacing: -0.2, lineHeight: 33, color: INK }, PLAIN]}>
                The pledge still stands.
              </AppText>
              <AppText center style={[sans('400'), { position: 'absolute', left: 44, right: 44, top: 142, fontSize: 15, lineHeight: 22, color: MUTED }]}>
                A slip doesn’t erase what you decided. Sign it again and keep going.
              </AppText>
              <SlipPledgeCard name={user?.displayName} pledge={pledge!.body} />
              <PressScale
                onPress={() => go('begin')}
                accessibilityRole="button"
                style={{ position: 'absolute', left: 24, right: 24, top: 634, height: 54, minHeight: 0, borderRadius: 27, backgroundColor: '#131313', alignItems: 'center', justifyContent: 'center' }}>
                <AppText style={[sans('600'), { fontSize: 17, letterSpacing: 0.2, color: '#FFFFFF' }]}>Sign it again</AppText>
              </PressScale>
              <PressScale
                onPress={() => router.push('/vow')}
                accessibilityRole="button"
                hitSlop={{ top: 14, bottom: 14, left: 24, right: 24 }}
                style={{ position: 'absolute', left: 0, right: 0, top: 706, minHeight: 0 }}>
                <AppText center style={[sans('500'), { fontSize: 15, color: '#8B8882' }]}>Read my pledge</AppText>
              </PressScale>
            </View>
          </SafeAreaView>
        </View>
      );

    // ── 98K · Slip — Begin Again ────────────────────────────────────
    case 'begin':
      return (
        <View style={{ flex: 1, backgroundColor: '#F0EFEB' }}>
          <StatusBar style="dark" />
          <SlipBeginSky />
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            {/*
             * The type hangs off this plain View, not off the SafeAreaView. Yoga
             * resolves a defined inset on an absolute child against the parent's
             * BORDER box and never consults its padding, and safe-area-context
             * expresses the inset as padding — so an absolute child of the
             * SafeAreaView would draw at screen y 74 minus nothing.
             */}
            <View style={{ flex: 1 }}>
              <AppText center style={[sans('500'), { position: 'absolute', left: 40, right: 40, top: 74, fontSize: 22, lineHeight: 32, color: INK }, PLAIN]}>
                The day is still yours.
              </AppText>
              <AppText center style={[sans('400'), { position: 'absolute', left: 30, right: 30, top: 146, fontSize: 14, lineHeight: 21, color: MUTED }, PLAIN]}>
                One part of it went wrong. Nothing else has to.
              </AppText>
            </View>
          </SafeAreaView>

          {/* canvas top:756 h:48 in the 852 frame — the same 48pt off the bottom edge */}
          <PressScale
            // a slip logged for a day that is not today IS last night's, which
            // is the screen 98L writes for — read the timestamp, not the chip,
            // because the wheel can move it after the chip was picked
            onPress={() => (new Date(at).toDateString() !== new Date(now).toDateString() ? go('morning') : router.replace('/(app)/today'))}
            accessibilityRole="button"
            style={{
              position: 'absolute',
              left: 16,
              right: 16,
              bottom: 48,
              height: 48,
              minHeight: 0,
              borderRadius: 25,
              backgroundColor: '#131313',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <AppText style={[sans('600'), { fontSize: 17.5, letterSpacing: 0.2, color: '#FFFFFF' }]}>Start again</AppText>
          </PressScale>
        </View>
      );

    // ── 98L · Slip — Morning After ──────────────────────────────────
    case 'morning':
      return (
        <>
          <StatusBar style="dark" />
          <SlipPage
            art="sunhills"
            artTop={170}
            headline="Morning after."
            headlineTop={428}
            body="Last night happened. Today still counts. Start with the next decision."
            bodyTop={474}
            cta="Check in"
            onCta={() => router.replace('/day/morning')}
            onClose={close}
            ghost="Later"
            onGhost={() => router.replace('/(app)/today')}
          />
        </>
      );
  }
}
