import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';

import { CheckinPicker, RoutineCTA, RoutineShell, saveCheckinDays, useCheckinDays } from '@/components/routines/kit';
import { useRoutines, useSaveRoutines, type TimeOfDay } from '@/lib/routines';

/** 109 · Nightly check-in time — the last board before Today. */
export default function NightTime() {
  const router = useRouter();
  const routines = useRoutines();
  const save = useSaveRoutines();
  const stored = useCheckinDays('night');
  // Same as the morning board: no draft until something is touched, so a late
  // read from disk still lands on the wheel.
  const [draftTime, setDraftTime] = useState<TimeOfDay | null>(null);
  const [draftDays, setDraftDays] = useState<number[] | null>(null);
  const time = draftTime ?? routines.night;
  const days = draftDays ?? stored;

  const { from } = useLocalSearchParams<{ from?: string }>();
  const fromSettings = from === 'settings';
  const back = () => (router.canGoBack() ? router.back() : router.replace(fromSettings ? '/(app)/settings' : '/(app)/today'));
  /* `Settings Check-in Time` (92B) is the only one of the three boards that still
     carries the reassurance line at y 676; `Nightly Check-in Time` (19C) and the
     morning board withdrew theirs, so the line belongs to the Settings entry
     rather than to the board. */
  const note = fromSettings ? 'Set it for the start of your riskiest hours — you can change this any time.' : undefined;

  const toggle = (day: number) => setDraftDays(days.includes(day) ? days.filter((d) => d !== day) : [...days, day].sort((a, b) => a - b));

  const done = async () => {
    await save({ night: time });
    await saveCheckinDays('night', days);
    /* Onboarding ends here, so that path replaces the stack with Today. The
       Settings path must not: 92B is a Settings sub-page and every one of its
       siblings returns to Settings, and a `replace` here threw the whole stack
       away so Back could not go home either. */
    if (fromSettings) return back();
    router.replace('/(app)/today');
  };

  return (
    <>
      <StatusBar style="dark" />
      <RoutineShell
        backLabel={fromSettings ? 'Settings' : 'Back'}
        onBack={back}
        title="When should the nightly check-in come?"
        note={note}
        cta={<RoutineCTA label="Save time" onPress={() => void done()} />}>
        <CheckinPicker time={time} onTime={setDraftTime} days={days} onToggleDay={toggle} />
      </RoutineShell>
    </>
  );
}
