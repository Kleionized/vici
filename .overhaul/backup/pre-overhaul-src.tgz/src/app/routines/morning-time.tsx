import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';

import { CheckinPicker, RoutineCTA, RoutineShell, saveCheckinDays, useCheckinDays } from '@/components/routines/kit';
import { useRoutines, useSaveRoutines, type TimeOfDay } from '@/lib/routines';

/** 108 · Morning check-in time. */
export default function MorningTime() {
  const router = useRouter();
  const routines = useRoutines();
  const save = useSaveRoutines();
  const stored = useCheckinDays('morning');
  // Both stores load from disk a beat after the screen mounts, so the draft
  // stays null until the wheel or a chip is actually touched — until then the
  // board follows whatever the store settles on.
  const [draftTime, setDraftTime] = useState<TimeOfDay | null>(null);
  const [draftDays, setDraftDays] = useState<number[] | null>(null);
  const time = draftTime ?? routines.morning;
  const days = draftDays ?? stored;

  /* The same board serves onboarding and the Settings > Reminders row, and the
     two exits are different. `Settings Check-in Time` (92B) is drawn for the
     night sibling only, but it states the rule for both: entered from Settings,
     the way back reads `Settings` and `Save time` returns there. Entered from
     onboarding it carries on to the night board. Without the parameter, editing
     the morning time from Settings dragged the user through the onboarding
     night board and left them on Today. */
  const { from } = useLocalSearchParams<{ from?: string }>();
  const fromSettings = from === 'settings';

  const back = () => (router.canGoBack() ? router.back() : router.replace(fromSettings ? '/(app)/settings' : '/(app)/today'));

  const toggle = (day: number) => setDraftDays(days.includes(day) ? days.filter((d) => d !== day) : [...days, day].sort((a, b) => a - b));

  const next = async () => {
    await save({ morning: time });
    await saveCheckinDays('morning', days);
    if (fromSettings) return back();
    router.push('/routines/night-time');
  };

  return (
    <>
      <StatusBar style="dark" />
      <RoutineShell
        backLabel={fromSettings ? 'Settings' : 'Back'}
        onBack={back}
        title="When should the morning check-in come?"
        cta={<RoutineCTA label="Save time" onPress={() => void next()} />}>
        <CheckinPicker time={time} onTime={setDraftTime} days={days} onToggleDay={toggle} />
      </RoutineShell>
    </>
  );
}
